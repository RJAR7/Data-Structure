#!/usr/bin/env bash
# 逐个编译并运行全部章节/示例程序，自动挑选可用编译器。
# 用法：bash build_all.sh            （默认依次试 g++ / clang++ / Dev-C++ MinGW）
#       CXX=clang++ bash build_all.sh   （手动指定）
set -u
cd "$(dirname "$0")"

# 选择编译器：优先环境变量 CXX，然后 PATH，最后常见 Dev-C++ 路径
if [ -n "${CXX:-}" ]; then
  :
elif command -v g++ >/dev/null 2>&1; then
  CXX=g++
elif command -v clang++ >/dev/null 2>&1; then
  CXX=clang++
else
  for p in \
    "/d/Program Files (x86)/Dev-Cpp/MinGW64/bin/g++.exe" \
    "/c/Program Files (x86)/Dev-Cpp/MinGW64/bin/g++.exe" \
    "/d/Program Files/Dev-Cpp/MinGW64/bin/g++.exe" \
    "/c/Program Files/Dev-Cpp/MinGW64/bin/g++.exe" \
    "/c/Dev-Cpp/MinGW64/bin/g++.exe"; do
    if [ -x "$p" ]; then CXX="$p"; break; fi
  done
fi

if [ -z "${CXX:-}" ]; then
  echo "[ERROR] 未找到 C++ 编译器，请安装 Dev-C++ 或把 g++/clang++ 加入 PATH。" >&2
  exit 1
fi

# 用 C++11：Dev-C++ 5.11 / g++ 4.9.2 与主流新编译器都支持的最低公共标准
STD=c++11
echo "编译器: $CXX"
echo "标准  : -std=$STD"
echo "说明  : 逐个编译并运行 $(ls ch*.cpp 2>/dev/null | wc -l) 个程序"
echo

fail=0
for f in ch*.cpp; do
  base="${f%.cpp}"
  echo "===== 编译并运行 $base ====="
  if "$CXX" -std=$STD -O2 -Wall -UNDEBUG "$f" -o "$base"; then
    "./$base" || { echo "[运行/断言失败] $f"; fail=1; }
  else
    echo "[编译失败] $f"
    fail=1
  fi
done

echo
if [ "$fail" -eq 0 ]; then
  echo "========== ALL OK：全部编译运行通过 =========="
else
  echo "========== 有失败项，请查看上方 error ========"
fi
exit "$fail"
