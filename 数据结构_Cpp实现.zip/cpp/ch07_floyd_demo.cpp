// ch07_floyd_demo.cpp —— 教材 7.6.2「Floyd 全源最短路」完整可编译示例
// 编译：g++ -std=c++17 -O2 ch07_floyd_demo.cpp -o floyd && ./floyd
// 说明：整体作为一个 @SECTION 段；0-based 顶点 0..3 对应教材 1-based 顶点 1..4（顶点 i = 教材顶点 i+1）。
// @SECTION 7.6.2 | 完整可编译示例：Floyd 全源最短路
#include "ds_common.h"

// ---------- 带权图的邻接矩阵（0-based；long long 存权，INF_COST 表示 ∞）----------
struct MGraph {
    int n;
    vector<vector<long long>> arcs;            // arcs[u][v]：弧权；INF_COST 表示无边
    explicit MGraph(int n_) : n(n_), arcs(n_, vector<long long>(n_, INF_COST)) {
        for (int i = 0; i < n_; ++i) arcs[i][i] = 0;
    }
    void AddUndir(int u, int v, long long w) { arcs[u][v] = arcs[v][u] = w; }
};

// 对齐打印 D 矩阵：INF 显示为 "INF"，列宽统一用 std::setw。
void PrintMatrix(const vector<vector<long long>>& D) {
    int n = (int)D.size();
    cout << "        ";                        // 行标占位
    for (int j = 0; j < n; ++j) cout << std::setw(5) << j;
    cout << "\n";
    for (int i = 0; i < n; ++i) {
        cout << std::setw(4) << i << " :  ";
        for (int j = 0; j < n; ++j)
            if (D[i][j] >= INF_COST) cout << std::setw(5) << "INF";
            else cout << std::setw(5) << D[i][j];
        cout << "\n";
    }
}

// 教材算法 7.16：三层循环 for k / for i / for j；时间 O(n^3)，空间 O(n^2)。
// P[v][w] 路径矩阵记录「最后一次改进 v->w 所用的中转点 k」；-1 表示由直达弧相连（无中转）。
// 因 k 递增更新，最终 P[i][j] 即路径上编号最大的中转点，递归分治可严格收敛。
// 加法前先判断 D[i][k]、D[k][j] 是否为 INF，避免 INF 参与运算溢出。
void ShortestPath_FLOYD(const MGraph& G, vector<vector<int>>& P,
                        vector<vector<long long>>& D) {
    int n = G.n;
    P.assign(n, vector<int>(n, -1));
    D = G.arcs;                                // D^(-1)：仅允许直达弧
    cout << "D^(-1) 初始矩阵（仅允许直达弧）:\n";
    PrintMatrix(D);
    for (int k = 0; k < n; ++k) {
        string upd;
        int cnt = 0;
        for (int i = 0; i < n; ++i) {
            if (D[i][k] >= INF_COST) continue;            // 判 INF，防溢出
            for (int j = 0; j < n; ++j) {
                if (D[k][j] >= INF_COST) continue;        // 判 INF，防溢出
                long long nd = D[i][k] + D[k][j];
                if (nd < D[i][j]) {
                    D[i][j] = nd;
                    P[i][j] = k;                          // 记录中转点
                    ++cnt;
                    upd += " (" + std::to_string(i) + "," + std::to_string(j)
                         + ")=" + std::to_string(nd);
                }
            }
        }
        cout << "允许中转点 k=" << k << " -> D^(" << k << ")  本轮更新 "
             << cnt << " 项:" << upd << "\n";
        PrintMatrix(D);
    }
}

// 递归还原 i->j 路径：k = P[i][j] 为最大中转点，分治还原 (i,k) 与 (k,j)。
// P[i][j] == -1 表示 i->j 为直达弧。out 累积含首尾顶点的完整序列。
void PrintPath(const vector<vector<int>>& P, int i, int j, vector<int>& out) {
    if (P[i][j] == -1) {
        if (out.empty()) out.push_back(i);
        out.push_back(j);
        return;
    }
    int k = P[i][j];
    PrintPath(P, i, k, out);
    PrintPath(P, k, j, out);
}

// 沿还原序列累加各段直达弧权，得到路径长度。
long long PathLength(const MGraph& G, const vector<int>& path) {
    long long s = 0;
    for (size_t t = 0; t + 1 < path.size(); ++t) s += G.arcs[path[t]][path[t + 1]];
    return s;
}

// 对照：逐点以每个顶点为源跑 Dijkstra（O(n^3) 总时间），仅适用于全非负权；
// 本例所有权非负，故结果应与 Floyd 完全一致。Floyd 本身可处理负权边（无负环）。
vector<vector<long long>> DijkstraAllPairs(const MGraph& G) {
    int n = G.n;
    vector<vector<long long>> all(n, vector<long long>(n, INF_COST));
    for (int s = 0; s < n; ++s) {
        vector<long long> dist(n, INF_COST);
        vector<int> S(n, 0);
        dist[s] = 0;
        for (int t = 0; t < n; ++t) {
            int u = -1; long long best = INF_COST;
            for (int v = 0; v < n; ++v)
                if (!S[v] && dist[v] < best) { best = dist[v]; u = v; }
            if (u == -1) break;                // 剩余顶点不可达
            S[u] = 1;
            for (int v = 0; v < n; ++v) {
                if (S[v] || v == u) continue;
                if (dist[u] >= INF_COST || G.arcs[u][v] >= INF_COST) continue;
                long long nd = dist[u] + G.arcs[u][v];   // 判 INF 后再相加
                if (nd < dist[v]) dist[v] = nd;
            }
        }
        all[s] = dist;
    }
    return all;
}

int main() {
    Demo demo("7.6.2 Floyd 完整示例（自建 4 顶点无向带权网，全非负权）");
    MGraph G(4);
    G.AddUndir(0, 1, 2); G.AddUndir(0, 2, 8); G.AddUndir(1, 2, 3);
    G.AddUndir(1, 3, 9); G.AddUndir(2, 3, 1);
    cout << "无向边(0-based): (0,1,2) (0,2,8) (1,2,3) (1,3,9) (2,3,1)\n";

    vector<vector<int>> P;
    vector<vector<long long>> D;
    ShortestPath_FLOYD(G, P, D);

    cout << "最终最短距离矩阵 D = D^(3):\n";
    PrintMatrix(D);

    // 手算全源最短距离矩阵（顶点 0..3，教材 1..4）
    vector<vector<long long>> expect = {
        {0, 2, 5, 6},
        {2, 0, 3, 4},
        {5, 3, 0, 1},
        {6, 4, 1, 0}
    };
    DS_CHECK(D == expect);                     // Floyd 结果与手算矩阵逐项相等

    // 性质：对称性 D[i][j]==D[j][i]、对角为 0、三角不等式 D[i][j]<=D[i][k]+D[k][j]
    bool prop = true;
    for (int i = 0; i < 4; ++i) {
        if (D[i][i] != 0) prop = false;
        for (int j = 0; j < 4; ++j) {
            if (D[i][j] != D[j][i]) prop = false;
            for (int k = 0; k < 4; ++k)
                if (D[i][k] < INF_COST && D[k][j] < INF_COST
                    && D[i][j] > D[i][k] + D[k][j]) prop = false;
        }
    }
    DS_CHECK(prop);

    cout << "路径还原（递归 PrintPath，长度须等于 D[i][j]）:\n";
    auto show = [&](int i, int j) {
        vector<int> path;
        PrintPath(P, i, j, path);
        long long len = PathLength(G, path);
        cout << "  " << i << " -> " << j << " : ";
        for (size_t t = 0; t < path.size(); ++t) {
            if (t) cout << " -> ";
            cout << path[t];
        }
        cout << "  长度 = " << len << "（D = " << D[i][j] << "）\n";
        return len;
    };
    long long l02 = show(0, 2);
    long long l03 = show(0, 3);
    long long l13 = show(1, 3);
    DS_CHECK(l02 == D[0][2]);                 // 0->1->2 = 2+3 = 5
    DS_CHECK(l03 == D[0][3]);                 // 0->1->2->3 = 2+3+1 = 6
    DS_CHECK(l13 == D[1][3]);                 // 1->2->3 = 3+1 = 4

    vector<vector<long long>> dij = DijkstraAllPairs(G);
    DS_CHECK(dij == D);                       // 逐点 Dijkstra 与 Floyd 一致
    cout << "[7.6.2] 断言通过：手算矩阵/对称性/三角不等式/路径长度/Dijkstra 对照均成立\n";
    return 0;
}
// @ENDSECTION
