// ch09_search.cpp - 第 9 章 查找: 可编译 C++17 单文件实现
// 对应《数据结构(C 语言版)》第 9 章: 静态查找表 / 动态查找表 / 哈希表
// 仅依赖 ds_common.h + C++17 标准库; 自带 main() 用 Demo/printSeq/DS_CHECK 自测
// 分节: @SECTION 9.x | ... / @ENDSECTION; include 与 main 均在各段之外
#include "ds_common.h"
#include <list>   // ds_common.h 未含 <list>, 链地址法需要 std::list

// @SECTION 9.1 | 静态查找表
// 教材 SSTable: elem[0] 留作哨兵, 数据存 elem[1..length], 即 1-based 位序;
//   与 C++ 容器 0-based 的差异: elem.size()==length+1, 查找返回位序, 失败返回 0.
// 时间复杂度: 顺序查找 O(n); 空间复杂度: 表 O(n), 查找辅助 O(1).
// ASL: 等概率下成功 ASL=(n+1)/2, 失败 ASL=n+1 (哨兵省去每次越界判断).
struct SSTable {
    vector<ElemType> elem;   // elem[0] 为哨兵位, elem[1..length] 存递增关键字
    int length = 0;          // 关键字个数, 不含哨兵
};
Status CreateSSTable(SSTable& ST, const vector<ElemType>& a) {
    ST.elem.assign(a.size() + 1, ElemType{0});   // 0 号位显式初始化, 杜绝未定义值
    ST.length = static_cast<int>(a.size());
    for (size_t i = 0; i < a.size(); ++i) ST.elem[i + 1] = a[i];
    return OK;
}
// 哨兵版: 先把 elem[0] 置为 key, 从后向前比较, 必在 0 号位"命中"而终止,
//   返回 0 即失败; 循环内不必再判 i>=1, 比教材 while 少一次比较.
int Search_Seq(SSTable& ST, KeyType key) {
    ST.elem[0] = key;                     // 设置哨兵, 故形参取非 const 引用
    int i = ST.length;
    while (ST.elem[i] != key) --i;         // 一定会在 i==0 处因哨兵相等而停
    return i;                              // 0 = 查找失败
}
double ASL_Seq_Success(int n) { return (n + 1) / 2.0; }   // 等概率成功 ASL
double ASL_Seq_Fail(int n)    { return n + 1.0; }          // 失败 ASL(含哨兵那次)
// @ENDSECTION

// @SECTION 9.1 | 折半查找与 ASL 打印
// 前提: ST.elem[1..length] 非递减有序; 仍用 1-based 位序, low=1, high=length.
// 时间复杂度: O(log2 n); 空间复杂度: 迭代 O(1), 递归 O(log n) 栈.
// ASL: 成功 ASL≈log2(n+1)-1, 由判定树结点层号决定; 失败 ASL 亦 O(log n).
int Search_Bin(const SSTable& ST, KeyType key) {
    int low = 1, high = ST.length;
    while (low <= high) {
        int mid = low + (high - low) / 2;          // 防溢出的中点
        if (key == ST.elem[mid]) return mid;        // 返回 1-based 位序
        if (key < ST.elem[mid]) high = mid - 1;
        else low = mid + 1;
    }
    return 0;                                       // 失败
}
// 递归版: low/high 用值参传递, 与教材 Search_Bin 的递归伪码形参一致.
int Search_Bin_Rec(const SSTable& ST, KeyType key, int low, int high) {
    if (low > high) return 0;
    int mid = low + (high - low) / 2;
    if (key == ST.elem[mid]) return mid;
    if (key < ST.elem[mid]) return Search_Bin_Rec(ST, key, low, mid - 1);
    return Search_Bin_Rec(ST, key, mid + 1, high);
}
// 实测成功 ASL: 对 i=1..n 各模拟一次折半查找并累计比较次数, 再取平均.
double ASL_Bin_Success(const SSTable& ST) {
    long long total = 0;
    for (int i = 1; i <= ST.length; ++i) {
        KeyType k = ST.elem[i];
        int low = 1, high = ST.length, c = 0;
        while (low <= high) {
            ++c;
            int mid = low + (high - low) / 2;
            if (k == ST.elem[mid]) break;
            if (k < ST.elem[mid]) high = mid - 1;
            else low = mid + 1;
        }
        total += c;
    }
    return ST.length ? (double)total / ST.length : 0.0;
}
void PrintASL_Bin(const SSTable& ST) {
    cout << "折半查找: 成功ASL(实测)=" << ASL_Bin_Success(ST)
         << " 顺序成功ASL=" << ASL_Seq_Success(ST.length)
         << " 顺序失败ASL=" << ASL_Seq_Fail(ST.length) << '\n';
}
// @ENDSECTION

// @SECTION 9.2 | 二叉排序树查找与插入
// 教材 SearchBST(T,key,f,p): f 为当前结点双亲(值参), p 为引用输出;
//   成功 p 指向该结点返回 TRUE; 失败 p 指向路径上最后结点(即双亲 f)返回 FALSE.
// 1-based 说明: BST 无位序概念, 关键字直接存结点, 与 SSTable 的哨兵/位序无关.
// 时间复杂度: 查找/插入 O(h), h 为树高(平均 O(log n), 最坏单支 O(n)); 空间 O(h) 栈.
// ASL: 成功 ASL≈1+结点平均深度, 平衡时 O(log n), 单支树退化为 O(n).
struct BSTNode {
    ElemType data = 0;
    BSTNode *lchild = nullptr, *rchild = nullptr;
    // C++11 下有 NSDMI 即非聚合体，补构造函数使 new BSTNode{e, nullptr, nullptr} 成立
    BSTNode(ElemType d = 0, BSTNode* l = nullptr, BSTNode* r = nullptr)
        : data(d), lchild(l), rchild(r) {}
};
using BSTree = BSTNode*;
Status SearchBST(BSTree T, KeyType key, BSTree f, BSTree& p) {
    if (!T) { p = f; return FALSE; }                // 空子树: p 带回双亲
    if (key == T->data) { p = T; return TRUE; }
    if (key < T->data) return SearchBST(T->lchild, key, T, p);
    return SearchBST(T->rchild, key, T, p);
}
// 教材 InsertBST: 先查, 不存在则挂在 p 的左/右(或作为根), 重复关键字不插入.
Status InsertBST(BSTree& T, ElemType e) {
    BSTree p = nullptr;
    if (SearchBST(T, e, nullptr, p) == TRUE) return FALSE;
    BSTree s = new BSTNode{e, nullptr, nullptr};    // 新结点, 左右孩子缺省空
    if (!p) T = s;                                  // 原树为空, s 作根
    else if (e < p->data) p->lchild = s;
    else p->rchild = s;
    return OK;
}
// @ENDSECTION

// @SECTION 9.2 | BST 删除三情形与中序验证
// Delete_Node 对应教材 Delete(p): (1) 叶子直接删; (2) 仅一侧子树, 用该子树顶替;
//   (3) 左右俱全, 取中序前驱(左子树最右结点)顶替数据, 再删那个前驱结点.
// 时间复杂度: O(h); 空间复杂度: O(h) 递归栈; 删除后中序序列仍严格递增.
// ASL: 同 BST, 删除可能改变树高, 平衡时查找 ASL 仍 O(log n).
void Delete_Node(BSTree& p) {
    if (!p->lchild && !p->rchild) {                  // 情形(1) 叶子
        delete p; p = nullptr;
    } else if (!p->rchild) {                         // 情形(2) 只有左子树
        BSTree q = p; p = p->lchild; delete q;
    } else if (!p->lchild) {                         // 情形(2) 只有右子树
        BSTree q = p; p = p->rchild; delete q;
    } else {                                         // 情形(3) 左右子树均非空
        BSTree q = p, s = p->lchild;
        while (s->rchild) { q = s; s = s->rchild; }
        p->data = s->data;                           // 中序前驱顶替
        if (q != p) q->rchild = s->lchild;           // s 是 q 的右孩子
        else q->lchild = s->lchild;                  // s 直接是 p 的左孩子
        delete s;
    }
}
Status DeleteBST(BSTree& T, KeyType key) {
    if (!T) return FALSE;
    if (key == T->data) { Delete_Node(T); return OK; }
    if (key < T->data) return DeleteBST(T->lchild, key);
    return DeleteBST(T->rchild, key);
}
void InOrderBST(BSTree T, vector<ElemType>& out) {
    if (!T) return;
    InOrderBST(T->lchild, out);
    out.push_back(T->data);
    InOrderBST(T->rchild, out);
}
void DestroyBST(BSTree& T) {                         // 后序释放, 避免悬空指针
    if (!T) return;
    DestroyBST(T->lchild);
    DestroyBST(T->rchild);
    delete T;
    T = nullptr;
}
// @ENDSECTION

// @SECTION 9.2 | AVL 旋转与平衡处理
// bf = 左子树高 - 右子树高, 只取 LH=1 / EH=0 / RH=-1, 教材常量用整数表示.
// R_Rotate(右旋/LL): 左孩子升根; L_Rotate(左旋/RR): 右孩子升根.
// LeftBalance 处理左子树失衡(LL 或 LR), RightBalance 处理右子树失衡(RR 或 RL).
// 时间复杂度: 单次旋转 O(1), 插入整体 O(log n); 空间复杂度: O(log n) 递归栈.
// ASL: 树高 h≈1.44log2(n+2), 成功/失败 ASL 均为 O(log n), 优于单支 BST.
struct AVLNode {
    ElemType data = 0;
    int bf = 0;                                   // 平衡因子, 缺省 0 避免未初始化
    AVLNode *lchild = nullptr, *rchild = nullptr;
    // 同上：C++11 下补构造函数使 new AVLNode{e, 0, nullptr, nullptr} 成立
    AVLNode(ElemType d = 0, int b = 0, AVLNode* l = nullptr, AVLNode* r = nullptr)
        : data(d), bf(b), lchild(l), rchild(r) {}
};
using AVLTree = AVLNode*;
void R_Rotate(AVLTree& p) {
    AVLTree lc = p->lchild;
    p->lchild = lc->rchild;
    lc->rchild = p;
    p = lc;                                       // 引用回写新根
}
void L_Rotate(AVLTree& p) {
    AVLTree rc = p->rchild;
    p->rchild = rc->lchild;
    rc->lchild = p;
    p = rc;
}
void LeftBalance(AVLTree& T) {
    AVLTree lc = T->lchild;
    switch (lc->bf) {
        case 1: { T->bf = 0; lc->bf = 0; R_Rotate(T); break; }   // LL 单旋
        case -1: {                                                // LR 双旋
            AVLTree rd = lc->rchild;
            switch (rd->bf) {
                case 1:  T->bf = -1; lc->bf = 0; break;
                case 0:  T->bf = 0;  lc->bf = 0; break;
                default: T->bf = 0;  lc->bf = 1; break;           // rd->bf == -1
            }
            rd->bf = 0;
            L_Rotate(T->lchild);
            R_Rotate(T);
            break;
        }
        default: break;
    }
}
void RightBalance(AVLTree& T) {
    AVLTree rc = T->rchild;
    switch (rc->bf) {
        case -1: { T->bf = 0; rc->bf = 0; L_Rotate(T); break; }  // RR 单旋
        case 1: {                                                 // RL 双旋
            AVLTree ld = rc->lchild;
            switch (ld->bf) {
                case 1:  T->bf = 0;  rc->bf = -1; break;
                case 0:  T->bf = 0;  rc->bf = 0;  break;
                default: T->bf = 1;  rc->bf = 0;  break;           // ld->bf == -1
            }
            ld->bf = 0;
            R_Rotate(T->rchild);
            L_Rotate(T);
            break;
        }
        default: break;
    }
}
// @ENDSECTION

// @SECTION 9.2 | InsertAVL 与 bf 校验
// taller 引用参数: 子树是否长高; 插入后沿回溯路径更新 bf, 失衡即调用平衡函数.
// 四种失衡 LL/RR/LR/RL 由 LeftBalance/RightBalance 内部分辨(单旋/双旋).
// 时间复杂度: O(log n); 空间复杂度: O(log n) 递归栈; ASL: O(log n).
Status InsertAVL(AVLTree& T, ElemType e, bool& taller) {
    if (!T) {
        T = new AVLNode{e, 0, nullptr, nullptr};
        taller = true;
        return OK;
    }
    if (e == T->data) { taller = false; return FALSE; }    // 重复不插入
    if (e < T->data) {
        if (InsertAVL(T->lchild, e, taller) == FALSE) return FALSE;
        if (taller) {
            switch (T->bf) {
                case 1:  LeftBalance(T);  taller = false; break;  // 原左高再长高: LL/LR
                case 0:  T->bf = 1;      taller = true;  break;
                default: T->bf = 0;      taller = false; break;   // -1 右高被抵消
            }
        }
    } else {
        if (InsertAVL(T->rchild, e, taller) == FALSE) return FALSE;
        if (taller) {
            switch (T->bf) {
                case -1: RightBalance(T); taller = false; break;  // RR/RL
                case 0:  T->bf = -1;     taller = true;  break;
                default: T->bf = 0;      taller = false; break;   // 1 左高被抵消
            }
        }
    }
    return OK;
}
// 后序校验: 检查所有结点 bf∈{-1,0,1} 且 bf == 左高-右高, 返回实际树高.
int AVL_Check(AVLTree T, bool& ok) {
    if (!T) return 0;
    int lh = AVL_Check(T->lchild, ok);
    int rh = AVL_Check(T->rchild, ok);
    if (T->bf < -1 || T->bf > 1 || T->bf != lh - rh) ok = false;
    return (lh > rh ? lh : rh) + 1;
}
void InOrderAVL(AVLTree T, vector<ElemType>& out) {
    if (!T) return;
    InOrderAVL(T->lchild, out);
    out.push_back(T->data);
    InOrderAVL(T->rchild, out);
}
void DestroyAVL(AVLTree& T) {
    if (!T) return;
    DestroyAVL(T->lchild);
    DestroyAVL(T->rchild);
    delete T;
    T = nullptr;
}
// @ENDSECTION

// @SECTION 9.3 | B-树(m=3) 结构与查找
// 说明: 本节为完整插入实现(未退化). m=3 即 2-3 树: 结点最多 m-1=2 个关键字,
//   非根最少 ceil(m/2)-1=1 个; keys/children 用 vector, keynum 由 keys.size() 隐含.
// 简化点: (1) 阶数 m 固定为常量 3; (2) 不实现删除; (3) 重复关键字忽略;
//   (4) 结点由析构函数递归释放, 不单独维护空闲表.
// 时间复杂度: 查找/插入 O(log_m n) 次结点访问; 空间复杂度: 树本身 O(n).
// ASL: 查找成功/失败 ASL 均为 O(log_m n), 与树高成正比.
constexpr int M = 3;
struct BTNode {
    vector<KeyType> keys;        // 升序关键字, 0..M-1(溢出时临时 M 个)
    vector<BTNode*> child;       // 内部结点 child.size()==keys.size()+1
    bool leaf = true;
    ~BTNode() { for (BTNode* c : child) delete c; }   // 递归释放整棵子树
};
struct BTSearchRes {
    BTNode* node = nullptr;
    int idx = -1;
    // 同上：C++11 下补构造函数使 return {p, i} / {nullptr, -1} 成立
    BTSearchRes(BTNode* n = nullptr, int i = -1) : node(n), idx(i) {}
};
BTSearchRes SearchBTree(BTNode* T, KeyType k) {
    BTNode* p = T;
    while (p) {
        int i = 0;
        while (i < (int)p->keys.size() && k > p->keys[i]) ++i;
        if (i < (int)p->keys.size() && k == p->keys[i]) return {p, i};
        if (p->leaf) return {nullptr, -1};
        p = p->child[i];
    }
    return {nullptr, -1};
}
// split: 把临时溢出的结点 T(恰 M 个关键字)一分为二, 中间关键字经 mid 带回,
//   新右结点经 right 带回; T 保留为左结点(转移 child 所有权, 避免重复释放).
void split(BTNode* T, KeyType& mid, BTNode*& right) {
    mid = T->keys[M / 2];                        // M/2==1, 上移 keys[1]
    BTNode* r = new BTNode();
    r->leaf = T->leaf;
    r->keys.assign(T->keys.begin() + M / 2 + 1, T->keys.end());
    T->keys.resize(M / 2);                       // 左结点保留 keys[0]
    if (!T->leaf) {
        size_t keep = M / 2 + 1;                 // 左结点保留 2 个孩子
        for (size_t j = keep; j < T->child.size(); ++j) r->child.push_back(T->child[j]);
        T->child.resize(keep);
    }
    right = r;
}
// NewRoot: 根分裂时产生新根, 关键字 mid, 两棵子树 left/right.
BTNode* NewRoot(BTNode* left, KeyType mid, BTNode* right) {
    BTNode* s = new BTNode();
    s->leaf = false;
    s->keys.push_back(mid);
    s->child.push_back(left);
    s->child.push_back(right);
    return s;
}
// @ENDSECTION

// @SECTION 9.3 | InsertBTree 分裂上传
// InsertBTreeRec 返回: 0=重复未插入, 1=已插入且本结点未溢出, 2=已插入且本结点分裂.
// 教材思路: 先落到叶结点插入; 若关键字数>M-1 则 split, 中间关键字上移插进双亲,
//   双亲可能连锁溢出; 若根分裂则 NewRoot 新建根(树高 +1).
// 时间复杂度: O(log_m n) 次结点访问, 单次 split O(m); 空间复杂度: O(log_m n) 栈.
// ASL: 查找成功/失败 ASL 均为 O(log_m n), 与树高成正比.
int InsertBTreeRec(BTNode* T, KeyType k, KeyType& mid, BTNode*& right) {
    right = nullptr;
    if (T->leaf) {
        auto it = std::lower_bound(T->keys.begin(), T->keys.end(), k);
        if (it != T->keys.end() && *it == k) return 0;          // 重复
        T->keys.insert(it, k);
    } else {
        int i = 0;
        while (i < (int)T->keys.size() && k > T->keys[i]) ++i;
        if (i < (int)T->keys.size() && k == T->keys[i]) return 0;
        KeyType cmid = 0; BTNode* cright = nullptr;
        int r = InsertBTreeRec(T->child[i], k, cmid, cright);
        if (r == 0) return 0;
        if (r == 1) return 1;                                    // 子树未分裂, 本层未变
        T->keys.insert(T->keys.begin() + i, cmid);
        T->child.insert(T->child.begin() + i + 1, cright);
    }
    if ((int)T->keys.size() <= M - 1) return 1;
    split(T, mid, right);
    return 2;
}
Status InsertBTree(BTNode*& T, KeyType k) {
    if (!T) {
        T = new BTNode();
        T->keys.push_back(k);
        return OK;
    }
    KeyType mid = 0; BTNode* right = nullptr;
    int r = InsertBTreeRec(T, k, mid, right);
    if (r == 0) return FALSE;
    if (r == 2) T = NewRoot(T, mid, right);                      // 根分裂, 树高 +1
    return OK;
}
// 后序校验 B-树合法性: 关键字有序、个数不超上界、内部结点孩子数 == keys+1.
bool CheckBTree(BTNode* T) {
    if (!T) return true;
    if ((int)T->keys.size() > M - 1) return false;
    for (size_t i = 1; i < T->keys.size(); ++i)
        if (T->keys[i - 1] >= T->keys[i]) return false;
    if (!T->leaf) {
        if (T->child.size() != T->keys.size() + 1) return false;
        for (BTNode* c : T->child) if (!CheckBTree(c)) return false;
    }
    return true;
}
// @ENDSECTION

// @SECTION 9.2A | 红黑树结点与旋转
// 颜色常量用 RB_RED/RB_BLACK 前缀, 避免与 Windows 头文件里的 RED/BLACK 宏冲突.
// NIL 叶子用 nullptr 表示并视为黑色; 每个结点带 parent 指针, 便于 Fixup 回溯.
// 时间复杂度: 单次旋转 O(1), 插入 O(log n); 空间复杂度: O(1) 辅助(迭代 Fixup).
// ASL: 红黑树高 h<=2log2(n+1), 查找成功/失败 ASL 均为 O(log n).
constexpr int RB_RED = 0;
constexpr int RB_BLACK = 1;
struct RBNode {
    KeyType key = 0;
    int color = RB_RED;                        // 新结点缺省红
    RBNode *lchild = nullptr, *rchild = nullptr, *parent = nullptr;
};
using RBTree = RBNode*;
RBNode* RB_NewNode(KeyType k) {
    RBNode* p = new RBNode();
    p->key = k;
    p->color = RB_RED;
    return p;                                  // l/r/parent 由缺省初始化为 nullptr
}
void RB_LeftRotate(RBTree& T, RBNode* x) {
    RBNode* y = x->rchild;
    if (!y) return;                            // 指针判空
    x->rchild = y->lchild;
    if (y->lchild) y->lchild->parent = x;
    y->parent = x->parent;
    if (!x->parent) T = y;                     // x 原为根
    else if (x == x->parent->lchild) x->parent->lchild = y;
    else x->parent->rchild = y;
    y->lchild = x;
    x->parent = y;
}
void RB_RightRotate(RBTree& T, RBNode* x) {
    RBNode* y = x->lchild;
    if (!y) return;
    x->lchild = y->rchild;
    if (y->rchild) y->rchild->parent = x;
    y->parent = x->parent;
    if (!x->parent) T = y;
    else if (x == x->parent->lchild) x->parent->lchild = y;
    else x->parent->rchild = y;
    y->rchild = x;
    x->parent = y;
}
// @ENDSECTION

// @SECTION 9.2A | RB_Insert_Fixup 三种情形
// 情形1 叔结点红: 父/叔涂黑, 祖涂红, z 上移到祖继续;
// 情形2 叔黑且 z 为"内侧"孩子: 先对父旋转转成情形3;
// 情形3 父涂黑、祖涂红, 对祖反向旋转. 左右分支完全对称, 最后把根涂黑.
// 时间复杂度: O(log n) 次着色(旋转至多 2 次); 空间复杂度: O(1).
// ASL: 修正不改变 BST 中序有序性, 树高仍 O(log n), 查找 ASL O(log n).
void RB_Insert_Fixup(RBTree& T, RBNode* z) {
    while (z != T && z->parent && z->parent->color == RB_RED) {
        RBNode* gp = z->parent->parent;
        if (!gp) break;                         // 父为红必非根, 判空保险
        if (z->parent == gp->lchild) {
            RBNode* u = gp->rchild;            // 叔结点
            if (u && u->color == RB_RED) {                      // 情形1
                z->parent->color = RB_BLACK;
                u->color = RB_BLACK;
                gp->color = RB_RED;
                z = gp;
            } else {
                if (z == z->parent->rchild) {                   // 情形2 LR
                    z = z->parent;
                    RB_LeftRotate(T, z);
                }
                z->parent->color = RB_BLACK;                    // 情形3 LL
                RBNode* g = z->parent->parent;
                if (g) { g->color = RB_RED; RB_RightRotate(T, g); }
            }
        } else {
            RBNode* u = gp->lchild;
            if (u && u->color == RB_RED) {                      // 情形1(对称)
                z->parent->color = RB_BLACK;
                u->color = RB_BLACK;
                gp->color = RB_RED;
                z = gp;
            } else {
                if (z == z->parent->lchild) {                   // 情形2 RL
                    z = z->parent;
                    RB_RightRotate(T, z);
                }
                z->parent->color = RB_BLACK;                    // 情形3 RR
                RBNode* g = z->parent->parent;
                if (g) { g->color = RB_RED; RB_LeftRotate(T, g); }
            }
        }
    }
    if (T) T->color = RB_BLACK;                 // 性质2: 根恒黑
}
// @ENDSECTION

// @SECTION 9.2A | RB_Insert 与 RB_Check 性质校验
// RB_Insert: 按 BST 规则挂到叶下(红结点), 再 Fixup; 重复关键字返回 FALSE.
// RB_Check 校验三条: 根黑、无父子连续红、任一结点到所有 NIL 叶的黑高一致;
//   NIL(nullptr) 视为黑色并计入黑高 1. 附带中序验证 BST 有序性.
// 时间复杂度: 插入 O(log n), 校验 O(n); 空间复杂度: O(log n) 递归栈.
// ASL: 查找成功/失败 ASL 均为 O(log n) (h<=2log2(n+1)).
Status RB_Insert(RBTree& T, KeyType k) {
    RBNode* y = nullptr;
    RBNode* x = T;
    while (x) {
        y = x;
        if (k == x->key) return FALSE;         // 去重
        x = (k < x->key) ? x->lchild : x->rchild;
    }
    RBNode* z = RB_NewNode(k);
    z->parent = y;
    if (!y) T = z;                             // 空树 -> 新根
    else if (k < y->key) y->lchild = z;
    else y->rchild = z;
    RB_Insert_Fixup(T, z);
    return OK;
}
int RB_Check_Rec(RBNode* p, bool& ok) {
    if (!p) return 1;                          // NIL 黑叶, 黑高计 1
    if (p->color == RB_RED &&
        ((p->lchild && p->lchild->color == RB_RED) ||
         (p->rchild && p->rchild->color == RB_RED))) ok = false;   // 连续红
    int lh = RB_Check_Rec(p->lchild, ok);
    int rh = RB_Check_Rec(p->rchild, ok);
    if (lh != rh) ok = false;                  // 黑高不一致
    return lh + (p->color == RB_BLACK ? 1 : 0);
}
bool RB_Check(RBTree T) {
    if (!T) return true;
    bool ok = (T->color == RB_BLACK);          // 性质2 根黑
    RB_Check_Rec(T, ok);
    return ok;
}
void InOrderRB(RBTree T, vector<ElemType>& out) {
    if (!T) return;
    InOrderRB(T->lchild, out);
    out.push_back(T->key);
    InOrderRB(T->rchild, out);
}
void DestroyRB(RBTree& T) {
    if (!T) return;
    DestroyRB(T->lchild);
    DestroyRB(T->rchild);
    delete T;
    T = nullptr;
}
// @ENDSECTION

// @SECTION 9.3 | 除留余数与线性探测
// H(key)=key%p, p 取不大于表长的最大素数, 这里 p=13、表长 HASH_M=15; 负键取正.
// 空位用 EMPTY_KEY 标记; 线性探测 pos=(pos+1)%m; collision 累计冲突(额外探测)次数.
// 与 1-based SSTable 无关: 哈希下标从 0 起, 没有哨兵位.
// 时间复杂度: 平均 O(1), 最坏 O(n); 装填因子 a=n/m 越小冲突越少.
// ASL: 成功 ASL≈(1+1/(1-a))/2, 失败 ASL≈(1+1/(1-a)^2)/2 (线性探测).
constexpr int HASH_P = 13;                     // 除留余数的模(素数)
constexpr int HASH_M = 15;                     // 开放定址表长(>p, 保证存在空位)
constexpr ElemType EMPTY_KEY = std::numeric_limits<ElemType>::min();
struct HashTable {
    vector<ElemType> elem;                     // 0-based, EMPTY_KEY 表示空位
    int count = 0;
    int collision = 0;
};
int H(KeyType key) {
    int r = key % HASH_P;
    return r < 0 ? r + HASH_P : r;             // 兼容负关键字
}
Status InitHash(HashTable& HT, int m) {
    HT.elem.assign(m, EMPTY_KEY);              // 逐位初始化, 无未定义值
    HT.count = 0;
    HT.collision = 0;
    return OK;
}
Status InsertHash(HashTable& HT, KeyType key) {
    if (HT.count >= (int)HT.elem.size()) return ERROR;    // 表满
    int pos = H(key), probes = 0;
    while (HT.elem[pos] != EMPTY_KEY && HT.elem[pos] != key) {
        pos = (pos + 1) % (int)HT.elem.size();             // 线性探测
        ++probes;
    }
    if (HT.elem[pos] == key) return FALSE;                 // 已存在
    HT.elem[pos] = key;
    HT.collision += probes;                                // 统计冲突次数
    ++HT.count;
    return OK;
}
Status SearchHash(const HashTable& HT, KeyType key, int& cmp) {
    cmp = 0;
    int start = H(key), pos = start;
    do {
        ++cmp;
        if (HT.elem[pos] == key) return OK;
        if (HT.elem[pos] == EMPTY_KEY) return FALSE;       // 遇空位即失败
        pos = (pos + 1) % (int)HT.elem.size();
    } while (pos != start);                                // 绕回起点防死循环
    return FALSE;
}
// @ENDSECTION

// @SECTION 9.3 | 链地址法与成功/失败 ASL 计算
// ChainedHash: vector<list<int>>, 同义词挂在同一桶链表; 冲突不占用别的位置.
// 约定: 失败查找比较次数 = 该桶链表长度(空桶 0 次); 成功 ASL 按实测比较次数平均.
// ASL_Hash_Success 对两种方法通用; 失败 ASL 分别按探测到空位 / 桶长统计.
// 时间复杂度: 平均 O(1+a), 最坏 O(n); 空间复杂度: O(n + p) 个结点/表头.
// ASL: 成功 ASL≈1+a/2, 失败 ASL≈a (a=n/p 为装填因子).
using std::list;
struct ChainedHash {
    vector<list<KeyType>> bucket;
    int count = 0;
};
Status InitChained(ChainedHash& CH, int m) {
    CH.bucket.assign(m, list<KeyType>());
    CH.count = 0;
    return OK;
}
Status InsertChained(ChainedHash& CH, KeyType key) {
    int pos = H(key);
    for (KeyType x : CH.bucket[pos]) if (x == key) return FALSE;
    CH.bucket[pos].push_back(key);             // 尾插, 保持插入序
    ++CH.count;
    return OK;
}
Status SearchChained(const ChainedHash& CH, KeyType key, int& cmp) {
    cmp = 0;
    for (KeyType x : CH.bucket[H(key)]) {
        ++cmp;
        if (x == key) return OK;
    }
    return FALSE;
}
double ASL_Hash_Success(const vector<int>& cmps) {
    long long total = 0;
    for (int c : cmps) total += c;
    return cmps.empty() ? 0.0 : (double)total / (int)cmps.size();
}
double ASL_Linear_Fail(const HashTable& HT) {
    long long total = 0;
    int m = (int)HT.elem.size();
    for (int j = 0; j < HASH_P; ++j) {
        int pos = j, c = 0, guard = 0;
        while (guard < m && HT.elem[pos] != EMPTY_KEY) {
            ++c; pos = (pos + 1) % m; ++guard;
        }
        ++c;                                   // 与空位的最后一次比较
        total += c;
    }
    return (double)total / HASH_P;
}
double ASL_Chained_Fail(const ChainedHash& CH) {
    long long total = 0;
    for (int j = 0; j < HASH_P; ++j) total += (long long)CH.bucket[j].size();
    return (double)total / HASH_P;
}
// @ENDSECTION

int main() {
    const vector<ElemType> seq{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};    // 递增: 折半/B树/RB
    const vector<ElemType> keys{5, 3, 9, 1, 7, 4, 2, 8, 6, 10};    // 无序: BST/AVL
    // 哈希用同组关键字(含 H 冲突): 5,16,3,18,9,22,1,14,7,20
    const vector<ElemType> hkeys{5, 16, 3, 18, 9, 22, 1, 14, 7, 20};
    HashTable HT;      // main 作用域, 供两个哈希演示块共用, 无 new 结点
    ChainedHash CH;

    {
        Demo d("9.1 顺序查找(哨兵, 1-based)");
        SSTable ST;
        CreateSSTable(ST, seq);
        DS_CHECK(Search_Seq(ST, 7) == 7);
        DS_CHECK(Search_Seq(ST, 99) == 0);                 // 失败返回 0
        printSeq(vector<ElemType>(ST.elem.begin() + 1, ST.elem.end()), "ST[1..n]");
        cout << "顺序ASL: 成功=" << ASL_Seq_Success(ST.length)
             << " 失败=" << ASL_Seq_Fail(ST.length) << '\n';
    }
    {
        Demo d("9.1 折半查找(迭代/递归)与 ASL");
        SSTable ST;
        CreateSSTable(ST, seq);
        for (int k = 1; k <= 10; ++k) {
            DS_CHECK(Search_Bin(ST, k) == k);
            DS_CHECK(Search_Bin_Rec(ST, k, 1, ST.length) == k);
        }
        DS_CHECK(Search_Bin(ST, 0) == 0);
        DS_CHECK(Search_Bin_Rec(ST, 11, 1, ST.length) == 0);
        PrintASL_Bin(ST);
    }
    {
        Demo d("9.2 二叉排序树: 查找/插入/删除三情形");
        BSTree T = nullptr;
        for (ElemType e : keys) InsertBST(T, e);
        BSTree p = nullptr;
        DS_CHECK(SearchBST(T, 7, nullptr, p) == TRUE && p && p->data == 7);
        vector<ElemType> out;
        InOrderBST(T, out);
        DS_CHECK(out == seq);                                // 中序有序
        DS_CHECK(DeleteBST(T, 1) == OK);                     // 情形(2) 仅有右子树
        DS_CHECK(DeleteBST(T, 2) == OK);                     // 情形(1) 叶子
        DS_CHECK(DeleteBST(T, 9) == OK);                     // 情形(3) 左右俱全
        DS_CHECK(DeleteBST(T, 5) == OK);                     // 情形(3) 根
        DS_CHECK(SearchBST(T, 5, nullptr, p) == FALSE);
        out.clear();
        InOrderBST(T, out);
        DS_CHECK(std::is_sorted(out.begin(), out.end()));
        printSeq(out, "删除后中序");
        DestroyBST(T);
        DS_CHECK(T == nullptr);
    }
    {
        Demo d("9.2 平衡二叉树 AVL: 四种旋转与 bf 校验");
        AVLTree T = nullptr;
        bool taller = false;
        const vector<ElemType> mix{4, 7, 5, 6, 10, 9, 1, 8, 2, 3};  // 实测触发 LL/RR/LR/RL
        for (ElemType e : mix) InsertAVL(T, e, taller);
        for (ElemType e : seq) InsertAVL(T, e, taller);      // 重复关键字被忽略
        bool ok = true;
        AVL_Check(T, ok);
        DS_CHECK(ok);                                        // 所有 bf∈{-1,0,1}
        vector<ElemType> out;
        InOrderAVL(T, out);
        DS_CHECK(out == seq);                                // 中序有序
        printSeq(out, "AVL 中序");
        DestroyAVL(T);
        DS_CHECK(T == nullptr);
    }
    {
        Demo d("9.3 B-树(m=3): 分裂/NewRoot 与查找");
        BTNode* T = nullptr;
        for (ElemType e : seq) InsertBTree(T, e);
        DS_CHECK(CheckBTree(T));
        for (ElemType e : seq) DS_CHECK(SearchBTree(T, e).node != nullptr);
        DS_CHECK(SearchBTree(T, 99).node == nullptr);
        cout << "根关键字数=" << T->keys.size() << " 根关键字=";
        printSeq(T->keys);
        delete T; T = nullptr;                              // 析构递归释放全部结点
        DS_CHECK(T == nullptr);
    }
    {
        Demo d("9.2A 红黑树: 递增插入后 RB_Check");
        RBTree T = nullptr;
        for (ElemType e : seq) RB_Insert(T, e);              // 递增序列最考验修正
        DS_CHECK(RB_Check(T));                               // 根黑/无连续红/黑高一致
        vector<ElemType> out;
        InOrderRB(T, out);
        DS_CHECK(out == seq);                                // BST 有序
        cout << "根颜色=" << (T->color == RB_BLACK ? "黑" : "红") << '\n';
        DestroyRB(T);
        DS_CHECK(T == nullptr);
    }
    {
        Demo d("9.3 哈希: 除留余数 + 线性探测");
        InitHash(HT, HASH_M);
        for (ElemType k : hkeys) InsertHash(HT, k);
        vector<int> cmps;
        for (ElemType k : hkeys) {
            int c = 0;
            DS_CHECK(SearchHash(HT, k, c) == OK);            // 全部能查到
            cmps.push_back(c);
        }
        int c0 = 0;
        DS_CHECK(SearchHash(HT, 99, c0) == FALSE);
        cout << "装填因子=" << (double)HT.count / HASH_M
             << " 冲突次数=" << HT.collision
             << " 成功ASL=" << ASL_Hash_Success(cmps)
             << " 失败ASL=" << ASL_Linear_Fail(HT) << '\n';
    }
    {
        Demo d("9.3 哈希: 链地址法 + 两种方法同组断言");
        InitChained(CH, HASH_P);
        for (ElemType k : hkeys) InsertChained(CH, k);
        vector<int> cmps;
        for (ElemType k : hkeys) {
            int c1 = 0, c2 = 0;
            DS_CHECK(SearchHash(HT, k, c1) == OK);           // 开放定址: 全部命中
            DS_CHECK(SearchChained(CH, k, c2) == OK);        // 链地址法: 全部命中
            cmps.push_back(c2);
        }
        DS_CHECK(CH.count == (int)hkeys.size());
        cout << "链地址成功ASL=" << ASL_Hash_Success(cmps)
             << " 失败ASL=" << ASL_Chained_Fail(CH)
             << " | 线性失败ASL=" << ASL_Linear_Fail(HT) << '\n';
    }
    cout << "第 9 章全部模块自测通过\n";
    return 0;
}
