// ch10_heapsort_demo.cpp —— 教材 10.4.3「堆排序」完整可编译示例
// 编译：g++ -std=c++17 -O2 ch10_heapsort_demo.cpp -o heapsort && ./heapsort
// 说明：本文件整体作为一个 @SECTION 段，便于讲义折叠展示「复制即可编译」的完整源码。
// @SECTION 10.4.3 | 完整可编译示例：堆排序（建堆与重建堆）
#include "ds_common.h"

// ---------- 教材 SqList / HeapType：1-based 下标 ----------
// r[i] 的双亲为 i/2、左孩子 2i、右孩子 2i+1（完全二叉树顺序存储）；
// 与 STL 0-based 差 1，故分配 n+1 个单元，r[0] 不用（仅占位）。
struct RedType {
    KeyType key = 0;        // 关键字项
    int otherinfo = 0;      // 其它数据项（随记录移动，便于观察重复 49 的不稳定）
};
struct SqList {
    vector<RedType> r;      // r[0..n]，1-based 使用
    int length;
    explicit SqList(int n) : r(n + 1), length(n) {}
};
typedef SqList HeapType;    // 教材：堆采用顺序表存储表示

// 演示统计与快照
long long g_cmp = 0;            // 关键字比较次数
long long g_mov = 0;            // 记录移动（赋值）次数
vector<int> g_heapAfterBuild;   // 建堆完成后的 1..n 关键字快照（供 main 断言）

// 一行打印 1..n：堆区 [1..m] 与已归位有序后缀 [m+1..n] 用 | 分隔
void printFull(const HeapType& H, int m) {
    cout << "[";
    for (int i = 1; i <= H.length; ++i) {
        if (i == m + 1) cout << " |";
        cout << std::setw(3) << H.r[i].key;
    }
    cout << " ]";
}
// 一行的「堆形」：按完全二叉树层分组 {L0 | L1 | L2 ...}
string heapShape(const HeapType& H, int m) {
    string out = "{";
    int lv = 0, idx = 1;
    bool first = true;
    while (idx <= m) {
        int cnt = 1 << lv;
        if (!first) out += " | ";
        first = false;
        for (int k = 0; k < cnt && idx <= m; ++k, ++idx) {
            if (k) out += " ";
            out += std::to_string(H.r[idx].key);
        }
        ++lv;
    }
    return out + "}";
}
// 按完全二叉树的层缩进打印：每层一行，层次越深缩进越大
void PrintHeap(const HeapType& H, int m) {
    int lv = 0, idx = 1;
    while (idx <= m) {
        int cnt = 1 << lv;
        cout << string(2 * lv, ' ');        // 层缩进
        for (int k = 0; k < cnt && idx <= m; ++k, ++idx) {
            if (k) cout << ' ';
            cout << std::setw(2) << H.r[idx].key;
        }
        cout << "\n";
        ++lv;
    }
}
// 断言 r[s..m] 满足大顶堆（根在 1 的标准 1-based 堆，s 取 1）
bool CheckMaxHeap(const HeapType& H, int s, int m) {
    for (int i = s; i <= m / 2; ++i) {
        int l = 2 * i, r = 2 * i + 1;
        if (l <= m && H.r[i].key < H.r[l].key) return false;
        if (r <= m && H.r[i].key < H.r[r].key) return false;
    }
    return true;
}
// 断言 r[i..n] 为「已归位的有序后缀」：升序，且均不小于堆区 r[1..i-1]
bool sortedSuffix(const HeapType& H, int i, int n) {
    for (int k = i; k < n; ++k)
        if (H.r[k].key > H.r[k + 1].key) return false;
    int heapMax = H.r[1].key;
    for (int k = 2; k < i; ++k) heapMax = std::max(heapMax, H.r[k].key);
    for (int k = i; k <= n; ++k)
        if (H.r[k].key < heapMax) return false;
    return true;
}

// 教材算法 10.10：已知 r[s..m] 除 r[s] 外均满足堆定义，沿关键字较大的孩子下筛。
// 先保存 r[s]，把较大的孩子逐层上移，最后把 r[s] 放到合适位置。
void HeapAdjust(HeapType& H, int s, int m) {
    RedType rc = H.r[s];                   // 先保存 r[s]
    ++g_mov;
    for (int j = 2 * s; j <= m; j *= 2) { // 沿关键字较大的孩子向下筛选
        if (j < m) {
            ++g_cmp;
            if (H.r[j].key < H.r[j + 1].key) ++j; // j 取较大孩子下标
        }
        ++g_cmp;
        if (rc.key >= H.r[j].key) break;   // rc 已不小于较大孩子，位置 s 合适
        H.r[s] = H.r[j];                   // 大孩子上移
        ++g_mov;
        s = j;                             // 继续下筛
    }
    H.r[s] = rc;                          // rc 插入最终位置
    ++g_mov;
}

// 教材算法 10.11：先建初堆（O(n)），再反复「交换堆顶与堆尾 + 重建堆」。
// 时间 O(n log n)、空间 O(1)（就地）、不稳定（相等关键字可能换位）；建堆 O(n)。
void HeapSort(HeapType& H) {
    int n = H.length;
    g_cmp = 0; g_mov = 0; g_heapAfterBuild.clear();
    cout << "--- 建初堆: for (i=n/2; i>0; --i) HeapAdjust(i,n) ---\n";
    for (int i = n / 2; i > 0; --i) {
        HeapAdjust(H, i, n);
        cout << "  HeapAdjust(s=" << i << ", m=" << n << ") 后 序列";
        printFull(H, n);
        cout << " 堆形 " << heapShape(H, n) << "\n";
    }
    cout << "--- 建堆完成的大顶堆（层缩进树形）---\n";
    PrintHeap(H, n);
    DS_CHECK(CheckMaxHeap(H, 1, n));       // 堆性质成立
    DS_CHECK(H.r[1].key == 97);            // 堆顶为最大值
    for (int i = 1; i <= n; ++i) g_heapAfterBuild.push_back(H.r[i].key);
    cout << "  建堆完成: CheckMaxHeap(1,n) 成立, r[1]=" << H.r[1].key << "\n";

    cout << "--- 排序: for (i=n; i>1; --i) { swap(r[1],r[i]); HeapAdjust(1,i-1); } ---\n";
    for (int i = n; i > 1; --i) {
        std::swap(H.r[1], H.r[i]);         // 教材：交换堆顶与堆尾，最大记录归位
        g_mov += 3;                        // 交换约 3 次记录移动
        DS_CHECK(sortedSuffix(H, i, n));   // r[i..n] 为已归位的有序后缀
        HeapAdjust(H, 1, i - 1);           // 将 r[1..i-1] 重建为大顶堆
        DS_CHECK(CheckMaxHeap(H, 1, i - 1));
        cout << "  i=" << i << " 交换 r[1]<->r[" << i << "], 重建堆(1.." << i - 1 << ") 后 ";
        printFull(H, i - 1);
        cout << " 堆形 " << heapShape(H, i - 1) << "\n";
    }
}

int main() {
    Demo demo("10.4.3 堆排序（教材序列 49 38 65 97 76 13 27 49）");
    vector<int> init = {49, 38, 65, 97, 76, 13, 27, 49};
    HeapType H(8);
    for (int i = 1; i <= H.length; ++i) {  // STL 0-based init 映射到 1-based r
        H.r[i].key = init[i - 1];
        H.r[i].otherinfo = i;
    }
    cout << "初始序列（1-based，双亲 i/2、孩子 2i/2i+1，r[0] 占位）：\n";
    printFull(H, H.length); cout << "\n";
    HeapSort(H);
    cout << "\n最终排序结果：\n";
    printFull(H, H.length); cout << "\n";
    vector<int> got;
    for (int i = 1; i <= H.length; ++i) got.push_back(H.r[i].key);
    vector<int> expect = init;
    std::sort(expect.begin(), expect.end());
    cout << "统计: cmp=" << g_cmp << "  mov=" << g_mov << "\n";

    // ---- 手算断言 ----
    // 建堆：HeapAdjust(4,3,2,1) 后得大顶堆 {97,76,65,49,49,13,27,38}，r[1]=97。
    vector<int> builtHeap = {97, 76, 65, 49, 49, 13, 27, 38};
    DS_CHECK(g_heapAfterBuild == builtHeap);          // 手算建堆结果
    DS_CHECK(g_heapAfterBuild[0] == 97);              // 堆顶为最大值
    DS_CHECK(std::is_sorted(got.begin(), got.end())); // 整体升序
    DS_CHECK(got == expect);                          // 与 std::sort 一致（含重复 49）
    cout << "[10.4.3] 断言通过：建堆={97,76,65,49,49,13,27,38}, r[1]=97, 整体升序\n";
    return 0;
}
// @ENDSECTION
