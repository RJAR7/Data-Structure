// ds_common.h —— 全书 C++ 实现的公共约定（对应教材 1.3 节的 ADT 实现约定）
// 用法：每个 chXX_*.cpp 只需 #include "ds_common.h"，即可单独编译运行。
#ifndef DS_COMMON_H
#define DS_COMMON_H

// Dev-C++ / MinGW 的控制台默认代码页是 GBK(936)，而本套源码为 UTF-8，
// 若不切换，cout 输出的中文会乱码。这里先定义 NOMINMAX 防止 windows.h 的
// min/max 宏破坏 <algorithm>，再引入 Win32 API（MSVC / MinGW 均适用）。
#if defined(_WIN32)
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#endif

#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <queue>
#include <stack>
#include <string>
#include <unordered_map>
#include <vector>

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::vector;

// ---- 教材伪码类型在 C++ 中的落地（见 cpp/README.md 的映射表）----
using ElemType = int;          // 教材 ElemType：为可编译、可演示，统一实例化为 int
using KeyType  = int;          // 教材 KeyType
using Status   = int;          // 教材 Status

#ifdef TRUE
#undef TRUE
#endif
#ifdef FALSE
#undef FALSE
#endif
#ifdef ERROR
#undef ERROR
#endif
#ifdef OVERFLOW
#undef OVERFLOW
#endif
constexpr Status TRUE     = 1;
constexpr Status FALSE    = 0;
constexpr Status OK       = 1;
constexpr Status ERROR    = 0;
constexpr Status OVERFLOW = -2;

constexpr int INF_COST = std::numeric_limits<int>::max() / 4; // 教材 INFINITY（图的 ∞）
constexpr int MAXSIZE  = 1000;                                // 教材 MAXSIZE

// ---- 演示与自测工具 ----
template <class Container>
void printSeq(const Container& c, const string& tip = "") {
    if (!tip.empty()) cout << tip << ": ";
    for (const auto& x : c) cout << x << ' ';
    cout << '\n';
}

template <class T, size_t N>
void printArr(const T (&a)[N], size_t from, size_t to, const string& tip = "") {
    if (!tip.empty()) cout << tip << ": ";
    for (size_t i = from; i <= to && i < N; ++i) cout << a[i] << ' ';
    cout << '\n';
}

// 断言宏：既输出中文提示，也在 Debug 下中止，便于逐章自检
#define DS_CHECK(expr)                                                        \
    do {                                                                      \
        if (!(expr)) {                                                        \
            std::cerr << "[FAIL] " << __FILE__ << ":" << __LINE__             \
                      << "  " #expr << '\n';                                   \
            assert(expr);                                                     \
        }                                                                     \
    } while (0)

// 演示与自测工具
struct Demo {
    string name;
    explicit Demo(const string& n) : name(n) { cout << "\n===== " << n << " =====\n"; }
    ~Demo() { cout << "----- " << name << " OK -----\n"; }
};

// ---- Windows 控制台 UTF-8 输出（Dev-C++ 中文乱码一键修复）----
// 用一个全局对象的构造函数，在 main() 之前把控制台切到 UTF-8 代码页，
// 使 cout 的中文字符串可在 Dev-C++ / cmd 的黑窗口里正确显示。
// 非 Windows 平台无操作；不影响重定向到文件（文件本就是 UTF-8 字节）。
#if defined(_WIN32)
namespace ds_detail {
struct ConsoleUtf8 {
    ConsoleUtf8() {
        SetConsoleOutputCP(CP_UTF8);   // 标准输出/错误：UTF-8
        SetConsoleCP(CP_UTF8);         // 标准输入：UTF-8
    }
};
static ConsoleUtf8 _console_utf8_on_startup;   // 每个可执行文件构造一次
} // namespace ds_detail
#endif

#endif // DS_COMMON_H
