// ch07_topo_demo.cpp —— 教材 7.5「拓扑排序与关键路径」完整可编译示例
// 编译：g++ -std=c++17 -O2 ch07_topo_demo.cpp -o topo && ./topo
// 说明：整体作为一个 @SECTION 段；0-based 事件 0..8 对应教材 1-based 事件 v1..v9（事件 i = v_{i+1}）。
// @SECTION 7.5 | 完整可编译示例：拓扑排序与关键路径
#include "ds_common.h"

// ---------- AOE 网：活动表 + 出边表 + 入度数组（0-based）----------
struct Activity { int u, v, w; };              // 活动 u->v，持续时间 w
struct AOEGraph {
    int n;
    vector<Activity> acts;
    vector<vector<int>> out;                   // out[u]：以 u 为起点的活动下标
    vector<int> indeg;                        // 入度（拓扑排序用）
    explicit AOEGraph(int n_) : n(n_), out(n_), indeg(n_, 0) {}
    void AddActivity(int u, int v, int w) {
        int id = (int)acts.size();
        acts.push_back({u, v, w});
        out[u].push_back(id);
        ++indeg[v];
    }
};

void PrintIdx(const vector<int>& v) {
    cout << "[";
    for (size_t t = 0; t < v.size(); ++t) { if (t) cout << ","; cout << v[t]; }
    cout << "]";
}

// 教材算法 7.12：入度数组 + 栈；时间 O(n+e)。返回 {是否有拓扑序, 拓扑序列}。
// 用 vector 模拟栈，便于逐轮打印「入度为 0 的顶点 / 出栈顶点 / 更新后的入度表」。
std::pair<bool, vector<int>> TopologicalSort(const AOEGraph& G, bool verbose) {
    int n = G.n;
    vector<int> indeg = G.indeg;               // 拷贝，避免改动原图
    vector<int> st;
    for (int i = 0; i < n; ++i) if (indeg[i] == 0) st.push_back(i);
    vector<int> seq;
    int round = 0;
    while (!st.empty()) {
        vector<int> zero = st;                 // 本轮「入度为 0 的顶点」快照
        int u = st.back(); st.pop_back();      // 出栈顶点
        seq.push_back(u);
        for (int id : G.out[u]) {              // 删去 u 的所有出边，更新入度
            int v = G.acts[id].v;
            if (--indeg[v] == 0) st.push_back(v);
        }
        if (verbose) {
            cout << "  第" << std::setw(2) << ++round << "轮 入度0顶点=";
            PrintIdx(zero);
            cout << " 出栈=" << u << " 更新后入度:";
            for (int x : indeg) cout << std::setw(3) << x;
            cout << "\n";
        }
    }
    return { (int)seq.size() == n, seq };
}

struct CPResult {
    vector<int> ve, vl, e, l;                  // 事件最早/最迟，活动最早/最迟
    vector<int> critical;                     // 关键活动下标（e==l）
    long long length = 0;                     // 关键路径长度
};

// 教材算法 7.13/7.14：ve 按拓扑序正推、vl 逆拓扑序反推、e/l 判关键活动；时间 O(n+e)。
CPResult CriticalPath(const AOEGraph& G, int src, int snk, const vector<int>& topo) {
    int n = G.n, m = (int)G.acts.size();
    CPResult R;
    R.ve.assign(n, 0);
    R.vl.assign(n, 0);
    R.e.assign(m, 0);
    R.l.assign(m, 0);
    // 1) 事件最早发生时间 ve：按拓扑序正推取最大
    for (int u : topo)
        for (int id : G.out[u]) {
            int v = G.acts[id].v;
            R.ve[v] = std::max(R.ve[v], R.ve[u] + G.acts[id].w);
        }
    // 2) 事件最迟发生时间 vl：逆拓扑序反推取最小
    std::fill(R.vl.begin(), R.vl.end(), R.ve[snk]);
    for (auto it = topo.rbegin(); it != topo.rend(); ++it) {
        int u = *it;
        for (int id : G.out[u]) {
            int v = G.acts[id].v;
            R.vl[u] = std::min(R.vl[u], R.vl[v] - G.acts[id].w);
        }
    }
    // 3) 活动最早 e = ve[u]，最迟 l = vl[v] - w；e == l 即关键活动
    vector<int> isCrit(m, 0);
    for (int id = 0; id < m; ++id) {
        int u = G.acts[id].u, v = G.acts[id].v, w = G.acts[id].w;
        R.e[id] = R.ve[u];
        R.l[id] = R.vl[v] - w;
        if (R.e[id] == R.l[id]) { R.critical.push_back(id); isCrit[id] = 1; }
    }
    // 4) 沿关键活动从源点走到汇点，累加持续时间得到关键路径长度
    int cur = src;
    while (cur != snk) {
        int next = -1;
        for (int id : G.out[cur])
            if (isCrit[id]) { R.length += G.acts[id].w; next = G.acts[id].v; break; }
        if (next == -1) break;
        cur = next;
    }
    // ---- 逐步打印 ----
    cout << "事件最早发生时间 ve:\n";
    cout << "  事件: "; for (int i = 0; i < n; ++i) cout << std::setw(4) << i; cout << "\n";
    cout << "  ve  : "; for (int i = 0; i < n; ++i) cout << std::setw(4) << R.ve[i]; cout << "\n";
    cout << "事件最迟发生时间 vl:\n";
    cout << "  事件: "; for (int i = 0; i < n; ++i) cout << std::setw(4) << i; cout << "\n";
    cout << "  vl  : "; for (int i = 0; i < n; ++i) cout << std::setw(4) << R.vl[i]; cout << "\n";
    cout << "活动表（e, l, l-e；l-e==0 为关键活动）:\n";
    cout << "  活动   u->v   w    e    l  l-e\n";
    for (int id = 0; id < m; ++id)
        cout << "  a" << std::setw(2) << id + 1 << "    "
             << G.acts[id].u << "->" << G.acts[id].v << std::setw(4) << G.acts[id].w
             << std::setw(5) << R.e[id] << std::setw(5) << R.l[id]
             << std::setw(5) << R.l[id] - R.e[id] << "\n";
    cout << "关键活动: ";
    for (int id : R.critical) cout << "a" << id + 1 << " ";
    cout << "\n关键路径长度 = " << R.length << "\n";
    return R;
}

int main() {
    Demo demo("7.5 拓扑排序 + 关键路径完整示例（教材 9 事件 11 活动 AOE 网）");
    AOEGraph G(9);
    G.AddActivity(0, 1, 6);   // a1
    G.AddActivity(0, 2, 4);   // a2
    G.AddActivity(0, 3, 5);   // a3
    G.AddActivity(1, 4, 1);   // a4
    G.AddActivity(2, 4, 1);   // a5
    G.AddActivity(3, 5, 2);   // a6
    G.AddActivity(4, 6, 9);   // a7
    G.AddActivity(4, 7, 7);   // a8
    G.AddActivity(5, 7, 4);   // a9
    G.AddActivity(6, 8, 2);   // a10
    G.AddActivity(7, 8, 4);   // a11
    cout << "AOE 网（0-based 事件 0..8 = 教材 1-based 事件 v1..v9），共 11 个活动\n";

    cout << "TopologicalSort 逐步演示:\n";
    auto r1 = TopologicalSort(G, true);
    DS_CHECK(r1.first);                        // DAG 必存在拓扑序列
    cout << "拓扑序列: "; printSeq(r1.second);
    vector<int> pos(9, -1);
    for (int t = 0; t < (int)r1.second.size(); ++t) pos[r1.second[t]] = t;
    bool legal = true;
    for (int id = 0; id < (int)G.acts.size(); ++id)
        if (pos[G.acts[id].u] >= pos[G.acts[id].v]) legal = false;
    DS_CHECK(legal);                           // 每条边起点在终点之前

    // 有环图：0->1->2->0，断言 TopologicalSort 返回 false
    AOEGraph cyc(3);
    cyc.AddActivity(0, 1, 1); cyc.AddActivity(1, 2, 1); cyc.AddActivity(2, 0, 1);
    auto r2 = TopologicalSort(cyc, false);
    DS_CHECK(!r2.first);
    cout << "有环图 0->1->2->0：TopologicalSort 返回 false（检测出环）\n";

    cout << "CriticalPath 逐步演示:\n";
    CPResult R = CriticalPath(G, 0, 8, r1.second);
    DS_CHECK(R.ve[8] == 18);                  // 手算工期 = 18
    vector<int> expectCritical = {0, 3, 6, 7, 9, 10};   // a1,a4,a7,a8,a10,a11（0-based 下标）
    DS_CHECK(R.critical == expectCritical);   // 关键活动集合 = 手算答案
    DS_CHECK(R.length == R.ve[8]);            // 关键路径长度 == ve[汇点]
    cout << "[7.5] 断言通过：拓扑序合法、工期 18、关键活动/路径长度与手算一致\n";
    return 0;
}
// @ENDSECTION
