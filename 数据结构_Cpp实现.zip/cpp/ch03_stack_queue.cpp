// ch03_stack_queue.cpp —— 《数据结构（C 语言版）》第 3 章 栈和队列（C++17 实现）
// 只依赖 ds_common.h + 标准库；每个分节片段可独立阅读；main 做演示 + DS_CHECK 自测。
#include "ds_common.h"

// @SECTION 3.1 | 栈
// 复杂度：各基本操作 O(1)，n 个元素空间 O(n)。教材 SqStack.top 指向「栈顶元素的下一位置」：
// 空栈 top==base、栈长 top-base、栈满 top-base>=stacksize；此处用 0-based 裸数组忠实还原。
constexpr int STACK_INIT_SIZE = 100, STACKINCREMENT = 10;
struct SqStack {
    ElemType* base;   // 栈底指针
    ElemType* top;    // 栈顶指针：指向下一可插入位置
    int stacksize;    // 已分配空间（元素数）
};
Status InitStack(SqStack& S) { S.base = new ElemType[STACK_INIT_SIZE]; S.top = S.base; S.stacksize = STACK_INIT_SIZE; return OK; }
Status ClearStack(SqStack& S) { S.top = S.base; return OK; }
Status DestroyStack(SqStack& S) { delete[] S.base; S.base = S.top = nullptr; S.stacksize = 0; return OK; }
bool   StackEmpty(const SqStack& S) { return S.top == S.base; }
int    StackLength(const SqStack& S) { return int(S.top - S.base); }
Status GetTop(const SqStack& S, ElemType& e) { if (S.top == S.base) return ERROR; e = *(S.top - 1); return OK; }
Status Push(SqStack& S, ElemType e) {
    if (S.top - S.base >= S.stacksize) {                 // 栈满：按教材追加 STACKINCREMENT
        int used = StackLength(S);
        ElemType* nb = new ElemType[S.stacksize + STACKINCREMENT];
        for (int i = 0; i < used; ++i) nb[i] = S.base[i];
        delete[] S.base; S.base = nb; S.top = S.base + used; S.stacksize += STACKINCREMENT;
    }
    *S.top++ = e; return OK;
}
Status Pop(SqStack& S, ElemType& e) { if (S.top == S.base) return ERROR; e = *--S.top; return OK; }

// 链栈：SNode 结点，无头结点，LinkStack 即栈顶指针；Push/Pop 均在表头，O(1)。
struct SNode { ElemType data; SNode* next; };
using LinkStack = SNode*;
Status InitStack(LinkStack& S) { S = nullptr; return OK; }
bool   StackEmpty(const LinkStack& S) { return S == nullptr; }
Status Push(LinkStack& S, ElemType e) { SNode* p = new SNode{e, S}; S = p; return OK; }
Status Pop(LinkStack& S, ElemType& e) { if (!S) return ERROR; SNode* p = S; e = p->data; S = p->next; delete p; return OK; }

// 两栈共享同一数组：栈1 从低端涨(top1,-1 空)、栈2 从高端涨(top2,n 空)；栈满 top1+1==top2。
struct DoubleStack {
    vector<int> space; int top1, top2;
    explicit DoubleStack(int n = 16) : space(n), top1(-1), top2(n) {}
};
bool   DSFull(const DoubleStack& S) { return S.top1 + 1 == S.top2; }
bool   DSEmpty(const DoubleStack& S, int w) { return w == 1 ? S.top1 == -1 : S.top2 == int(S.space.size()); }
Status DSPush(DoubleStack& S, int w, ElemType e) { if (DSFull(S)) return ERROR; (w == 1) ? (S.space[++S.top1] = e) : (S.space[--S.top2] = e); return OK; }
Status DSPop(DoubleStack& S, int w, ElemType& e) {
    if (DSEmpty(S, w)) return ERROR;
    e = (w == 1) ? S.space[S.top1--] : S.space[S.top2++]; return OK;
}
// @ENDSECTION

// @SECTION 3.2.1 | 数制转换
// 复杂度：时间 O(log_d N)，空间 O(log_d N)。原理 N = (N / d) * d + N % d。
// 余数「先算出的低位」与输出顺序相反，正好用栈 LIFO 逆序输出。(1348)10=(2504)8。
// 教材版用 SqStack(见 3.1) + InitStack/Push/Pop/StackEmpty；此处用 STL std::stack<int>，
// 其内部 0-based；对应关系：push→入栈、top+pop→出栈、empty→判空。base 支持 2/8/16，>9 用 A~F。
string conversion(int N, int base) {
    if (N == 0) return "0";
    const char* digits = "0123456789ABCDEF";
    std::stack<int> S;
    while (N > 0) { S.push(N % base); N /= base; }
    string out;
    while (!S.empty()) { out += digits[S.top()]; S.pop(); }   // 先 top 再 pop
    return out;
}
// @ENDSECTION

// @SECTION 3.2.2 | 括号匹配的检验
// 复杂度：时间 O(n)，空间 O(n)（最坏全为左括号）。按「期待的急迫程度」处理：越晚出现的
// 左括弧越先被匹配，故用栈。三类不匹配：①与栈顶不配对 ②栈空遇右括弧(不速之客) ③扫描完栈非空。
// 用 STL std::stack<char>；教材 SqStack 把 char 当作 ElemType，逻辑相同。
bool isLeft(char c) { return c == '(' || c == '[' || c == '{'; }
bool isRight(char c) { return c == ')' || c == ']' || c == '}'; }
bool pairOK(char l, char r) {
    return (l == '(' && r == ')') || (l == '[' && r == ']') || (l == '{' && r == '}');
}
Status matching(const string& exp) {
    std::stack<char> S;
    for (char c : exp) {
        if (isLeft(c)) S.push(c);
        else if (isRight(c)) {
            if (S.empty()) return ERROR;            // ② 右括弧多余
            if (!pairOK(S.top(), c)) return ERROR;  // ① 与栈顶不配对
            S.pop();                                // 先 top 后 pop
        }
    }
    return S.empty() ? OK : ERROR;                  // ③ 结束时栈必须为空
}
// @ENDSECTION

// @SECTION 3.2.3 | 行编辑程序
// 复杂度：时间 O(n)，空间 O(n)。输入用 string 模拟字符流：'#' 退格(删前一字符)、
// '@' 退行(清空本行)、'\n' 行结束；普通字符入栈；行末从栈底→栈顶依次输出即正确文本（教材格式）。
// 用 STL std::stack<char>；为能从栈底输出，出栈暂存后 std::reverse 翻转（教材顺序栈可正序遍历）。
string LineEdit(const string& input) {
    std::stack<char> S;
    string result;                                  // 累积各行正确文本，供 main 断言
    auto flushLine = [&]() {
        string line;
        while (!S.empty()) { line += S.top(); S.pop(); }
        std::reverse(line.begin(), line.end());     // 翻转为 栈底→栈顶
        cout << line << '\n';
        result += line + '\n';
    };
    for (char c : input) {
        if (c == '#') { if (!S.empty()) S.pop(); }
        else if (c == '@') { while (!S.empty()) S.pop(); }
        else if (c == '\n') flushLine();
        else S.push(c);
    }
    if (!S.empty()) flushLine();                    // 处理无换行结尾的最后一行
    return result;
}
// @ENDSECTION

// @SECTION 3.2.4 | 迷宫求解
// 复杂度：时间 O(R·C)（每格至多试探 4 方向），空间 O(R·C)（栈深不超过通道数）。
// 穷举求解 + 回溯：方向序 东→南→西→北；当前位置可通则入栈前进，四周不通则出栈退回换方向。
// 栈元素含「位置 + 下一试探方向 di」；留足迹(置 -1)防走回头路。用 STL std::stack<MazePos>，
// 0-based 坐标；到达出口时栈内自底向顶即一条路径。教材用 SqStack，语义一致。
struct MazePos { int r, c, di; };   // (行,列) 与下一试探方向下标 0..3
bool MazePath(vector<MazePos>& out) {
    constexpr int R = 6, C = 6;
    int maze[R][C] = {                              // 1=墙 0=通道；入口(1,1) 出口(4,4)
        {1,1,1,1,1,1},
        {1,0,0,0,1,1},
        {1,1,1,0,1,1},
        {1,1,1,0,0,1},
        {1,1,1,1,0,1},
        {1,1,1,1,1,1}
    };
    const int dr[4] = {0, 1, 0, -1}, dc[4] = {1, 0, -1, 0};   // 东 南 西 北
    const int sr = 1, sc = 1, er = 4, ec = 4;
    std::stack<MazePos> S;
    maze[sr][sc] = -1;                             // 入口留足迹
    S.push(MazePos{sr, sc, 0});
    while (!S.empty()) {
        MazePos cur = S.top();
        if (cur.r == er && cur.c == ec) {          // 到达出口：栈内即路径
            while (!S.empty()) { out.push_back(S.top()); S.pop(); }
            std::reverse(out.begin(), out.end());   // 翻转为 入口→出口
            return true;
        }
        bool moved = false;
        for (; cur.di < 4; ) {
            int d = cur.di;
            int nr = cur.r + dr[d], nc = cur.c + dc[d];
            ++cur.di;
            S.top().di = cur.di;                   // 写回：回溯后从下一方向继续
            if (nr >= 0 && nr < R && nc >= 0 && nc < C && maze[nr][nc] == 0) {
                maze[nr][nc] = -1;                 // 留足迹
                S.push(MazePos{nr, nc, 0});
                moved = true;
                break;
            }
        }
        if (!moved) S.pop();                       // 四周不通：删去该位置并回溯
    }
    return false;                                  // 退到入口仍无路 → 无通路
}
// @ENDSECTION

// @SECTION 3.2.5 | 表达式求值
// 复杂度：时间 O(n)，空间 O(n)。算符优先法：OPTR(运算符)/OPND(操作数) 双栈。
// 表 3.1 给出 + - * / ( ) # 七算符的栈内/栈外优先关系；核心规则：栈顶优先数 >= 当前则退栈计算。
// Precede(a,b)：a=栈顶(栈内)算符，b=当前读入(栈外)算符，返回 < > = 或空格(非法)。
// 用 STL std::stack；整数除法、多位数按字符累加、先弹的是右操作数，并防除零。
static const char kPrec[7][7] = {
    {'>','>','<','<','<','>','>'},   // +
    {'>','>','<','<','<','>','>'},   // -
    {'>','>','>','>','<','>','>'},   // *
    {'>','>','>','>','<','>','>'},   // /
    {'<','<','<','<','<','=',' '},   // (
    {'>','>','>','>',' ','>','>'},   // )
    {'<','<','<','<','<',' ','='}    // #
};
int op2i(char c) {
    switch (c) {
        case '+': return 0; case '-': return 1; case '*': return 2;
        case '/': return 3; case '(': return 4; case ')': return 5;
        case '#': return 6; default: return -1;
    }
}
char Precede(char a, char b) {
    int i = op2i(a), j = op2i(b);
    if (i < 0 || j < 0) return ' ';
    return kPrec[i][j];
}
int Operate(int a, char theta, int b) {
    switch (theta) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return b == 0 ? 0 : a / b;       // 整数除法，防除零
        default:  return 0;
    }
}
int EvaluateExpression(const string& expr) {
    string s = expr; s.push_back('#');              // 表达式以 # 结束
    std::stack<char> OPTR; OPTR.push('#');          // 栈底预置 #
    std::stack<int>  OPND;
    int i = 0; char c = s[i];
    auto isDigit = [](char x) -> bool { return x >= '0' && x <= '9'; };
    while (!(c == '#' && OPTR.top() == '#')) {
        if (c == ' ') { c = s[++i]; continue; }
        if (isDigit(c)) {
            int val = 0;
            while (isDigit(s[i])) { val = val * 10 + (s[i] - '0'); ++i; }
            OPND.push(val);
            c = s[i];
        } else {
            char rel = Precede(OPTR.top(), c);
            if (rel == '<') { OPTR.push(c); c = s[++i]; }
            else if (rel == '=') { OPTR.pop(); c = s[++i]; }
            else if (rel == '>') {
                if (OPTR.empty() || OPND.size() < 2) return 0;
                char theta = OPTR.top(); OPTR.pop();
                int b = OPND.top(); OPND.pop();     // 先弹右操作数
                int a = OPND.top(); OPND.pop();
                OPND.push(Operate(a, theta, b));
            } else return 0;                        // 表中空格：非法表达式
        }
    }
    return OPND.empty() ? 0 : OPND.top();
}
// @ENDSECTION

// @SECTION 3.3 | 栈与递归的实现
// 复杂度：Hanoi 时间 O(2^n)、递归工作栈空间 O(n)；n! 时间/空间 O(n)。
// 嵌套调用「后调用先返回」，数据区按栈式管理；递归转非递归即用工作栈保存「本层实参+返回地址」
// 模拟递推/回归。0-based 递归深度，与教材一致。hanoi 打印移动步骤并返回步数。
long long hanoi(int n, char x, char y, char z, bool verbose) {
    if (n <= 0) return 0;
    if (n == 1) {
        if (verbose) cout << "  " << x << "->" << z << " 盘1\n";
        return 1;
    }
    long long cnt = hanoi(n - 1, x, z, y, verbose);      // 1..n-1: x -> y
    if (verbose) cout << "  " << x << "->" << z << " 盘" << n << "\n";
    ++cnt;
    cnt += hanoi(n - 1, y, x, z, verbose);              // 1..n-1: y -> z
    return cnt;
}
long long fact(int n) { return n <= 1 ? 1 : n * fact(n - 1); }
long long factNonRec(int n) {
    // 用「递归工作栈」模拟 n!：递推时层层压栈保存实参，到达出口后回归逐层相乘。
    std::stack<int> S;
    for (int k = n; k > 1; --k) S.push(k);              // 递推：压入 n, n-1, ..., 2
    long long r = 1;                                     // 递归出口 n==1 返回 1
    while (!S.empty()) { r *= S.top(); S.pop(); }        // 回归：先 top 再 pop
    return r;
}
// @ENDSECTION

// @SECTION 3.4 | 队列
// 复杂度：各基本操作 O(1)，空间 O(n)。链队列带头结点；删除最后一个元素时须 Q.rear=Q.front(最易漏)。
// 循环队列为 0-based 数组，「少用一个元素空间」区分空满：队满 (rear+1)%MAXQSIZE==front，
// 最多存 MAXQSIZE-1 个元素；队空 front==rear；队长 (rear-front+MAXQSIZE)%MAXQSIZE。
struct QNode { ElemType data; QNode* next; };
struct LinkQueue { QNode* front; QNode* rear; };         // front 指向头结点
Status InitQueue(LinkQueue& Q) { Q.front = Q.rear = new QNode; Q.front->next = nullptr; return OK; }
bool   QueueEmpty(const LinkQueue& Q) { return Q.front == Q.rear; }
Status EnQueue(LinkQueue& Q, ElemType e) {
    QNode* p = new QNode{e, nullptr};                    // 表尾插入
    Q.rear->next = p; Q.rear = p; return OK;
}
Status DeQueue(LinkQueue& Q, ElemType& e) {
    if (Q.front == Q.rear) return ERROR;                // 队空
    QNode* p = Q.front->next; e = p->data;
    Q.front->next = p->next;
    if (Q.rear == p) Q.rear = Q.front;                  // 删尾结点后尾指针回头结点
    delete p; return OK;
}
Status DestroyQueue(LinkQueue& Q) {
    while (Q.front) { Q.rear = Q.front->next; delete Q.front; Q.front = Q.rear; }
    return OK;
}
constexpr int MAXQSIZE = 100;
struct SqQueue { ElemType* base; int front; int rear; };
Status InitQueue(SqQueue& Q) { Q.base = new ElemType[MAXQSIZE]; Q.front = Q.rear = 0; return OK; }
int  QueueLength(const SqQueue& Q) { return (Q.rear - Q.front + MAXQSIZE) % MAXQSIZE; }
bool QueueEmpty(const SqQueue& Q) { return Q.front == Q.rear; }
Status EnQueue(SqQueue& Q, ElemType e) {
    if ((Q.rear + 1) % MAXQSIZE == Q.front) return ERROR;   // 判满：牺牲一个单元
    Q.base[Q.rear] = e; Q.rear = (Q.rear + 1) % MAXQSIZE; return OK;
}
Status DeQueue(SqQueue& Q, ElemType& e) {
    if (Q.front == Q.rear) return ERROR;                     // 判空
    e = Q.base[Q.front]; Q.front = (Q.front + 1) % MAXQSIZE; return OK;
}
Status DestroyQueue(SqQueue& Q) { delete[] Q.base; Q.base = nullptr; Q.front = Q.rear = 0; return OK; }
// @ENDSECTION

// @SECTION 3.5 | 离散事件模拟
// 复杂度：时间 O(m log m)（m=事件数，事件表用优先队列小顶堆），空间 O(n)。
// 银行两窗口：客户按到达时刻入「最短队列」，窗口空闲立即服务并生成离开事件；离开时累计逗留时间。
// 平均逗留时间 = 累计逗留 / 客户数。用固定到达/服务时间，规模小、结果可断言非负。
struct BankEvent { int time, kind, win, arrive, dur; };   // kind: 0 到达 / 1 离开
struct EventCmp {                                        // 小顶堆：按发生时刻升序
    bool operator()(const BankEvent& a, const BankEvent& b) const { return a.time > b.time; }
};
double BankSimulation(const vector<int>& arrive, const vector<int>& dur) {
    std::priority_queue<BankEvent, vector<BankEvent>, EventCmp> ev;
    for (int i = 0; i < int(arrive.size()); ++i)
        ev.push(BankEvent{arrive[i], 0, -1, arrive[i], dur[i]});
    std::queue<BankEvent> q[2];                         // 两个窗口的等待队列
    bool busy[2] = {false, false};
    double totalStay = 0; int done = 0;
    while (!ev.empty()) {
        BankEvent e = ev.top(); ev.pop();
        if (e.kind == 0) {                              // 到达事件
            int w = (q[0].size() <= q[1].size()) ? 0 : 1;   // 排入最短队列
            q[w].push(e);
            if (!busy[w]) {                          // 窗口空闲：队头立即接受服务
                busy[w] = true;
                BankEvent c = q[w].front(); q[w].pop();
                ev.push(BankEvent{e.time + c.dur, 1, w, c.arrive, c.dur});
            }
        } else {                                     // 离开事件
            totalStay += e.time - e.arrive;          // 逗留 = 离开 - 到达
            ++done;
            int w = e.win;
            if (!q[w].empty()) {                     // 队列还有人：为下一客户生成离开事件
                BankEvent c = q[w].front(); q[w].pop();
                ev.push(BankEvent{e.time + c.dur, 1, w, c.arrive, c.dur});
            } else busy[w] = false;                  // 窗口转为空闲
        }
    }
    return done ? totalStay / done : 0.0;
}
// @ENDSECTION

// @SECTION 3.6 | 杨辉三角
// 复杂度：时间 O(n^2)，空间 O(n)。第 i-1 行系数两侧补 0，则第 i 行 b[j]=a[j-1]+a[j]；
// 用 0 作「行界值」入队，队列长度约 n+2。教材用 SqQueue(3.4 的循环队列)逐行输出，此处为
// 保持片段自含改用 STL std::queue 复现同一「0 哨兵」逻辑（0-based 行索引）。
// 第 k 行(0 起始)系数和 = 2^k，main 中逐行校验。
vector<vector<int>> yanghui(int n) {
    vector<vector<int>> rows;
    std::queue<int> Q;
    Q.push(0);                                       // 行界值 0 入队
    Q.push(1);                                       // 第 1 行的系数
    for (int i = 1; i <= n; ++i) {
        Q.push(0);
        vector<int> row;
        int e = 0;
        do {
            int s = Q.front(); Q.pop();               // DeQueue：取上一行左邻
            e = Q.front();                           // GetHead：读队头(右邻)不删除
            if (e) row.push_back(e);                 // 非 0 为系数；0 为行结束
            Q.push(s + e);                          // 生成下一行系数(含行界 0)
        } while (e != 0);
        rows.push_back(row);
        for (int x : row) cout << x << ' ';          // 按教材格式逐行输出
        cout << '\n';
    }
    return rows;
}
// @ENDSECTION

int main() {
    {
        Demo d("3.1 栈：SqStack / LinkStack / 双栈共享");
        SqStack S{}; InitStack(S);
        for (int i = 1; i <= 5; ++i) Push(S, i);
        ElemType e = 0;
        DS_CHECK(GetTop(S, e) == OK && e == 5);
        DS_CHECK(StackLength(S) == 5 && !StackEmpty(S));
        vector<int> v;
        while (Pop(S, e) == OK) v.push_back(e);
        std::reverse(v.begin(), v.end());
        printSeq(v, "SqStack 底->顶");
        DestroyStack(S);

        LinkStack LS{}; InitStack(LS);
        Push(LS, 10); Push(LS, 20); Push(LS, 30);
        DS_CHECK(Pop(LS, e) == OK && e == 30);
        DS_CHECK(Pop(LS, e) == OK && e == 20);
        DS_CHECK(Pop(LS, e) == OK && e == 10);
        DS_CHECK(StackEmpty(LS));
        cout << "LinkStack 弹出: 30 20 10\n";

        DoubleStack DS(6);
        DS_CHECK(DSPush(DS, 1, 1) == OK);
        DS_CHECK(DSPush(DS, 1, 2) == OK);
        DS_CHECK(DSPush(DS, 2, 9) == OK);
        DS_CHECK(DSPush(DS, 2, 8) == OK);
        int a = 0, b = 0;
        DS_CHECK(DSPop(DS, 1, a) == OK && a == 2);
        DS_CHECK(DSPop(DS, 2, b) == OK && b == 8);
        cout << "双栈共享 top1=" << DS.top1 << " top2=" << DS.top2 << " 未越界\n";
    }
    {
        Demo d("3.2 栈的应用");
        DS_CHECK(conversion(1348, 8) == "2504");
        DS_CHECK(conversion(10, 2) == "1010");
        DS_CHECK(conversion(255, 16) == "FF");
        cout << "数制转换: 1348->(8)" << conversion(1348, 8)
             << " 10->(2)" << conversion(10, 2)
             << " 255->(16)" << conversion(255, 16) << '\n';

        DS_CHECK(matching("[()]") == OK);
        DS_CHECK(matching("[(])") == ERROR);
        DS_CHECK(matching("())") == ERROR);
        DS_CHECK(matching("(()") == ERROR);
        cout << "括号匹配(1=OK,0=ERR): [()] " << matching("[()]")
             << " [(]) " << matching("[(])")
             << " ()) " << matching("())")
             << " (() " << matching("(()") << '\n';

        string r = LineEdit("abc##d\nef@GH\n");
        DS_CHECK(r == "ad\nGH\n");

        vector<MazePos> path;
        DS_CHECK(MazePath(path));
        DS_CHECK(!path.empty());
        DS_CHECK(path.front().r == 1 && path.front().c == 1);
        DS_CHECK(path.back().r == 4 && path.back().c == 4);
        cout << "迷宫路径: ";
        for (const auto& p : path) cout << "(" << p.r << "," << p.c << ")";
        cout << '\n';

        DS_CHECK(EvaluateExpression("3+4*5") == 23);
        DS_CHECK(EvaluateExpression("(3+4)*5") == 35);
        DS_CHECK(EvaluateExpression("100/3*2+5") == 71);
        cout << "表达式: 3+4*5=" << EvaluateExpression("3+4*5")
             << " (3+4)*5=" << EvaluateExpression("(3+4)*5")
             << " 100/3*2+5=" << EvaluateExpression("100/3*2+5") << '\n';
    }
    {
        Demo d("3.3 递归与栈模拟");
        cout << "Hanoi(2) 移动步骤:\n";
        long long steps2 = hanoi(2, 'A', 'B', 'C', true);
        DS_CHECK(steps2 == 3);
        for (int n = 1; n <= 6; ++n)
            DS_CHECK(hanoi(n, 'A', 'B', 'C', false) == (1LL << n) - 1);
        DS_CHECK(fact(5) == 120 && fact(6) == 720);
        DS_CHECK(factNonRec(5) == 120 && factNonRec(6) == 720);
        cout << "阶乘 5!=" << fact(5) << " 非递归 5!=" << factNonRec(5)
             << " Hanoi(3)=" << hanoi(3, 'A', 'B', 'C', false) << '\n';
    }
    {
        Demo d("3.4 链队列与循环队列");
        LinkQueue LQ{}; InitQueue(LQ);
        for (int i = 1; i <= 4; ++i) EnQueue(LQ, i);
        ElemType x = 0;
        vector<int> got;
        while (DeQueue(LQ, x) == OK) got.push_back(x);
        vector<int> expect = {1, 2, 3, 4};
        DS_CHECK(got == expect);
        printSeq(got, "链队列出队");
        DS_CHECK(QueueEmpty(LQ));
        DestroyQueue(LQ);

        SqQueue SQ{}; InitQueue(SQ);
        for (int i = 1; i <= MAXQSIZE - 1; ++i) DS_CHECK(EnQueue(SQ, i) == OK);
        DS_CHECK(QueueLength(SQ) == MAXQSIZE - 1);
        DS_CHECK(EnQueue(SQ, 999) == ERROR);            // 少用一个单元：满
        DS_CHECK(DeQueue(SQ, x) == OK && x == 1);
        DestroyQueue(SQ);
        cout << "循环队列 MAXQSIZE=" << MAXQSIZE << " 最多存 "
             << MAXQSIZE - 1 << " 个(少用一个单元判满)\n";
    }
    {
        Demo d("3.5 离散事件模拟：银行两窗口");
        vector<int> arrive = {0, 1, 3, 4, 8};
        vector<int> dur    = {5, 3, 2, 4, 1};
        double avg = BankSimulation(arrive, dur);
        DS_CHECK(avg >= 0.0);
        cout << "平均逗留时间 = " << avg << " (客户数 " << arrive.size() << ")\n";
    }
    {
        Demo d("3.6 杨辉三角（循环队列）");
        int n = 5;
        vector<vector<int>> rows = yanghui(n);
        DS_CHECK(int(rows.size()) == n);
        for (int k = 0; k < n; ++k) {
            int sum = 0;
            for (int x : rows[k]) sum += x;
            DS_CHECK(sum == (1 << k));                   // 第 k 行(0 起始)系数和 = 2^k
        }
        cout << "各行系数和 = 1,2,4,8,16 = 2^k，校验通过\n";
    }
    return 0;
}
