#include "ds_common.h"

// ch07_graph.cpp ——《数据结构(C 语言版)》第 7 章「图」配套实现(C++17 单文件)。
// 约定: 顶点统一采用 0-based 编号(0..n-1), 权值为 int, INF_COST 表无穷。
// 全文件只依赖 C++17 标准库; include 与 main 均置于所有 @SECTION 段之外。

// @SECTION 7.2.1 | 邻接矩阵
// 0-based 顶点编号: 顶点 0..n-1; arcs[i][j] 存权值, INF_COST 表示无穷(无边)。
// 复杂度: CreateUDN / CreateDN 为 O(n^2 + e), PrintMatrix 为 O(n^2)。
// 边表项: 起点 u, 终点 v, 权值 w, 均 0-based; 给默认值避免未初始化变量。
struct Edge {
    int u, v, w;
    Edge(int uu = 0, int vv = 0, int ww = 0) : u(uu), v(vv), w(ww) {}
};
using EdgeList = vector<Edge>;

// 邻接矩阵图: n 个顶点, arcs 为 n*n 矩阵, 对角线置 0。
struct MGraph {
    int n = 0;                        // 顶点数, 编号 0..n-1
    vector<vector<int>> arcs;         // 邻接矩阵; INF_COST 表示无穷
    explicit MGraph(int n_ = 0)
        : n(n_), arcs(n_, vector<int>(n_, INF_COST)) {
        for (int i = 0; i < n_; ++i) arcs[i][i] = 0;
    }
};

// 无向带权网: 每条边对称写入 arcs[u][v] 与 arcs[v][u]。
void CreateUDN(MGraph& G, int n, const EdgeList& edges) {
    G = MGraph(n);
    for (const auto& e : edges)
        if (e.u >= 0 && e.u < n && e.v >= 0 && e.v < n) {
            G.arcs[e.u][e.v] = e.w;
            G.arcs[e.v][e.u] = e.w;
        }
}

// 有向带权网: 仅按方向写入 arcs[u][v]。
void CreateDN(MGraph& G, int n, const EdgeList& edges) {
    G = MGraph(n);
    for (const auto& e : edges)
        if (e.u >= 0 && e.u < n && e.v >= 0 && e.v < n)
            G.arcs[e.u][e.v] = e.w;
}

// 打印邻接矩阵: 无穷用 "INF" 占位, 列宽 5 便于对齐。
void PrintMatrix(const MGraph& G) {
    for (int i = 0; i < G.n; ++i) {
        for (int j = 0; j < G.n; ++j)
            if (G.arcs[i][j] >= INF_COST) cout << std::setw(5) << "INF";
            else cout << std::setw(5) << G.arcs[i][j];
        cout << '\n';
    }
}
// @ENDSECTION

// @SECTION 7.2.2 | 邻接表
// 0-based 顶点编号: adj[i] 存顶点 i 的所有出边 <邻接点, 权值>。
// 复杂度: CreateALGraph 为 O(n + e), Indegree 为 O(n + e)。
using std::pair;                      // 使 pair<int,int> 可直接书写

struct ALGraph {
    int n = 0;                                  // 顶点数, 编号 0..n-1
    vector<vector<pair<int,int>>> adj;          // 邻接表: pair=(邻接点, 权值)
    explicit ALGraph(int n_ = 0) : n(n_), adj(n_) {}
};

// 由边表构造邻接表; directed=false 时同时加入反向弧(用于无向图)。
void CreateALGraph(ALGraph& G, int n, const EdgeList& edges,
                   bool directed = true) {
    G = ALGraph(n);
    for (const auto& e : edges) {
        if (e.u < 0 || e.u >= n || e.v < 0 || e.v >= n) continue;
        G.adj[e.u].emplace_back(e.v, e.w);
        if (!directed) G.adj[e.v].emplace_back(e.u, e.w);
    }
}

// 求各顶点入度(有向图): 统计每条弧终点出现的次数。
vector<int> Indegree(const ALGraph& G) {
    vector<int> indeg(G.n, 0);
    for (int u = 0; u < G.n; ++u)
        for (const auto& p : G.adj[u])
            if (p.first >= 0 && p.first < G.n) ++indeg[p.first];
    return indeg;
}
// @ENDSECTION

// @SECTION 7.3 | 图的遍历
// 0-based 顶点编号; visited[0..n-1] 标记是否已访问。
// 复杂度: 邻接表下 DFS/BFS 与连通分量计数均为 O(n + e)(邻接矩阵为 O(n^2))。
// 从 v 出发递归深度优先遍历(内部辅助函数)。
static void DFS(const ALGraph& G, int v, vector<int>& visited,
                vector<int>& seq) {
    visited[v] = 1;
    seq.push_back(v);
    for (const auto& p : G.adj[v]) {
        int w = p.first;
        if (w >= 0 && w < G.n && !visited[w]) DFS(G, w, visited, seq);
    }
}

// 深度优先遍历(非连通图也访问全部顶点), 返回访问序列。
vector<int> DFSTraverse(const ALGraph& G) {
    vector<int> visited(G.n, 0), seq;
    for (int v = 0; v < G.n; ++v)
        if (!visited[v]) DFS(G, v, visited, seq);
    return seq;
}

// 广度优先遍历(非连通图也访问全部顶点), 返回访问序列。
vector<int> BFSTraverse(const ALGraph& G) {
    vector<int> visited(G.n, 0), seq;
    std::queue<int> Q;
    for (int s = 0; s < G.n; ++s) {
        if (visited[s]) continue;
        visited[s] = 1;
        Q.push(s);
        while (!Q.empty()) {
            int v = Q.front(); Q.pop();
            seq.push_back(v);
            for (const auto& p : G.adj[v]) {
                int w = p.first;
                if (w >= 0 && w < G.n && !visited[w]) {
                    visited[w] = 1;
                    Q.push(w);
                }
            }
        }
    }
    return seq;
}

// 连通分量个数(无向图): 每启动一次 BFS 即找到一个分量。
int ConnectedComponentCount(const ALGraph& G) {
    vector<int> visited(G.n, 0);
    int cnt = 0;
    std::queue<int> Q;
    for (int s = 0; s < G.n; ++s) {
        if (visited[s]) continue;
        ++cnt;
        visited[s] = 1;
        Q.push(s);
        while (!Q.empty()) {
            int v = Q.front(); Q.pop();
            for (const auto& p : G.adj[v]) {
                int w = p.first;
                if (w >= 0 && w < G.n && !visited[w]) {
                    visited[w] = 1;
                    Q.push(w);
                }
            }
        }
    }
    return cnt;
}
// @ENDSECTION

// @SECTION 7.4 | 最小生成树
// 0-based 顶点编号; 两算法均作用于连通带权无向网 MGraph。
// 复杂度: PRIM O(n^2); KRUSKAL O(e log e)(并查集近似 O(1))。
// 教材 closedge[]: adjvex 为树内一侧顶点, lowcost 为当前最小边权(0 表示已入树)。
struct CloseEdge {
    int adjvex = 0;
    int lowcost = INF_COST;
};

// 并查集: 路径压缩 + 按秩合并, 用于 KRUSKAL 判环。
struct UnionFind {
    vector<int> parent, rankv;
    explicit UnionFind(int n) : parent(n), rankv(n, 0) {
        for (int i = 0; i < n; ++i) parent[i] = i;
    }
    int Find(int x) { return parent[x] == x ? x : (parent[x] = Find(parent[x])); }
    bool Union(int a, int b) {
        int ra = Find(a), rb = Find(b);
        if (ra == rb) return false;
        if (rankv[ra] < rankv[rb]) std::swap(ra, rb);
        parent[rb] = ra;
        if (rankv[ra] == rankv[rb]) ++rankv[ra];
        return true;
    }
};

// PRIM: 从 start 出发, 打印选中边并返回最小生成树总权值。
int MiniSpanTree_PRIM(const MGraph& G, int start = 0) {
    int n = G.n;
    vector<CloseEdge> closedge(n);
    for (int v = 0; v < n; ++v) {
        closedge[v].adjvex = start;
        closedge[v].lowcost = G.arcs[start][v];
    }
    closedge[start].lowcost = 0;
    int total = 0;
    for (int k = 1; k < n; ++k) {
        int minc = INF_COST, pick = -1;
        for (int v = 0; v < n; ++v)
            if (closedge[v].lowcost > 0 && closedge[v].lowcost < minc) {
                minc = closedge[v].lowcost; pick = v;
            }
        if (pick == -1) return total;          // 非连通, 提前结束
        cout << "PRIM 选边: " << closedge[pick].adjvex << " - " << pick
             << " (w=" << minc << ")\n";
        total += minc;
        closedge[pick].lowcost = 0;
        for (int v = 0; v < n; ++v)
            if (G.arcs[pick][v] < closedge[v].lowcost) {
                closedge[v].lowcost = G.arcs[pick][v];
                closedge[v].adjvex = pick;
            }
    }
    return total;
}

// KRUSKAL: 边按权升序, 借并查集取不成环的 n-1 条边, 返回总权值。
int MiniSpanTree_KRUSKAL(const MGraph& G, const EdgeList& edges) {
    int n = G.n;
    EdgeList es = edges;                       // 副本排序, 不改原边表
    std::sort(es.begin(), es.end(),
              [](const Edge& a, const Edge& b) { return a.w < b.w; });
    UnionFind uf(n);
    int total = 0, cnt = 0;
    for (const auto& e : es) {
        if (e.u < 0 || e.u >= n || e.v < 0 || e.v >= n) continue;
        if (uf.Union(e.u, e.v)) {
            cout << "KRUSKAL 选边: " << e.u << " - " << e.v
                 << " (w=" << e.w << ")\n";
            total += e.w;
            if (++cnt == n - 1) break;
        }
    }
    return total;
}
// @ENDSECTION

// @SECTION 7.5 | 拓扑排序与关键路径
// 0-based 顶点编号; AOE 网中弧权表示活动持续时间。
// 复杂度: TopologicalSort O(n + e), CriticalPath O(n + e)。
// 拓扑排序: 入度 + 栈; 有环返回 false; 顺带求事件最早发生时间 ve。
bool TopologicalSort(const ALGraph& G, vector<int>& topo, vector<int>& ve) {
    int n = G.n;
    vector<int> indeg = Indegree(G);
    std::stack<int> S;                        // 教材用栈暂存入度为 0 的顶点
    ve.assign(n, 0);
    topo.clear();
    for (int i = 0; i < n; ++i)
        if (indeg[i] == 0) S.push(i);
    int cnt = 0;
    while (!S.empty()) {
        int u = S.top(); S.pop();
        topo.push_back(u);
        ++cnt;
        for (const auto& p : G.adj[u]) {
            int v = p.first, w = p.second;
            if (v < 0 || v >= n) continue;
            if (ve[u] + w > ve[v]) ve[v] = ve[u] + w;
            if (--indeg[v] == 0) S.push(v);
        }
    }
    return cnt == n;                          // cnt < n 说明存在环
}

// 关键路径(AOE): ve 由拓扑排序得, vl 逆拓扑序求最迟发生时间;
// e=ve[u], l=vl[v]-w, e==l 即关键活动; 返回工期(关键路径长度)。
int CriticalPath(const ALGraph& G) {
    int n = G.n;
    vector<int> topo, ve;
    if (!TopologicalSort(G, topo, ve)) {
        cout << "AOE 网存在环, 无法求关键路径\n";
        return -1;
    }
    int duration = 0;
    for (int x : ve) if (x > duration) duration = x;
    vector<int> vl(n, duration);              // 最迟发生时间初始化为工期
    for (int i = n - 1; i >= 0; --i) {       // 逆拓扑序
        int u = topo[i];
        for (const auto& p : G.adj[u]) {
            int v = p.first, w = p.second;
            if (v < 0 || v >= n) continue;
            if (vl[v] - w < vl[u]) vl[u] = vl[v] - w;
        }
    }
    cout << "关键活动(e==l): ";
    for (int u = 0; u < n; ++u)
        for (const auto& p : G.adj[u]) {
            int v = p.first, w = p.second;
            if (v < 0 || v >= n) continue;
            int e = ve[u], l = vl[v] - w;
            if (e == l) cout << u << "->" << v << ' ';
        }
    cout << "\n工期(关键路径长度)=" << duration << '\n';
    return duration;
}
// @ENDSECTION

// @SECTION 7.6 | 最短路径
// 0-based 顶点编号; DIJ 单源 O(n^2), FLOYD 全源 O(n^3), 路径还原 O(L)。
// FLOYD 距离用 long long 与大 INFLL, 避免 INF 相加溢出; P 为前驱矩阵。
constexpr long long INFLL = std::numeric_limits<long long>::max() / 4;
struct DijResult { vector<int> dist, prev; };  // dist:距离(INF_COST 不可达), prev:前驱

// DIJ: 教材 S 集, 逐次选当前最短点并松弛, 返回距离与前驱。
DijResult ShortestPath_DIJ(const MGraph& G, int v0) {
    int n = G.n;
    DijResult R;
    R.dist.assign(n, INF_COST);
    R.prev.assign(n, -1);
    vector<int> S(n, 0);
    if (v0 < 0 || v0 >= n) return R;
    R.dist[v0] = 0;
    for (int i = 0; i < n; ++i) {
        int u = -1, best = INF_COST;
        for (int v = 0; v < n; ++v)
            if (!S[v] && R.dist[v] < best) { best = R.dist[v]; u = v; }
        if (u == -1) break;                   // 剩余顶点均不可达
        S[u] = 1;
        for (int v = 0; v < n; ++v) {
            if (S[v] || v == u || G.arcs[u][v] >= INF_COST) continue;
            long long nd = (long long)R.dist[u] + G.arcs[u][v];
            if (nd < R.dist[v]) { R.dist[v] = (int)nd; R.prev[v] = u; }
        }
    }
    return R;
}

// FLOYD: D 全源距离; P[i][j] 为 i->j 最短路中 j 的前驱(教材 P[v][w])。
vector<vector<long long>> ShortestPath_FLOYD(const MGraph& G,
                                            vector<vector<int>>& P) {
    int n = G.n;
    vector<vector<long long>> D(n, vector<long long>(n, INFLL));
    P.assign(n, vector<int>(n, -1));
    for (int i = 0; i < n; ++i) {
        D[i][i] = 0;
        for (int j = 0; j < n; ++j)
            if (i != j && G.arcs[i][j] < INF_COST) {
                D[i][j] = G.arcs[i][j]; P[i][j] = i;
            }
    }
    for (int k = 0; k < n; ++k)
        for (int i = 0; i < n; ++i) {
            if (D[i][k] >= INFLL) continue;
            for (int j = 0; j < n; ++j) {
                if (D[k][j] >= INFLL) continue;
                long long nd = D[i][k] + D[k][j];
                if (nd < D[i][j]) { D[i][j] = nd; P[i][j] = P[k][j]; }
            }
        }
    return D;
}

// 路径还原打印: 由前驱数组(DIJ 的 prev 或 FLOYD 的 P 行)回溯到起点。
void PrintPath(const vector<int>& pre, int src, int dst, const string& tag) {
    int n = (int)pre.size();
    if (src < 0 || src >= n || dst < 0 || dst >= n ||
        (src != dst && pre[dst] < 0)) {
        cout << tag << " 路径 " << src << " -> " << dst << ": 不可达\n";
        return;
    }
    vector<int> path;
    int cur = dst;
    while (cur >= 0 && cur < n && (int)path.size() < n) {
        path.push_back(cur);
        if (cur == src) break;
        cur = pre[cur];
    }
    std::reverse(path.begin(), path.end());
    cout << tag << " 路径 " << src << " -> " << dst << ": ";
    for (int x : path) cout << x << ' ';
    cout << '\n';
}
// @ENDSECTION

int main() {
    // 全部顶点 0-based 编号; 下列边表用于各算法自测。
    // (1) 连通带权无向网 Gudn: 5 顶点, 最小生成树总权值已知为 14。
    EdgeList udnEdges = {
        {0,1,2}, {1,2,3}, {2,3,4}, {3,4,5},
        {0,2,7}, {1,3,8}, {2,4,9}, {0,4,20}
    };
    MGraph Gudn;
    CreateUDN(Gudn, 5, udnEdges);

    // (2) 有向带权网 Gdn: 6 顶点, v0=0 的单源最短路已知答案。
    EdgeList dnEdges = {
        {0,2,10}, {0,4,30}, {0,5,100}, {1,2,5},
        {2,3,50}, {3,5,10}, {4,3,20}, {4,5,60}
    };
    MGraph Gdn;
    CreateDN(Gdn, 6, dnEdges);

    // (3) AOE 网(有向无环): 6 个事件, 关键路径长度已知为 12。
    EdgeList aoeEdges = {
        {0,1,3}, {0,2,2}, {1,3,4}, {2,3,1},
        {1,4,5}, {2,4,3}, {3,5,2}, {4,5,4}
    };
    ALGraph Gaoe;
    CreateALGraph(Gaoe, 6, aoeEdges, true);

    // (4) 有环有向图: 拓扑排序应返回 false。
    EdgeList cycEdges = {{0,1,1}, {1,2,1}, {2,0,1}};
    ALGraph Gcyc;
    CreateALGraph(Gcyc, 3, cycEdges, true);

    {
        Demo d("7.2 邻接矩阵与邻接表");
        cout << "邻接矩阵(INF 表无穷):\n";
        PrintMatrix(Gudn);
        ALGraph Gal;
        CreateALGraph(Gal, 5, udnEdges, false);   // 无向图邻接表
        vector<int> indeg = Indegree(Gal);
        int sum = 0;
        for (int x : indeg) sum += x;
        DS_CHECK((int)indeg.size() == 5);
        DS_CHECK(sum == 16);                      // 8 条边, 入度和 = 2*8
    }

    {
        Demo d("7.3 遍历与连通分量");
        EdgeList discEdges = {{0,1,1}, {1,2,1}, {3,4,1}};
        ALGraph Gdisc;
        CreateALGraph(Gdisc, 6, discEdges, false); // 含孤立点 5
        vector<int> dfs = DFSTraverse(Gdisc);
        vector<int> bfs = BFSTraverse(Gdisc);
        printSeq(dfs, "DFS");
        printSeq(bfs, "BFS");
        DS_CHECK((int)dfs.size() == 6);
        DS_CHECK((int)bfs.size() == 6);
        DS_CHECK(ConnectedComponentCount(Gdisc) == 3);
    }

    {
        Demo d("7.4 最小生成树");
        int wp = MiniSpanTree_PRIM(Gudn, 0);
        int wk = MiniSpanTree_KRUSKAL(Gudn, udnEdges);
        cout << "PRIM 总权值=" << wp << ", KRUSKAL 总权值=" << wk << '\n';
        DS_CHECK(wp == 14);
        DS_CHECK(wk == 14);
        DS_CHECK(wp == wk);
    }

    {
        Demo d("7.5 拓扑排序与关键路径");
        vector<int> topo, ve;
        bool ok = TopologicalSort(Gaoe, topo, ve);
        printSeq(topo, "拓扑序");
        DS_CHECK(ok);
        DS_CHECK((int)topo.size() == 6);
        vector<int> pos(6, -1);                   // 校验拓扑序合法性
        for (int i = 0; i < 6; ++i) pos[topo[i]] = i;
        for (const auto& e : aoeEdges) DS_CHECK(pos[e.u] < pos[e.v]);
        bool cycOk = TopologicalSort(Gcyc, topo, ve);
        DS_CHECK(!cycOk);
        int cp = CriticalPath(Gaoe);
        DS_CHECK(cp == 12);
    }

    {
        Demo d("7.6 最短路径");
        DijResult R = ShortestPath_DIJ(Gdn, 0);
        vector<vector<int>> P;
        vector<vector<long long>> Df = ShortestPath_FLOYD(Gdn, P);
        vector<int> known = {0, INF_COST, 10, 50, 30, 60};
        printSeq(R.dist, "DIJ 距离");
        for (int j = 0; j < 6; ++j) {
            DS_CHECK(R.dist[j] == known[j]);
            if (known[j] >= INF_COST) DS_CHECK(Df[0][j] >= INFLL);
            else DS_CHECK(Df[0][j] == known[j]);
            if (R.dist[j] < INF_COST) DS_CHECK(R.dist[j] == Df[0][j]);
        }
        PrintPath(R.prev, 0, 5, "DIJ");
        PrintPath(P[0], 0, 5, "FLOYD");
    }

    cout << "全部自测通过\n";
    return 0;
}
