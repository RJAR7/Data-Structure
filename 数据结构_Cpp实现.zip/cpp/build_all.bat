@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>nul
cd /d "%~dp0"

rem ==== 1) 选择编译器：优先 Dev-C++ 自带 MinGW，其次 PATH 里的 g++/clang++ ====
set "CXX="
set "STD=c++11"

rem 常见 Dev-C++ 5 / Dev-C++ 6 安装路径（含 32/64 位、C/D 盘）
for %%p in (
  "D:\Program Files (x86)\Dev-Cpp\MinGW64\bin\g++.exe"
  "C:\Program Files (x86)\Dev-Cpp\MinGW64\bin\g++.exe"
  "D:\Program Files\Dev-Cpp\MinGW64\bin\g++.exe"
  "C:\Program Files\Dev-Cpp\MinGW64\bin\g++.exe"
  "C:\Dev-Cpp\MinGW64\bin\g++.exe"
  "D:\Program Files (x86)\Dev-Cpp\MinGW32\bin\g++.exe"
  "C:\Program Files (x86)\Dev-Cpp\MinGW32\bin\g++.exe"
) do (
  if not defined CXX if exist %%p set "CXX=%%~p"
)

rem 注册表中反查 Dev-C++ 安装位置
if not defined CXX (
  for /f "tokens=2,*" %%a in ('reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" /s /f Dev-Cpp 2^>nul ^| findstr /i InstallLocation') do (
    if exist "%%b\MinGW64\bin\g++.exe" set "CXX=%%b\MinGW64\bin\g++.exe"
  )
)
if not defined CXX (
  for /f "tokens=2,*" %%a in ('reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall" /s /f Dev-Cpp 2^>nul ^| findstr /i InstallLocation') do (
    if exist "%%b\MinGW64\bin\g++.exe" set "CXX=%%b\MinGW64\bin\g++.exe"
  )
)

rem 退回 PATH
if not defined CXX (
  where g++ >nul 2>nul && set "CXX=g++"
)
if not defined CXX (
  where clang++ >nul 2>nul && set "CXX=clang++"
)

if not defined CXX (
  echo [ERROR] 未找到 C++ 编译器。请安装 Dev-C++，或把 g++/clang++ 加入 PATH。
  echo        也支持 MSVC：cl /EHsc /std:c++11 chXX.cpp
  pause
  exit /b 1
)

echo ============================================================
echo  编译器: %CXX%
echo  标准  : -%STD%  (Dev-C++ 5.11 / g++ 4.9.2 兼容；新编译器亦可用)
echo  说明  : 逐个编译并运行 23 个章节/示例程序，断言失败会中止
echo ============================================================
echo.

set "FAIL=0"
for %%f in (ch*.cpp) do (
  echo ===== 编译并运行 %%~nf =====
  "!CXX!" -std=%STD% -O2 -Wall -UNDEBUG "%%f" -o "%%~nf.exe"
  if errorlevel 1 (
    echo [编译失败] %%f
    set "FAIL=1"
  ) else (
    "%%~nf.exe"
    if errorlevel 1 (
      echo [运行/断言失败] %%f
      set "FAIL=1"
    )
  )
)

echo.
if "!FAIL!"=="0" (
  echo ========== ALL OK：全部编译运行通过 ==========
) else (
  echo ========== 有失败项，请查看上方 error ========
)
pause
exit /b !FAIL!
