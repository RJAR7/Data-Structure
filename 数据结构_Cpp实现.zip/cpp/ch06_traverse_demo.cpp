// ch06_traverse_demo.cpp —— 教材 6.3.1「遍历二叉树」完整可编译示例
// 编译：g++ -std=c++17 -O2 ch06_traverse_demo.cpp -o traverse && ./traverse
// 说明：与 ch07_prim_demo.cpp 风格一致，整段为一个 @SECTION，复制即可编译运行。
// @SECTION 6.3.1 | 完整可编译示例：二叉树遍历与重建
#include "ds_common.h"
#include <iomanip>

// ---------- 二叉链表存储（教材 6.2.3）----------
struct BiTNode {
    char data = '\0';
    BiTNode* lchild = nullptr;
    BiTNode* rchild = nullptr;
    explicit BiTNode(char d) : data(d) {}
};
using BiTree = BiTNode*;

// 把 vector<char> 拼成 string，便于逐步打印与断言比较
string ToStr(const vector<char>& v) { return string(v.begin(), v.end()); }

// 教材算法 6.4：按「带 # 空标记的先序序列」递归建立二叉链表。
// 读一个字符：'#' 表示空子树，否则建根并递归建左、右子树。
BiTree CreateBiTree(const string& s, size_t& pos) {
    if (pos >= s.size()) return nullptr;          // 递归基：序列耗尽判空
    char ch = s[pos++];
    if (ch == '#') return nullptr;                // 递归基：空标记判空
    BiTree T = new BiTNode(ch);
    T->lchild = CreateBiTree(s, pos);
    T->rchild = CreateBiTree(s, pos);
    return T;
}

// ---------- 四种遍历：访问序列收进 vector<char> ----------
void PreOrder(BiTree T, vector<char>& out) {
    if (!T) return;                               // 递归基判空
    out.push_back(T->data);
    PreOrder(T->lchild, out);
    PreOrder(T->rchild, out);
}
void InOrder(BiTree T, vector<char>& out) {
    if (!T) return;                               // 递归基判空
    InOrder(T->lchild, out);
    out.push_back(T->data);
    InOrder(T->rchild, out);
}
void PostOrder(BiTree T, vector<char>& out) {
    if (!T) return;                               // 递归基判空
    PostOrder(T->lchild, out);
    PostOrder(T->rchild, out);
    out.push_back(T->data);
}

// 层序：用队列，顺带简要打印「出队访问 / 入队孩子」的进出过程
void LevelOrder(BiTree T, vector<char>& out) {
    if (!T) return;                               // 递归基判空
    std::queue<BiTree> Q;
    Q.push(T);
    cout << "    入队根 " << T->data << "\n";
    while (!Q.empty()) {
        BiTree p = Q.front(); Q.pop();
        out.push_back(p->data);
        cout << "    出队访问 " << p->data;
        if (p->lchild) { Q.push(p->lchild); cout << " | 入队左孩子 " << p->lchild->data; }
        if (p->rchild) { Q.push(p->rchild); cout << " | 入队右孩子 " << p->rchild->data; }
        cout << "\n";
    }
}

// 非递归中序：std::stack 模拟递归，沿左链入栈再转向右子树
void InOrderIter(BiTree T, vector<char>& out) {
    std::stack<BiTree> S;
    BiTree p = T;
    while (p || !S.empty()) {
        while (p) { S.push(p); p = p->lchild; }
        p = S.top(); S.pop();
        out.push_back(p->data);
        p = p->rchild;
    }
}

// 深度 = 左右子树最大深度 + 1；叶子 = 左右孩子皆空的结点
int BiTreeDepth(BiTree T) {
    if (!T) return 0;                             // 递归基判空
    int ld = BiTreeDepth(T->lchild), rd = BiTreeDepth(T->rchild);
    return (ld > rd ? ld : rd) + 1;
}
int CountLeaves(BiTree T) {
    if (!T) return 0;                             // 递归基判空
    if (!T->lchild && !T->rchild) return 1;
    return CountLeaves(T->lchild) + CountLeaves(T->rchild);
}

// 由先序 + 中序重建（教材 6.3.1 习题思想）：先序定根，中序分左右区间。
// pl..pr / il..ir 均为闭区间；每层打印「根 = X，左区间 = …，右区间 = …」。
BiTree BuildTreeFromPreIn(const string& pre, int pl, int pr,
                          const string& ino, int il, int ir, int depth) {
    if (pl > pr) return nullptr;                  // 递归基：区间为空
    char root = pre[pl];
    int k = il;
    while (ino[k] != root) ++k;                   // 在中序区间里定位根
    int leftLen = k - il;
    cout << string(2 * depth, ' ') << "根 = " << root
         << "，左区间 = " << ino.substr(il, leftLen)
         << "，右区间 = " << ino.substr(k + 1, ir - k) << "\n";
    BiTree T = new BiTNode(root);
    T->lchild = BuildTreeFromPreIn(pre, pl + 1, pl + leftLen, ino, il, k - 1, depth + 1);
    T->rchild = BuildTreeFromPreIn(pre, pl + leftLen + 1, pr, ino, k + 1, ir, depth + 1);
    return T;
}

// 后序释放全部结点（main 结束前调用，避免内存泄漏）
void DestroyBiTree(BiTree& T) {
    if (!T) return;                               // 递归基判空
    DestroyBiTree(T->lchild);
    DestroyBiTree(T->rchild);
    delete T;
    T = nullptr;
}

int main() {
    Demo demo("6.3.1 二叉树遍历与重建完整示例（先序 ABC##DE#G##F###，7 结点）");

    // 教材经典二叉树的带 # 先序串，共 7 个字母结点
    const string def = "ABC##DE#G##F###";
    size_t pos = 0;
    BiTree T = CreateBiTree(def, pos);
    DS_CHECK(pos == def.size());                  // 15 个字符应恰好全部消耗
    cout << "由先序串 " << def << " 建树完成\n";

    cout << "\n[一] 递归遍历的访问序列\n";
    vector<char> a, b, c, d;
    PreOrder(T, a); InOrder(T, b); PostOrder(T, c);
    printSeq(a, "  先序 PreOrder ");
    printSeq(b, "  中序 InOrder ");
    printSeq(c, "  后序 PostOrder");
    cout << "  层序队列进出过程（简要）：\n";
    LevelOrder(T, d);
    printSeq(d, "  层序 LevelOrder");

    cout << "\n[二] 非递归中序（std::stack）\n";
    vector<char> e;
    InOrderIter(T, e);
    printSeq(e, "  中序(非递归)");

    cout << "\n[三] 深度与叶子数（std::setw 表格）\n";
    int dep = BiTreeDepth(T), leaf = CountLeaves(T);
    cout << "  " << std::setw(10) << "项目" << std::setw(8) << "计算值"
         << std::setw(8) << "手算值" << "\n";
    cout << "  " << std::setw(10) << "深度" << std::setw(8) << dep
         << std::setw(8) << 5 << "\n";
    cout << "  " << std::setw(10) << "叶子数" << std::setw(8) << leaf
         << std::setw(8) << 3 << "\n";

    cout << "\n[四] 由先序 + 中序重建（打印每层递归区间）\n";
    string preS = ToStr(a), inoS = ToStr(b);
    cout << "  先序 = " << preS << "，中序 = " << inoS << "\n";
    BiTree R = BuildTreeFromPreIn(preS, 0, (int)preS.size() - 1,
                                  inoS, 0, (int)inoS.size() - 1, 0);
    vector<char> rp, ri;
    PreOrder(R, rp); InOrder(R, ri);
    cout << "  重建树先序 = " << ToStr(rp) << "，中序 = " << ToStr(ri) << "\n";

    // 断言：四种遍历 == 手算答案（注释给出手算序列）
    DS_CHECK(ToStr(a) == "ABCDEGF");              // 手算先序 A B C D E G F
    DS_CHECK(ToStr(b) == "CBEGDFA");              // 手算中序 C B E G D F A
    DS_CHECK(ToStr(c) == "CGEFDBA");              // 手算后序 C G E F D B A
    DS_CHECK(ToStr(d) == "ABCDEFG");              // 手算层序 A B C D E F G
    DS_CHECK(ToStr(e) == ToStr(b));               // 非递归中序 == 递归中序 CBEGDFA
    DS_CHECK(ToStr(rp) == preS && ToStr(ri) == inoS); // 重建树先序/中序与原树一致
    DS_CHECK(dep == 5);                           // 手算最长路径 A-B-D-E-G 共 5 层
    DS_CHECK(leaf == 3);                          // 手算叶子 C、G、F 共 3 个

    cout << "\n[6.3.1] 断言通过：四序/非递归中序/重建/深度=5/叶子=3 全部吻合\n";

    DestroyBiTree(R);                             // 释放重建树 new 出的结点
    DestroyBiTree(T);                             // 释放原树 new 出的结点
    cout << "  DestroyBiTree 已释放两棵树的全部结点\n";
    return 0;
}
// @ENDSECTION
