// ch05_array_matrix.cpp —— 《数据结构（C 语言版）》第 5 章：数组与矩阵的压缩存储（C++17）
// 编译：g++ -std=c++17 -O2 -Wall ch05_array_matrix.cpp -o ch05 && ./ch05
// 约定：数组与矩阵下标内部统一 0-based；教材 1-based 公式处显式做 +1 转换并注释。
#include "ds_common.h"
#include <utility>

// @SECTION 5.2 | n 维数组 Array 与地址计算（InitArray / Locate / Value / Assign）
// 教材 n 维数组含 dims/bounds/constants；内存一维，按行序为主序（低下标优先）映象。
// LOC(j1..jn)=LOC(0..0)+Σ ci·ji，cn=L=1，c(i-1)=bi·ci；此处 L=1，off 即相对地址（单位：元素）。
struct Array {
    ElemType* base = nullptr;                 // 元素存储区
    int dim = 0;
    int* bounds = nullptr;                    // bounds[i]：第 i+1 维长度 bi（0-based 下标 0..bi-1）
    int* constants = nullptr;                 // constants[i] = ci
    Array() = default;
    Array(const Array&) = delete; Array& operator=(const Array&) = delete;  // 含裸指针，禁拷贝防重复释放
    void Destroy() {
        delete[] base; delete[] bounds; delete[] constants;
        base = nullptr; bounds = nullptr; constants = nullptr; dim = 0;
    }
    ~Array() { Destroy(); }
};
Status InitArray(Array& A, const vector<int>& b) {   // 教材变参 bounds 用 vector 传入
    A.Destroy();
    A.dim = (int)b.size();
    if (A.dim <= 0) return ERROR;
    long long total = 1;
    A.bounds = new int[A.dim];
    for (int i = 0; i < A.dim; ++i) {
        if (b[i] <= 0) { A.Destroy(); return ERROR; }
        A.bounds[i] = b[i]; total *= b[i];
    }
    A.base = new ElemType[(size_t)total]();          // 值初始化为 0
    A.constants = new int[A.dim];
    A.constants[A.dim - 1] = 1;                      // cn = L = 1
    for (int i = A.dim - 2; i >= 0; --i)
        A.constants[i] = A.bounds[i + 1] * A.constants[i + 1];   // c(i-1)=bi·ci（行优先）
    return OK;
}
Status DestroyArray(Array& A) { A.Destroy(); return OK; }
Status Locate(const Array& A, const vector<int>& idx, int& off) {
    if ((int)idx.size() != A.dim) return ERROR;
    off = 0;
    for (int i = 0; i < A.dim; ++i) {
        if (idx[i] < 0 || idx[i] >= A.bounds[i]) return ERROR;
        off += A.constants[i] * idx[i];               // Σ ci·ji
    }
    return OK;
}
Status Value(const Array& A, ElemType& e, const vector<int>& idx) {
    int off = 0; if (Locate(A, idx, off) != OK) return ERROR;
    e = A.base[off]; return OK;
}
Status Assign(Array& A, ElemType e, const vector<int>& idx) {
    int off = 0; if (Locate(A, idx, off) != OK) return ERROR;
    A.base[off] = e; return OK;
}
// 复杂度：InitArray O(dim + 各维乘积)（清零），Locate/Value/Assign 均 O(dim) 即随机存取；空间 O(各维乘积)。
// @ENDSECTION

// @SECTION 5.3.1 | 特殊矩阵压缩（一）：对称矩阵与上/下三角矩阵
// 教材下标从 1 起、压缩数组 sa 从 0 起存。k(i,j)=i(i-1)/2+j-1（i>=j，按行存下三角）即 0-based 下标。
// 入参 (r,c) 为 0-based，进公式前统一 +1 转成 1-based：i=r+1，j=c+1。
struct SymMatrix {
    int n; vector<ElemType> sa;                    // sa[n(n+1)/2]
    explicit SymMatrix(int n_) : n(n_), sa((size_t)n_ * (n_ + 1) / 2, 0) {}
    static int k(int i, int j) {                    // i,j 为 1-based
        if (i < j) std::swap(i, j);                 // 对称：上三角折回下三角
        return i * (i - 1) / 2 + j - 1;            // 0-based 数组下标
    }
    ElemType Value(int r, int c) const { return sa[k(r + 1, c + 1)]; }
    void Assign(int r, int c, ElemType e) { sa[k(r + 1, c + 1)] = e; }
};
// 三角矩阵：变量区为下三角（lower 为真）或上三角（lower 为假），其余为同一常数，另加 sa 末单元存该常数。
// 上三角复用 k（交换后以列为主序压缩），与下三角按行存次序不同，但同为一一映象。
struct TriMatrix {
    int n; bool lower; vector<ElemType> sa;        // sa[N] 存常数，N=n(n+1)/2；sa[0..N-1] 存变量区
    TriMatrix(int n_, bool lo) : n(n_), lower(lo), sa((size_t)n_ * (n_ + 1) / 2 + 1, 0) {}
    bool inVar(int r, int c) const { return lower ? (r >= c) : (r <= c); }   // 对应 1-based i>=j 或 i<=j
    ElemType Value(int r, int c) const {
        return inVar(r, c) ? sa[SymMatrix::k(r + 1, c + 1)] : sa.back();
    }
    void Assign(int r, int c, ElemType e) {
        if (inVar(r, c)) sa[SymMatrix::k(r + 1, c + 1)] = e;
        else sa.back() = e;                        // 常数区：赋任一位置即改该常数
    }
};
// 复杂度：Value/Assign 均 O(1)；空间 O(n^2/2)，较普通 n^2 省约一半。
// @ENDSECTION

// @SECTION 5.3.1 | 特殊矩阵压缩（二）：三对角矩阵与对角矩阵
// 三对角：仅 |i-j|<=1（1-based）处可非零，按行存 3n-2 个单元，教材 k=2i+j-3 即 0-based 下标。
struct TriDiagMatrix {
    int n; vector<ElemType> sa;                    // sa[3n-2]
    explicit TriDiagMatrix(int n_) : n(n_), sa((size_t)(3 * n_ - 2), 0) {}
    ElemType Value(int r, int c) const {
        int i = r + 1, j = c + 1, d = i - j; if (d < 0) d = -d;   // 0-based -> 1-based
        if (d > 1) return 0;                       // 带外恒为 0
        return sa[2 * i + j - 3];                  // k=2i+j-3，范围 0..3n-3
    }
    void Assign(int r, int c, ElemType e) {
        int i = r + 1, j = c + 1, d = i - j; if (d < 0) d = -d;
        if (d > 1) return;                         // 带外不存，赋值忽略（恒为 0）
        sa[2 * i + j - 3] = e;
    }
};
// 对角矩阵（主对角线之外全 0）：只需 n 个单元，是分布最稀疏的特例。
struct DiagMatrix {
    int n; vector<ElemType> sa;                    // sa[n]
    explicit DiagMatrix(int n_) : n(n_), sa((size_t)n_, 0) {}
    ElemType Value(int r, int c) const { return (r == c) ? sa[r] : 0; }
    void Assign(int r, int c, ElemType e) { if (r == c) sa[r] = e; }
};
// 复杂度：Value/Assign 均 O(1)；空间 O(3n) 与 O(n)，远小于 n^2。
// @ENDSECTION

// @SECTION 5.3.2 | 稀疏矩阵三元组表：创建、普通转置与打印
// Triple 的 i,j 均 1-based（教材）；data[0] 未用，data[1..tu] 按行序优先。用 vector 代替定长数组自动管理。
struct Triple {
    int i = 0, j = 0; ElemType e = 0;
    // C++11 下带 NSDMI 的类不是聚合体；补非 explicit 构造函数以支持
    //   Triple{...}、vector<Triple>{{...}}、push_back({...}) 与 data[q] = {...}
    Triple(int i_ = 0, int j_ = 0, ElemType e_ = 0) : i(i_), j(j_), e(e_) {}
};
struct TSMatrix {
    vector<Triple> data;                          // data[0] 预留不用
    int mu = 0, nu = 0, tu = 0;
};
Status CreateSMatrix(TSMatrix& M, const vector<vector<ElemType>>& a) {
    M.mu = (int)a.size(); M.nu = M.mu ? (int)a[0].size() : 0; M.tu = 0;
    M.data.assign(1, Triple{0, 0, 0});
    for (int r = 0; r < M.mu; ++r)
        for (int c = 0; c < M.nu; ++c)
            if (a[r][c] != 0) { M.data.push_back({r + 1, c + 1, a[r][c]}); ++M.tu; } // 0-based -> 1-based
    return OK;
}
// 普通转置：按 M 的列号从小到大扫描三元组表，结果仍按行序有序。
Status TransposeSMatrix(const TSMatrix& M, TSMatrix& T) {
    T.mu = M.nu; T.nu = M.mu; T.tu = M.tu;
    T.data.assign(1, Triple{0, 0, 0});
    for (int col = 1; col <= M.nu; ++col)
        for (int p = 1; p <= M.tu; ++p)
            if (M.data[p].j == col)
                T.data.push_back({M.data[p].j, M.data[p].i, M.data[p].e});
    return OK;
}
void PrintSMatrix(const TSMatrix& M, const string& tip = "") {
    if (!tip.empty()) cout << tip << ": ";
    cout << "mu=" << M.mu << " nu=" << M.nu << " tu=" << M.tu << " | ";
    for (int t = 1; t <= M.tu; ++t)
        cout << "(" << M.data[t].i << "," << M.data[t].j << "," << M.data[t].e << ")";
    cout << '\n';
}
// 复杂度：CreateSMatrix O(mu*nu)，TransposeSMatrix O(nu*tu)，Print O(tu)；空间 O(tu)。
// @ENDSECTION

// @SECTION 5.3.2 | 稀疏矩阵：快速转置 FastTransposeSMatrix 与加法 AddSMatrix
// 快速转置：num[col] 统计每列非零元数，cpot[col] 为该列第一个非零元在 T.data 中的起始位置。
Status FastTransposeSMatrix(const TSMatrix& M, TSMatrix& T) {
    T.mu = M.nu; T.nu = M.mu; T.tu = M.tu;
    T.data.assign(M.tu + 1, Triple{0, 0, 0});     // 预分配，按 cpot 随机写入
    if (T.tu) {
        vector<int> num(M.nu + 1, 0);
        for (int t = 1; t <= M.tu; ++t) ++num[M.data[t].j];
        vector<int> cpot(M.nu + 2, 0);
        cpot[1] = 1;
        for (int col = 2; col <= M.nu; ++col) cpot[col] = cpot[col - 1] + num[col - 1];
        for (int p = 1; p <= M.tu; ++p) {
            int col = M.data[p].j, q = cpot[col]++;
            T.data[q] = {M.data[p].j, M.data[p].i, M.data[p].e};
        }
    }
    return OK;
}
// 加法 Q=M+N：按行序线性位置 (i-1)*nu+j 归并两个有序三元组表，和为 0 的项不存入。
Status AddSMatrix(const TSMatrix& M, const TSMatrix& N, TSMatrix& Q) {
    if (M.mu != N.mu || M.nu != N.nu) return ERROR;
    Q.mu = M.mu; Q.nu = M.nu; Q.tu = 0;
    Q.data.assign(1, Triple{0, 0, 0});
    int p = 1, q = 1;
    while (p <= M.tu && q <= N.tu) {
        int pm = (M.data[p].i - 1) * M.nu + M.data[p].j;
        int pn = (N.data[q].i - 1) * N.nu + N.data[q].j;
        if (pm < pn) { Q.data.push_back(M.data[p]); ++p; }
        else if (pm > pn) { Q.data.push_back(N.data[q]); ++q; }
        else {
            ElemType sum = M.data[p].e + N.data[q].e;
            if (sum != 0) Q.data.push_back({M.data[p].i, M.data[p].j, sum});
            ++p; ++q;
        }
    }
    while (p <= M.tu) { Q.data.push_back(M.data[p]); ++p; }
    while (q <= N.tu) { Q.data.push_back(N.data[q]); ++q; }
    Q.tu = (int)Q.data.size() - 1;
    return OK;
}
// 复杂度：快速转置 O(nu+tu)，AddSMatrix O(tuM+tuN)；空间 O(nu+tu)。
// @ENDSECTION

// @SECTION 5.3.2 | 稀疏矩阵乘法 MultSMatrix（行逻辑联接 RLSMatrix）
// 行逻辑联接：rpos[row] 为第 row 行第一个非零元在 data 中的序号，rpos[mu+1]=tu+1 作哨兵。
struct RLSMatrix {
    vector<Triple> data; int mu = 0, nu = 0, tu = 0;
    vector<int> rpos;                              // rpos[1..mu+1]，索引 0 不用
};
void BuildRPos(RLSMatrix& M) {
    M.rpos.assign(M.mu + 2, M.tu + 1);
    vector<int> num(M.mu + 1, 0);
    for (int t = 1; t <= M.tu; ++t) ++num[M.data[t].i];
    M.rpos[1] = 1;
    for (int row = 2; row <= M.mu + 1; ++row) M.rpos[row] = M.rpos[row - 1] + num[row - 1];
}
RLSMatrix ToRL(const TSMatrix& T) {
    RLSMatrix R; R.data = T.data; R.mu = T.mu; R.nu = T.nu; R.tu = T.tu; BuildRPos(R); return R;
}
// Q=M×N：逐行用 ctemp 累加，只存非零结果，不做 0 乘 0 的无效运算。
Status MultSMatrix(const RLSMatrix& M, const RLSMatrix& N, RLSMatrix& Q) {
    if (M.nu != N.mu) return ERROR;
    Q.mu = M.mu; Q.nu = N.nu; Q.tu = 0;
    Q.data.assign(1, Triple{0, 0, 0});
    if (M.tu == 0 || N.tu == 0) { BuildRPos(Q); return OK; }
    vector<ElemType> ctemp(N.nu + 1, 0);
    for (int arow = 1; arow <= M.mu; ++arow) {
        std::fill(ctemp.begin(), ctemp.end(), 0);
        for (int p = M.rpos[arow]; p < M.rpos[arow + 1]; ++p) {
            int nrow = M.data[p].j;                // 对应 N 的行号
            for (int q = N.rpos[nrow]; q < N.rpos[nrow + 1]; ++q)
                ctemp[N.data[q].j] += M.data[p].e * N.data[q].e;
        }
        for (int ccol = 1; ccol <= N.nu; ++ccol)
            if (ctemp[ccol] != 0) { Q.data.push_back({arow, ccol, ctemp[ccol]}); ++Q.tu; }
    }
    BuildRPos(Q);
    return OK;
}
vector<vector<ElemType>> ToDense(const RLSMatrix& Q) {
    vector<vector<ElemType>> d(Q.mu, vector<ElemType>(Q.nu, 0));
    for (int t = 1; t <= Q.tu; ++t) d[Q.data[t].i - 1][Q.data[t].j - 1] = Q.data[t].e;
    return d;
}
// 复杂度：时间 O(M.mu*N.nu + M.tu*N.tu/N.mu)（教材），空间 O(N.nu + Q.tu)。
// @ENDSECTION

// @SECTION 5.3.2OL | 十字链表 CrossList（创建、打印与内存释放）
// 每个非零元同时链入行循环链表与列循环链表；rhead/chead 为 1-based 头指针数组，各指向一个哨兵头结点。
struct OLNode {
    int i = 0, j = 0; ElemType e = 0;
    OLNode* right = nullptr; OLNode* down = nullptr;   // 同行后继、同列后继
};
struct CrossList {
    int mu = 0, nu = 0, tu = 0;
    vector<OLNode*> rhead, chead;                      // 索引 0 不用，大小 mu+1 与 nu+1
    void Clear() {
        for (int r = 1; r <= mu; ++r) {                // 只按行环释放数据结点，每个结点唯一归属一行
            OLNode* h = rhead[r]; if (!h) continue;
            for (OLNode* p = h->right; p != h; ) { OLNode* nx = p->right; delete p; p = nx; }
            h->right = h;
        }
        for (int c = 1; c <= nu; ++c) if (chead[c]) chead[c]->down = chead[c];  // 列头复位，避免悬垂
        for (int r = 1; r <= mu; ++r) delete rhead[r];
        for (int c = 1; c <= nu; ++c) delete chead[c];
        rhead.clear(); chead.clear(); mu = nu = tu = 0;
    }
    ~CrossList() { Clear(); }
};
Status CreateSMatrix_OL(CrossList& M, const vector<vector<ElemType>>& a) {
    M.Clear();
    M.mu = (int)a.size(); M.nu = M.mu ? (int)a[0].size() : 0;
    M.rhead.assign(M.mu + 1, nullptr); M.chead.assign(M.nu + 1, nullptr);
    for (int r = 1; r <= M.mu; ++r) { M.rhead[r] = new OLNode(); M.rhead[r]->right = M.rhead[r]; }
    for (int c = 1; c <= M.nu; ++c) { M.chead[c] = new OLNode(); M.chead[c]->down = M.chead[c]; }
    vector<OLNode*> rt = M.rhead, ct = M.chead;        // 行/列当前尾结点，保证 O(tu) 插入
    for (int i = 0; i < M.mu; ++i)
        for (int j = 0; j < M.nu; ++j)
            if (a[i][j] != 0) {
                OLNode* p = new OLNode(); p->i = i + 1; p->j = j + 1; p->e = a[i][j];  // 0-based -> 1-based
                p->right = M.rhead[i + 1]; rt[i + 1]->right = p; rt[i + 1] = p;        // 行环尾插
                p->down = M.chead[j + 1]; ct[j + 1]->down = p; ct[j + 1] = p;          // 列环尾插
                ++M.tu;
            }
    return OK;
}
void PrintSMatrix_OL(const CrossList& M, const string& tip = "") {
    if (!tip.empty()) cout << tip << ": ";
    cout << "mu=" << M.mu << " nu=" << M.nu << " tu=" << M.tu << " | ";
    for (int r = 1; r <= M.mu; ++r)
        for (OLNode* p = M.rhead[r]->right; p != M.rhead[r]; p = p->right)
            cout << "(" << p->i << "," << p->j << "," << p->e << ")";
    cout << '\n';
}
int OLColumnCount(const CrossList& M) {              // 沿列循环链遍历，验证列环完整
    int cnt = 0;
    for (int c = 1; c <= M.nu; ++c)
        for (OLNode* p = M.chead[c]->down; p != M.chead[c]; p = p->down) ++cnt;
    return cnt;
}
// 复杂度：CreateSMatrix_OL O(mu*nu + tu)，打印与遍历 O(tu)，Clear O(mu+nu+tu)；空间 O(mu+nu+tu)。
// @ENDSECTION

int main() {
    {
        Demo d("5.2 n 维数组地址计算(行优先公式验证)");
        Array A;
        vector<int> dims{3, 2, 4};
        DS_CHECK(InitArray(A, dims) == OK);
        vector<int> ci(A.constants, A.constants + A.dim);
        printSeq(ci, "ci 行优先权");                           // 应为 8 4 1
        DS_CHECK(ci[0] == 8 && ci[1] == 4 && ci[2] == 1);
        vector<int> idx{1, 1, 2};
        int off = 0; ElemType e = 0;
        Status s1 = Locate(A, idx, off);                      // 教材例题：1*8+1*4+2=14
        Status s2 = Assign(A, 1028, idx);                    // 基址 1000 + 14*2 = 1028
        Status s3 = Value(A, e, idx);
        DS_CHECK(s1 == OK && off == 14 && s2 == OK && s3 == OK && e == 1028);
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 2; ++j)
                for (int k = 0; k < 4; ++k) {
                    int o = i * 8 + j * 4 + k;               // 手算 Σ ci·ji
                    vector<int> ix{i, j, k};
                    int got = 0; ElemType v = 0;
                    Status a1 = Locate(A, ix, got);
                    Status a2 = Assign(A, 1000 + o * 2, ix);
                    Status a3 = Value(A, v, ix);
                    DS_CHECK(a1 == OK && got == o && a2 == OK && a3 == OK && v == 1000 + o * 2);
                }
        // 二维 2 行 3 列：行优先 LOC=b2*i+j=3i+j，列优先 LOC=b1*j+i=2j+i（基址 0，L=1）
        for (int i = 0; i < 2; ++i) {
            cout << "二维 i=" << i << " 行优先:";
            for (int j = 0; j < 3; ++j) cout << " " << (3 * i + j);
            cout << " | 列优先:";
            for (int j = 0; j < 3; ++j) cout << " " << (2 * j + i);
            cout << "\n";
        }
        DS_CHECK(DestroyArray(A) == OK);
    }
    {
        Demo d("5.3.1 特殊矩阵压缩(读写往返断言)");
        SymMatrix sym(4);
        sym.Assign(2, 0, 7); DS_CHECK(sym.Value(2, 0) == 7 && sym.Value(0, 2) == 7);  // 对称
        sym.Assign(0, 2, 9); DS_CHECK(sym.Value(2, 0) == 9);                          // 同一单元
        TriMatrix low(4, true), up(4, false);
        low.Assign(0, 0, 1); low.Assign(3, 1, 5); low.Assign(0, 3, 8);               // 上三角赋常数 8
        DS_CHECK(low.Value(0, 0) == 1 && low.Value(3, 1) == 5 && low.Value(1, 3) == 8);
        up.Assign(0, 3, 6); up.Assign(3, 0, 2);                                       // 下三角赋常数 2
        DS_CHECK(up.Value(0, 3) == 6 && up.Value(3, 0) == 2 && up.Value(2, 0) == 2);
        TriDiagMatrix td(4);
        td.Assign(0, 0, 1); td.Assign(0, 1, 2); td.Assign(1, 0, 3); td.Assign(3, 3, 4);
        DS_CHECK(td.Value(0, 1) == 2 && td.Value(1, 0) == 3 && td.Value(3, 3) == 4);
        td.Assign(3, 0, 99); DS_CHECK(td.Value(3, 0) == 0);                           // 带外恒为 0
        DiagMatrix dg(4); dg.Assign(2, 2, 5);
        DS_CHECK(dg.Value(2, 2) == 5 && dg.Value(2, 0) == 0);
        cout << "四类特殊矩阵(对称/上下三角/三对角/对角)读写往返断言全部通过\n";
    }
    {
        Demo d("5.3.2 稀疏矩阵三元组表:转置/快速转置/加/乘");
        vector<vector<ElemType>> a = {{1, 0, 3}, {0, 0, 5}, {0, 7, 0}};
        TSMatrix M, T, FT, TT, ADD;
        DS_CHECK(CreateSMatrix(M, a) == OK && M.mu == 3 && M.nu == 3 && M.tu == 4);
        DS_CHECK(TransposeSMatrix(M, T) == OK);
        DS_CHECK(FastTransposeSMatrix(M, FT) == OK);
        DS_CHECK(T.tu == FT.tu);
        for (int t = 1; t <= T.tu; ++t)
            DS_CHECK(T.data[t].i == FT.data[t].i && T.data[t].j == FT.data[t].j && T.data[t].e == FT.data[t].e);
        vector<vector<ElemType>> aT = {{1, 0, 0}, {0, 0, 7}, {3, 5, 0}};   // a 的普通转置
        Status st = CreateSMatrix(TT, aT);
        DS_CHECK(st == OK && FT.tu == TT.tu);
        for (int t = 1; t <= FT.tu; ++t)
            DS_CHECK(FT.data[t].i == TT.data[t].i && FT.data[t].j == TT.data[t].j && FT.data[t].e == TT.data[t].e);
        DS_CHECK(AddSMatrix(M, M, ADD) == OK && ADD.tu == 4 && ADD.data[1].e == 2);
        // 乘法：2x2 矩阵 A 乘 B，期望结果 19 22 与 43 50
        TSMatrix A2, B2;
        Status c1 = CreateSMatrix(A2, {{1, 2}, {3, 4}});
        Status c2 = CreateSMatrix(B2, {{5, 6}, {7, 8}});
        DS_CHECK(c1 == OK && c2 == OK);
        RLSMatrix Q;
        Status mp = MultSMatrix(ToRL(A2), ToRL(B2), Q);
        DS_CHECK(mp == OK);
        vector<vector<ElemType>> dense = ToDense(Q);
        DS_CHECK(dense[0][0] == 19 && dense[0][1] == 22 && dense[1][0] == 43 && dense[1][1] == 50);
        PrintSMatrix(M, "M");
        PrintSMatrix(FT, "FT 快速转置");
        PrintSMatrix(ADD, "M+M");
        cout << "乘法 Q = [" << dense[0][0] << "," << dense[0][1] << "; " << dense[1][0] << "," << dense[1][1] << "]\n";
    }
    {
        Demo d("5.3.2OL 十字链表 CrossList");
        CrossList L;
        Status s1 = CreateSMatrix_OL(L, {{1, 0, 3}, {0, 0, 5}, {0, 7, 0}});
        DS_CHECK(s1 == OK && L.mu == 3 && L.nu == 3 && L.tu == 4);
        DS_CHECK(OLColumnCount(L) == L.tu);                 // 列循环链完整
        PrintSMatrix_OL(L, "OL 行序");
        Status s2 = CreateSMatrix_OL(L, {{0, 2}, {9, 0}});// 重建一次，验证 Clear 不重复释放
        DS_CHECK(s2 == OK && L.tu == 2 && OLColumnCount(L) == 2);
        cout << "十字链表重建后 tu=" << L.tu << " | 行/列循环链与内存释放均正确\n";
    }
    cout << "第 5 章:全部 DS_CHECK 通过\n";
    return 0;
}
