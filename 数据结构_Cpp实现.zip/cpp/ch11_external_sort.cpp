// ch11_external_sort.cpp —— 《数据结构(C语言版)》第 11 章「外部排序」配套实现（课件补充）
// 本机不真读写磁盘,全部用内存容器模拟外存:
//   deque<int>            ≈ 磁带/磁盘上的「大文件」顺序流（读写指针）
//   vector<vector<int>>   ≈ 磁盘上存放的若干「顺串文件」
//   vector<deque<int>>    ≈ 多路归并时的输入/输出缓冲区（磁带机）
// 全局对应:败者树 k 个叶子 == 最小堆 k 个元素,冠军 ls[0] == 堆顶;
//   Adjust(沿叶到根单路径 O(log k)) == 堆「取最小 + 一次上滤」,详见 11.3 / 11.4.
#include "ds_common.h"
#include <algorithm>
#include <cstddef>
#include <deque>
#include <functional>
#include <iostream>
#include <limits>
#include <queue>
#include <utility>
#include <vector>

using std::deque;   // ds_common.h 已 using std::vector / cout / endl 等

// @SECTION 11.2 | 外部排序的方法
// 2 路平衡归并:切段 -> 内部排序生成初始顺串 -> 逐趟两两归并至 1 个顺串.
// 时间:内部排序 O(R*m*log m),每趟归并 O(N),共 O(log2 R) 趟,合计 O(N log2 R).
// 空间:内存工作区 O(m),外存 O(N);I/O 以「记录读/写累计」估计,生成与各趟均读 N 写 N.
// 以 vector<vector<int>>,deque<int> 分别模拟磁盘顺串文件与磁带大文件,不落盘.
// 从输入流取至多 m 条,内部排序后写成一个初始顺串（输入缓冲 + 内部排序 + 输出）
static vector<int> MakeInitialRun(deque<int>& input, size_t m) {
    vector<int> buf;
    while (!input.empty() && buf.size() < m) {
        buf.push_back(input.front());
        input.pop_front();
    }
    std::sort(buf.begin(), buf.end());
    return buf;
}

// 两个有序顺串的 2 路归并
static vector<int> MergeTwo(const vector<int>& a, const vector<int>& b) {
    vector<int> out;
    out.reserve(a.size() + b.size());
    size_t i = 0, j = 0;
    while (i < a.size() && j < b.size()) {
        if (a[i] <= b[j]) out.push_back(a[i++]);
        else out.push_back(b[j++]);
    }
    while (i < a.size()) out.push_back(a[i++]);
    while (j < b.size()) out.push_back(b[j++]);
    return out;
}

struct TwoWayStat {
    int passes = 0;        // 归并趟数
    long long io = 0;      // 估计 I/O 次数（记录读/写累计）
};

// 切段生成初始顺串,再做 2 路平衡归并直至只剩 1 个顺串
static TwoWayStat ExternalSortTwoWay(const vector<int>& data, size_t memCap,
                                     vector<int>& sorted) {
    deque<int> input(data.begin(), data.end());   // 模拟磁带大文件
    vector<vector<int>> runs;                     // 模拟磁盘顺串文件集合
    long long io = 0;
    while (!input.empty()) {
        vector<int> r = MakeInitialRun(input, memCap);
        io += static_cast<long long>(r.size()) * 2;   // 读 + 写
        runs.push_back(std::move(r));
    }
    cout << "[11.2] 初始顺串个数 = " << runs.size()
         << ", 生成阶段估计 I/O 约 " << io << "\n";
    TwoWayStat st;
    int pass = 0;
    while (runs.size() > 1) {
        vector<vector<int>> next;
        long long passIo = 0;
        for (size_t i = 0; i < runs.size(); i += 2) {
            if (i + 1 < runs.size()) {
                vector<int> m = MergeTwo(runs[i], runs[i + 1]);
                passIo += static_cast<long long>(m.size()) * 2;   // 读两串 + 写新串
                next.push_back(std::move(m));
            } else {
                passIo += static_cast<long long>(runs[i].size()) * 2;  // 落单串复制
                next.push_back(std::move(runs[i]));
            }
        }
        runs.swap(next);
        io += passIo;
        ++pass;
        cout << "[11.2] 第 " << pass << " 趟归并: 顺串个数 = " << runs.size()
             << ", 本趟估计 I/O 约 " << passIo << ", 累计约 " << io << "\n";
    }
    st.passes = pass;
    st.io = io;
    if (runs.empty()) sorted.clear();
    else sorted = std::move(runs[0]);
    return st;
}
// @ENDSECTION

// @SECTION 11.3 | 败者树与多路平衡归并
// 败者树 <=> 最小堆:k 个叶子 == 堆的 k 个元素,冠军 ls[0] == 堆顶(最小关键字);
//   ls[1..k-1] 存内部结点「败者」(较大者),胜者(较小者)继续上溯;
//   Adjust 沿「叶->根」单路径比较,恰 O(log k),等价于堆「取最小 + 一次上滤」.
// 时间:建树 O(k),每选一个关键字 O(log k),归并 N 个记录 O(N log k);空间 O(k).
// b[i]=第 i 串当前关键字;b[k]=极小虚叶子(仅建树用);MAXKEY 标记某串已读完.
struct LoserTree {
    static constexpr int MAXKEY = std::numeric_limits<int>::max();
    static constexpr int MINKEY = std::numeric_limits<int>::min();
    int k = 0;
    vector<int> ls;   // ls[0]=冠军串号;ls[1..k-1]=内部结点败者串号
    vector<int> b;    // b[0..k-1]=各串当前关键字,b[k]=虚叶子

    // 从叶子 s 上溯重排:关键字大者为败者留在本结点,小者继续上溯
    void Adjust(int s) {
        int t = (s + k) / 2;              // b[s] 的父结点在 ls 中的下标
        while (t > 0) {
            if (b[s] > b[ls[t]]) {        // s 较大 -> 成为本结点败者
                int tmp = s;
                s = ls[t];                // 较小者(原败者)胜出继续上溯
                ls[t] = tmp;
            }
            t /= 2;
        }
        ls[0] = s;                        // 最终胜者即冠军(全局最小所在串)
    }

    // 建树:极小虚叶子填满败者位,再从后向前逐叶调整
    void CreateLoserTree() {
        b[k] = MINKEY;
        for (int i = 0; i < k; ++i) ls[i] = k;
        for (int i = k - 1; i >= 0; --i) Adjust(i);
    }

    // k 路平衡归并:从 k 个有序顺串中每次选出最小关键字
    vector<int> K_Merge(const vector<vector<int>>& runs, bool verbose = true) {
        if (runs.empty()) return vector<int>();
        k = static_cast<int>(runs.size());
        ls.assign(k, 0);
        b.assign(k + 1, MAXKEY);
        vector<size_t> pos(k, 0);         // 每串读取位置,模拟磁带头
        for (int i = 0; i < k; ++i)
            b[i] = pos[i] < runs[i].size() ? runs[i][pos[i]++] : MAXKEY;
        CreateLoserTree();
        vector<int> out;
        if (verbose) cout << "[11.3] 每轮选出的最小值: ";
        while (b[ls[0]] != MAXKEY) {
            int q = ls[0];                // 冠军:当前最小关键字所在串
            int v = b[q];
            out.push_back(v);
            if (verbose) cout << v << ' ';   // 打印本轮选出的最小值
            b[q] = pos[q] < runs[q].size() ? runs[q][pos[q]++] : MAXKEY;
            Adjust(q);                    // 从叶子 q 上溯重排,O(log k)
        }
        if (verbose) cout << '\n';
        return out;
    }
};
constexpr int LoserTree::MAXKEY;   // C++11:static constexpr 成员被 odr-use 需类外定义
constexpr int LoserTree::MINKEY;
// @ENDSECTION

// @SECTION 11.4 | 置换-选择排序
// 最小堆 + 输入流生成顺串:堆顶(最小)为当前串下一个输出,门槛 last = 刚输出的关键字.
//   新读入 x >= last 回堆(可并入本串),否则「冻结」留给下一串;堆空即本串结束,
//   解冻并复位 last 开始新串.败者树 <=> 堆:冠军 ls[0] == 堆顶,Adjust == 一次上滤.
// 平均顺串长度约为内存工作区 w 的 2 倍（随机大文件的经典结论）.
// 时间:每条记录进出堆一次 O(N log w);空间:工作区 O(w).
struct ReplacementSelection {
    using MinHeap = std::priority_queue<int, vector<int>, std::greater<int>>;
    vector<vector<int>> runs;   // 生成的初始顺串（对应磁盘顺串文件）

    // input 模拟大文件顺序流;w 为内存工作区容量
    vector<vector<int>> Generate(deque<int>& input, size_t w) {
        runs.clear();
        if (w == 0) return runs;
        MinHeap heap;
        vector<int> frozen;      // 冻结,属于下一顺串的记录
        for (size_t i = 0; i < w && !input.empty(); ++i) {
            heap.push(input.front());
            input.pop_front();
        }
        int last = std::numeric_limits<int>::min();   // 当前顺串门槛
        while (!heap.empty() || !frozen.empty()) {
            vector<int> run;
            while (!heap.empty()) {
                int rmin = heap.top();
                heap.pop();
                run.push_back(rmin);
                last = rmin;                        // 更新门槛
                if (!input.empty()) {
                    int x = input.front();
                    input.pop_front();
                    if (x >= last) heap.push(x);     // 可并入当前顺串
                    else frozen.push_back(x);        // 冻结,留给下一顺串
                }
            }
            if (!run.empty()) runs.push_back(std::move(run));
            last = std::numeric_limits<int>::min(); // 新顺串门槛复位
            for (int x : frozen) heap.push(x);      // 解冻
            frozen.clear();
        }
        return runs;
    }
};
// @ENDSECTION

// @SECTION 11.5 | 最佳归并树
// n 个长度不等的顺串做 k 路归并,使 I/O 最少的顺序 = k 路哈夫曼树.
// 若 (n-1) % (k-1) != 0,需补 0 权虚结点（置最浅层,最早合并,不改变 WPL）.
// WPL(带权路径长度)=各内部结点合并权之和,代表记录被读/写的遍数;I/O ≈ 2 * WPL.
// 时间:O(n log n)（最小堆取 k 个最小权）;空间 O(n).
// 对照「简单顺序归并」:按原序每 k 个一组逐层合并,不重排,其 WPL 必 >= 最优 WPL.
struct BestMergeTree {
    int k = 0;
    long long wpl = 0;   // 最佳归并树带权路径长度

    // 补 0 权虚结点,使叶子数 n' 满足 (n'-1) % (k-1) == 0
    static vector<int> Pad(const vector<int>& w, int k) {
        vector<int> a = w;
        if (k < 2 || a.empty()) return a;
        int r = (static_cast<int>(a.size()) - 1) % (k - 1);
        if (r != 0) {
            int d = (k - 1) - r;
            for (int i = 0; i < d; ++i) a.push_back(0);
        }
        return a;
    }

    // k 路哈夫曼:每次取 k 个最小权合并,累加合并权即 WPL
    static long long HuffmanWPL(const vector<int>& leaves, int k) {
        std::priority_queue<int, vector<int>, std::greater<int>> pq(leaves.begin(), leaves.end());
        long long wpl = 0;
        while (pq.size() > 1) {
            long long s = 0;
            for (int i = 0; i < k && !pq.empty(); ++i) {
                s += pq.top();
                pq.pop();
            }
            wpl += s;
            pq.push(static_cast<int>(s));
        }
        return wpl;
    }

    // 简单顺序归并:按原次序每 k 个一组逐层合并（对照组）
    static long long SequentialWPL(const vector<int>& leaves, int k) {
        vector<long long> cur(leaves.begin(), leaves.end());
        long long wpl = 0;
        while (cur.size() > 1) {
            vector<long long> next;
            for (size_t i = 0; i < cur.size(); i += static_cast<size_t>(k)) {
                long long s = 0;
                for (size_t j = i; j < cur.size() && j < i + static_cast<size_t>(k); ++j)
                    s += cur[j];
                wpl += s;
                next.push_back(s);
            }
            cur.swap(next);
        }
        return wpl;
    }

    // 构造并返回最优 WPL;seqWpl 回传顺序归并 WPL 以便比较
    long long Build(const vector<int>& runLens, int way, long long& seqWpl) {
        k = way;
        if (k < 2) { seqWpl = 0; wpl = 0; return 0; }
        vector<int> leaves = Pad(runLens, k);
        wpl = HuffmanWPL(leaves, k);
        seqWpl = SequentialWPL(leaves, k);
        return wpl;
    }
};
// @ENDSECTION

int main() {
    cout << "[说明] deque/vector 模拟外存;败者树冠军==堆顶,Adjust==一次上滤,均 O(log k).\n";

    {
        Demo d("11.2 外部排序的方法:2 路平衡归并");
        vector<int> data = {35,17,22,8,41,5,29,13,50,2,46,19,7,31,11,26};
        vector<int> sorted;
        TwoWayStat st = ExternalSortTwoWay(data, 4, sorted);
        printSeq(sorted, "[11.2] 最终整体有序序列");
        DS_CHECK(std::is_sorted(sorted.begin(), sorted.end()));
        vector<int> expect = data;
        std::sort(expect.begin(), expect.end());
        DS_CHECK(sorted == expect);
        cout << "[11.2] 总归并趟数 = " << st.passes
             << ", 估计 I/O(记录读/写) 约 " << st.io << "\n";
    }

    {
        Demo d("11.3 败者树:k 路平衡归并");
        vector<vector<int>> runs = {
            {1, 4, 7, 10},
            {2, 5, 8, 11},
            {3, 6, 9, 12}
        };
        LoserTree lt;
        vector<int> merged = lt.K_Merge(runs);   // 每轮打印选出的最小值
        DS_CHECK(std::is_sorted(merged.begin(), merged.end()));
        vector<int> expect;
        for (const auto& r : runs) expect.insert(expect.end(), r.begin(), r.end());
        std::sort(expect.begin(), expect.end());
        DS_CHECK(merged == expect);
        cout << "[11.3] 共选出 " << merged.size() << " 个关键字,输出整体有序\n";
    }

    {
        Demo d("11.4 置换-选择排序:生成初始顺串");
        vector<int> data = {35,17,22,8,41,5,29,13,50,2,46,19,7,31,11,26};
        deque<int> input(data.begin(), data.end());
        ReplacementSelection rs;
        vector<vector<int>> runs = rs.Generate(input, 4);
        cout << "[11.4] 生成顺串个数 = " << runs.size() << ", 各顺串长度: ";
        for (const auto& r : runs) cout << r.size() << ' ';
        cout << "\n";
        for (const auto& r : runs)
            DS_CHECK(std::is_sorted(r.begin(), r.end()));  // 每个顺串内部有序
        LoserTree lt;
        vector<int> merged = lt.K_Merge(runs, false);      // 复用 k 路归并,静默
        vector<int> expect = data;
        std::sort(expect.begin(), expect.end());
        DS_CHECK(merged == expect);                        // 所有顺串归并后为全序
        cout << "[11.4] 顺串总记录 = " << merged.size()
             << ", 平均长约为工作区(4) 的 2 倍量级\n";
    }

    {
        Demo demo115("11.5 最佳归并树:k 路哈夫曼");
        vector<int> runLens = {2, 3, 5, 7, 11, 13, 17};
        int k = 3;
        long long seqWpl = 0;
        BestMergeTree bmt;
        long long best = bmt.Build(runLens, k, seqWpl);
        int r = (static_cast<int>(runLens.size()) - 1) % (k - 1);
        int d = (r == 0) ? 0 : (k - 1) - r;   // 补 0 权虚结点个数
        cout << "[11.5] k = " << k << ", 补 0 权虚结点 = " << d << "\n";
        cout << "[11.5] 最佳归并树 WPL = " << best
             << ", 顺序归并 WPL = " << seqWpl << "\n";
        cout << "[11.5] 对应 I/O 块数约 2*WPL,最优树更省 I/O\n";
        DS_CHECK(best <= seqWpl);
        DS_CHECK(best == bmt.wpl);
    }

    cout << "[完成] 11.2~11.5 全部自测通过\n";
    return 0;
}
