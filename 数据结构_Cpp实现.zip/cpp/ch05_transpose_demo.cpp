// ch05_transpose_demo.cpp —— 教材 5.3.2「稀疏矩阵快速转置」完整可编译示例
// 编译：g++ -std=c++17 -O2 ch05_transpose_demo.cpp -o transpose && ./transpose
// 说明：与 ch07_prim_demo.cpp 风格一致，整段为一个 @SECTION，复制即可编译运行。
// @SECTION 5.3.2 | 完整可编译示例：稀疏矩阵快速转置
#include "ds_common.h"
#include <iomanip>

// ---------- 三元组顺序表（教材 1-based：data[0] 弃用）----------
// 行列号 i、j 均为 1-based（1..mu / 1..nu）；转置后 T.mu=M.nu, T.nu=M.mu。
// 与 0-based 二维数组换算：dense[i-1][j-1] = data[k].e（详见 ToDense）。
struct Triple {
    int i = 0, j = 0, e = 0;
};
struct TSMatrix {
    int mu = 0, nu = 0, tu = 0;                 // 行数、列数、非零元个数
    vector<Triple> data;                         // data[0] 弃用，data[1..tu] 按行优先存放
    explicit TSMatrix(int m = 0, int n = 0, int t = 0)
        : mu(m), nu(n), tu(t), data(t + 1) {}
};

// 打印三元组表（std::setw 表格）
void PrintSMatrix(const TSMatrix& M, const string& tip = "") {
    if (!tip.empty()) cout << tip << "\n";
    cout << "  " << std::setw(4) << "k" << std::setw(4) << "i"
         << std::setw(4) << "j" << std::setw(6) << "e" << "\n";
    for (int k = 1; k <= M.tu; ++k)
        cout << "  " << std::setw(4) << k << std::setw(4) << M.data[k].i
             << std::setw(4) << M.data[k].j << std::setw(6) << M.data[k].e << "\n";
}

// 还原成 0-based 稠密矩阵，便于断言数学转置。
vector<vector<int>> ToDense(const TSMatrix& M) {
    vector<vector<int>> d(M.mu, vector<int>(M.nu, 0));
    for (int k = 1; k <= M.tu; ++k)
        d[M.data[k].i - 1][M.data[k].j - 1] = M.data[k].e;  // 1-based -> 0-based
    return d;
}

// 教材算法 5.1 TransposeSMatrix：按列扫描，O(nu*tu)。
TSMatrix TransposeSMatrix(const TSMatrix& M) {
    TSMatrix T(M.nu, M.mu, M.tu);
    int q = 1;
    for (int col = 1; col <= M.nu; ++col)        // 按 M 的列序（即 T 的行序）
        for (int p = 1; p <= M.tu; ++p)
            if (M.data[p].j == col) {
                T.data[q].i = M.data[p].j;
                T.data[q].j = M.data[p].i;
                T.data[q].e = M.data[p].e;
                ++q;
            }
    return T;
}

// 打印 num[] / cpot[] 一维表（1-based 列号）
void PrintVec(const vector<int>& a, int lo, int hi, const string& tip) {
    cout << tip << ": ";
    for (int k = lo; k <= hi; ++k) cout << std::setw(3) << a[k];
    cout << "\n";
}

// 教材算法 5.2 FastTransposeSMatrix：num[col] + cpot[col]，O(nu + tu)。
// cpot[col] 初值 = 第 col 列第一个非零元在 T.data 中的存放位置（1-based）。
TSMatrix FastTransposeSMatrix(const TSMatrix& M, bool verbose = false) {
    TSMatrix T(M.nu, M.mu, M.tu);
    vector<int> num(M.nu + 1, 0), cpot(M.nu + 1, 0);   // 下标 1..nu 有效
    for (int t = 1; t <= M.tu; ++t) ++num[M.data[t].j];
    cpot[1] = 1;
    for (int col = 2; col <= M.nu; ++col)
        cpot[col] = cpot[col - 1] + num[col - 1];
    if (verbose) {
        PrintVec(num, 1, M.nu, "  num[col] 各列非零元个数");
        PrintVec(cpot, 1, M.nu, "  cpot[col] 初值");
        cout << "  --- 逐个三元组放入 T（cpot[col]++）---\n";
    }
    for (int p = 1; p <= M.tu; ++p) {
        int col = M.data[p].j;
        int q = cpot[col];
        T.data[q].i = M.data[p].j;
        T.data[q].j = M.data[p].i;
        T.data[q].e = M.data[p].e;
        ++cpot[col];
        if (verbose)
            cout << "  p=" << p << " (" << M.data[p].i << "," << M.data[p].j << ","
                 << M.data[p].e << ") col=" << col << " q=" << q
                 << " -> T.data[" << q << "]，cpot[" << col << "]++ 变 " << cpot[col] << "\n";
    }
    if (verbose) PrintVec(cpot, 1, M.nu, "  cpot[col] 终值");
    return T;
}

int main() {
    Demo demo("5.3.2 稀疏矩阵快速转置完整示例（6x7，8 个非零元）");

    // 教材经典 6x7 稀疏矩阵（三元组按行优先）
    TSMatrix M(6, 7, 8);
    int elems[8][3] = {
        {1, 2, 12}, {1, 3, 9}, {3, 1, -3}, {3, 6, 14},
        {4, 3, 24}, {5, 2, 18}, {6, 1, 15}, {6, 4, -7},
    };
    for (int k = 0; k < 8; ++k) {
        M.data[k + 1].i = elems[k][0];
        M.data[k + 1].j = elems[k][1];
        M.data[k + 1].e = elems[k][2];
    }
    PrintSMatrix(M, "原矩阵 M 的三元组表（mu=6, nu=7, tu=8）：");

    cout << "\n[一] 快速转置 num[] / cpot[] 与放置过程\n";
    TSMatrix TF = FastTransposeSMatrix(M, true);
    cout << "\n[二] 快速转置所得 T 的三元组表\n";
    PrintSMatrix(TF, "T（mu=7, nu=6, tu=8）：");

    // 普通转置作对照（不逐步打印）
    TSMatrix TS = TransposeSMatrix(M);

    // 断言 1：快速转置 == 普通转置（逐三元组完全一致）
    bool same = (TF.mu == TS.mu && TF.nu == TS.nu && TF.tu == TS.tu);
    for (int k = 1; same && k <= M.tu; ++k)
        same = (TF.data[k].i == TS.data[k].i &&
                TF.data[k].j == TS.data[k].j &&
                TF.data[k].e == TS.data[k].e);
    DS_CHECK(same);

    // 断言 2：T.mu / T.nu / T.tu 正确
    DS_CHECK(TF.mu == 7 && TF.nu == 6 && TF.tu == 8);

    // 断言 3：T 的稠密还原 == 原矩阵的数学转置 T[r][c] = M[c][r]
    auto denseM = ToDense(M);
    auto denseT = ToDense(TF);
    bool trans = true;
    for (int r = 0; r < M.mu; ++r)
        for (int c = 0; c < M.nu; ++c)
            if (denseM[r][c] != denseT[c][r]) trans = false;
    DS_CHECK(trans);

    cout << "\n[5.3.2] 断言通过：快速转置 == 普通转置 == 数学转置，T=7x6, tu=8\n";
    return 0;
}
// @ENDSECTION
