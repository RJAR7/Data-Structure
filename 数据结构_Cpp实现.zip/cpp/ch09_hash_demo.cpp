// ch09_hash_demo.cpp —— 教材 9.3「哈希表」构造与平均查找长度完整可编译示例
// 编译：g++ -std=c++17 -O2 ch09_hash_demo.cpp -o hash && ./hash
// 说明：整体作为一个 @SECTION 段，复制保存为 .cpp 即可单独编译运行。
// @SECTION 9.3 | 完整可编译示例：哈希表构造与 ASL
#include "ds_common.h"
#include <iomanip>

constexpr int EMPTY = -1;          // 空槽标志；本例关键字均为正整数，-1 不冲突

// ---------- 除留余数法 ----------
// H(key) = key % p，p 取「不大于表长 m」的最大素数，可使散列地址分布更均匀。
bool IsPrime(int x) {
    if (x < 2) return false;
    for (int d = 2; d * d <= x; ++d)
        if (x % d == 0) return false;
    return true;
}
int PrimeNotGreater(int m) {
    for (int x = m; x >= 2; --x)
        if (IsPrime(x)) return x;
    return 2;
}

// ---------- 开放定址法（线性探测再散列）----------
struct HashTable {
    int m, p;
    vector<int> elem;     // 槽位中的关键字，EMPTY 表示空槽
    vector<int> cnt;      // 放入该槽时的探测次数，即查找成功的比较次数
    int count = 0;        // 已存关键字个数
    explicit HashTable(int m_, int p_) : m(m_), p(p_), elem(m_, EMPTY), cnt(m_, 0) {}
    int H(int key) const { return key % p; }
};

// 线性探测插入：H_i = (H(key) + i) % m；probe 带回探测序列 H→H+1→…。
// 返回落位下标；-1 表示关键字已存在或表满。cnt[pos] 为探测次数，
// 冲突次数 = cnt[pos] - 1，查找成功比较次数 = cnt[pos]。
int InsertHash(HashTable& ht, int key, vector<int>& probe) {
    probe.clear();
    int h = ht.H(key);
    for (int i = 0; i < ht.m; ++i) {
        int pos = (h + i) % ht.m;
        probe.push_back(pos);
        if (ht.elem[pos] == EMPTY) {
            ht.elem[pos] = key;
            ht.cnt[pos] = static_cast<int>(probe.size());
            ++ht.count;
            return pos;
        }
        if (ht.elem[pos] == key) return -1;       // 不插入重复关键字
    }
    return -1;                                    // 表满（α 过大时应扩容）
}

// 查找：成功返回下标，失败返回 -1；cmp 带回比较次数（含对空槽的判定），
// 即失败查找的比较次数。
int SearchHash(const HashTable& ht, int key, int& cmp) {
    cmp = 0;
    int h = ht.H(key);
    for (int i = 0; i < ht.m; ++i) {
        int pos = (h + i) % ht.m;
        ++cmp;
        if (ht.elem[pos] == EMPTY) return -1;     // 遇空槽即判定查找失败
        if (ht.elem[pos] == key) return pos;
    }
    return -1;
}

// ASL_succ = (1/n) Σ C_i，C_i 为查到第 i 个关键字的比较次数。
// 线性探测理论近似：ASL_succ ≈ (1/2)(1 + 1/(1-α))，α = n/m 越大冲突越多、ASL 越大。
double ASL_Success(const HashTable& ht, const vector<int>& keys) {
    long long sum = 0;
    for (int k : keys) {
        int cmp = 0;
        int pos = SearchHash(ht, k, cmp);
        DS_CHECK(pos >= 0);                       // 断言每个关键字都能找回
        DS_CHECK(cmp == ht.cnt[pos]);             // 成功比较次数 = 插入探测次数
        sum += cmp;
    }
    return static_cast<double>(sum) / static_cast<int>(keys.size());
}

// ASL_fail = (1/p) Σ_{i=0}^{p-1} C_i，C_i 为从哈希地址 i 探测到空槽的比较次数。
// 线性探测理论近似：ASL_fail ≈ (1/2)(1 + 1/(1-α)^2)，随 α 增长比成功 ASL 更快。
double ASL_Fail(const HashTable& ht) {
    long long sum = 0;
    for (int h = 0; h < ht.p; ++h) {
        int cmp = 0;
        for (int i = 0; i < ht.m; ++i) {
            int pos = (h + i) % ht.m;
            ++cmp;
            if (ht.elem[pos] == EMPTY) break;
        }
        sum += cmp;
    }
    return static_cast<double>(sum) / ht.p;
}

// 按槽位打印表格：下标 / key / 探测次数；空槽用 - 占位，std::setw 对齐。
void PrintHashTable(const HashTable& ht) {
    cout << "  下标  :";
    for (int i = 0; i < ht.m; ++i) cout << std::setw(4) << i;
    cout << "\n  key   :";
    for (int i = 0; i < ht.m; ++i)
        cout << std::setw(4) << (ht.elem[i] == EMPTY ? string("-") : std::to_string(ht.elem[i]));
    cout << "\n  探测数:";
    for (int i = 0; i < ht.m; ++i)
        cout << std::setw(4) << (ht.elem[i] == EMPTY ? string("-") : std::to_string(ht.cnt[i]));
    cout << "\n";
}

void PrintProbe(const vector<int>& probe) {
    for (size_t i = 0; i < probe.size(); ++i) {
        if (i) cout << "→";
        cout << probe[i];
    }
}

// ---------- 链地址法 ----------
// 同义词挂在同一桶中；vector<vector<int>> 即「桶 → 同义词链」，无二次聚集。
struct ChainedHash {
    int p;
    vector<vector<int>> buckets;
    explicit ChainedHash(int p_) : p(p_), buckets(p_) {}
    int H(int key) const { return key % p; }
    void Insert(int key) { buckets[H(key)].push_back(key); }
    bool Search(int key, int& cmp) const {
        cmp = 0;
        for (int x : buckets[H(key)]) {
            ++cmp;
            if (x == key) return true;
        }
        return false;
    }
    // 链地址 ASL_succ 理论近似 1 + α/2；此处按各关键字在桶内的序号精确求和。
    double ASL_Success(const vector<int>& keys) const {
        long long sum = 0;
        for (int k : keys) {
            int cmp = 0;
            DS_CHECK(Search(k, cmp));             // 断言链地址法也能找回全部关键字
            sum += cmp;
        }
        return static_cast<double>(sum) / static_cast<int>(keys.size());
    }
    void Print() const {
        for (int i = 0; i < p; ++i) {
            if (buckets[i].empty()) continue;
            cout << "  桶 " << std::setw(2) << i << ": ";
            for (size_t j = 0; j < buckets[i].size(); ++j)
                cout << (j ? " → " : "") << buckets[i][j];
            cout << "  (" << buckets[i].size() << " 个)\n";
        }
        int emptyCnt = 0;
        for (const auto& b : buckets) if (b.empty()) ++emptyCnt;
        cout << "  其余 " << emptyCnt << " 个桶为空\n";
    }
};

int main() {
    Demo demo("9.3 哈希表构造与 ASL 完整示例");

    const int m = 13;
    const int p = PrimeNotGreater(m);            // p = 13（不大于表长的最大素数）
    DS_CHECK(p == 13);
    vector<int> keys = {19, 14, 23, 1, 68, 20, 84, 27, 55, 11, 10, 79};
    HashTable ht(m, p);

    cout << "表长 m=" << m << "，素数 p=" << p << "，H(key)=key%" << p
         << "，关键字个数 n=" << keys.size() << "\n";
    cout << "[构造] 线性探测 H_i=(H(key)+i)%m，逐个打印 H(key) 与探测序列\n";
    for (int k : keys) {
        vector<int> probe;
        int pos = InsertHash(ht, k, probe);
        DS_CHECK(pos >= 0);
        cout << "  key=" << std::setw(2) << k
             << "  H=" << std::setw(2) << ht.H(k) << "  探测 ";
        PrintProbe(probe);
        cout << "  → 落位 " << std::setw(2) << pos
             << "  (比较 " << ht.cnt[pos] << " 次, 冲突 " << ht.cnt[pos] - 1 << " 次)\n";
    }

    cout << "[最终哈希表] 空槽用 - 占位\n";
    PrintHashTable(ht);

    cout << "[查找示例] 成功=插入探测次数；失败=探到空槽为止的比较次数\n";
    int cmp = 0;
    int pos19 = SearchHash(ht, 19, cmp);
    cout << "  查找 19 → 成功 槽 " << pos19 << "，比较 " << cmp << " 次\n";
    int pos79 = SearchHash(ht, 79, cmp);
    cout << "  查找 79 → 成功 槽 " << pos79 << "，比较 " << cmp << " 次\n";
    SearchHash(ht, 21, cmp);
    cout << "  查找 21 → 失败，比较 " << cmp << " 次（遇空槽 0）\n";

    double aslS = ASL_Success(ht, keys);
    double aslF = ASL_Fail(ht);
    double alpha = static_cast<double>(ht.count) / m;
    cout << std::fixed << std::setprecision(3);
    cout << "[ASL] 成功 ASL = 30/12 = " << aslS << "\n";
    cout << "[ASL] 失败 ASL = 91/13 = " << aslF << "\n";
    cout << "[ASL] 装填因子 α = n/m = " << ht.count << "/" << m << " = " << alpha << "\n";
    cout << "[公式] ASL_succ≈(1+1/(1-α))/2, ASL_fail≈(1+1/(1-α)^2)/2，α↑ 则冲突↑、ASL↑\n";

    // 手算：探测次数 1×6 + 2 + 3×3 + 4 + 9 = 30，故 ASL_succ = 30/12 = 2.5。
    DS_CHECK(aslS == 2.5);
    // 手算：13 个哈希地址探到空槽的比较次数 1+2+…+13 = 91，故 ASL_fail = 91/13 = 7。
    DS_CHECK(aslF == 7.0);
    for (int miss : vector<int>{2, 21, 99, 100}) DS_CHECK(SearchHash(ht, miss, cmp) == -1);
    cout << "[断言] 12 个关键字全部找回；未插入关键字查找失败；ASL_succ=2.5 ASL_fail=7\n";

    cout << "[链地址法] 同义词入桶，桶分布（p=" << p << "）\n";
    ChainedHash ch(p);
    for (int k : keys) ch.Insert(k);
    ch.Print();
    double chAsl = ch.ASL_Success(keys);
    cout << "[链地址法] 成功 ASL = 21/12 = " << chAsl << "\n";
    // 手算：桶内序号之和 1+1+1+2+1+1+2+3+2+1+2+4 = 21，故 ASL = 21/12 = 1.75。
    DS_CHECK(chAsl == 1.75);
    cout << "[断言] 链地址法找回全部 12 个关键字，成功 ASL=1.75\n";

    return 0;
}
// @ENDSECTION
