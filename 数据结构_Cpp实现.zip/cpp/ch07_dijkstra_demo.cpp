// ch07_dijkstra_demo.cpp —— 教材 7.6「最短路径」Dijkstra 算法完整可编译示例
// 编译：g++ -std=c++17 -O2 ch07_dijkstra_demo.cpp -o dij && ./dij
// 说明：本文件整体作为一个 @SECTION 段，便于讲义折叠展示「复制即可编译」的完整源码。
// @SECTION 7.6 | 完整可编译示例：Dijkstra 逐步演示 + 堆优化对照
#include "ds_common.h"
#include <iomanip>

// ---------- 带权有向图的邻接矩阵（0-based，教材图 7.34 的 6 顶点例子）----------
struct MGraph {
    int n;
    vector<vector<int>> arcs;                  // arcs[u][v]：弧权；INF_COST 表示无弧
    explicit MGraph(int n_) : n(n_), arcs(n_, vector<int>(n_, INF_COST)) {
        for (int i = 0; i < n_; ++i) arcs[i][i] = 0;
    }
    void AddArc(int u, int v, int w) { arcs[u][v] = w; }
};

struct DijResult {
    vector<int> dist;                          // D[v]：v0 到 v 的当前最短路径长度
    vector<int> prev;                          // P[v]：路径上 v 的前驱，-1 表示不可达
    vector<int> S;                             // S[v]=1 表示最短路径已确定
};

void PrintD(const vector<int>& D) {
    cout << "  D[]: ";
    for (int x : D) {
        if (x >= INF_COST) cout << std::setw(5) << "INF";
        else cout << std::setw(5) << x;
    }
    cout << "\n";
}

// 教材算法 7.15：S = {v0}；每轮从 V-S 中选 D 最小的 u 并入 S，再用 u 松弛其余顶点。
// 时间 O(n^2)（邻接矩阵），空间 O(n)。要求所有弧权非负。
DijResult ShortestPath_DIJ(const MGraph& G, int v0) {
    int n = G.n;
    DijResult R;
    R.dist.assign(n, INF_COST);
    R.prev.assign(n, -1);
    R.S.assign(n, 0);
    R.dist[v0] = 0;
    cout << "初始（S = {" << v0 << "}）:\n";
    PrintD(R.dist);

    for (int i = 0; i < n; ++i) {
        int u = -1, best = INF_COST;
        for (int v = 0; v < n; ++v)
            if (!R.S[v] && R.dist[v] < best) { best = R.dist[v]; u = v; }
        if (u == -1) break;                    // 剩余顶点都不可达
        R.S[u] = 1;
        cout << "\n第 " << i + 1 << " 轮：选 u = " << u << "（D = " << best << "）\n";
        for (int v = 0; v < n; ++v) {
            if (R.S[v] || v == u || G.arcs[u][v] >= INF_COST) continue;
            long long nd = (long long)R.dist[u] + G.arcs[u][v];   // long long 防溢出
            if (nd < R.dist[v]) {
                R.dist[v] = (int)nd;
                R.prev[v] = u;
                cout << "  松弛 " << u << "->" << v << " : D[" << v << "] = " << nd << "\n";
            }
        }
        PrintD(R.dist);
    }
    return R;
}

// 堆优化版：用最小堆代替「线性扫描找最小」，矩阵实现为 O(n^2 log n)；
// 若改用邻接表则为 O((n+e) log n)，适合稀疏图。结果与教材版必须完全一致。
vector<int> ShortestPath_DIJ_PQ(const MGraph& G, int v0) {
    int n = G.n;
    vector<int> D(n, INF_COST);
    using P = std::pair<int, int>;             // (距离, 顶点)
    std::priority_queue<P, vector<P>, std::greater<P>> pq;
    D[v0] = 0; pq.push({0, v0});
    while (!pq.empty()) {
        auto top = pq.top(); pq.pop();
        int d = top.first, u = top.second;
        if (d != D[u]) continue;               // 跳过过期记录
        for (int v = 0; v < n; ++v) {
            if (G.arcs[u][v] >= INF_COST || v == u) continue;
            long long nd = (long long)d + G.arcs[u][v];
            if (nd < D[v]) { D[v] = (int)nd; pq.push({D[v], v}); }
        }
    }
    return D;
}

// 由前驱数组回溯输出 v0 -> dst 的路径。
vector<int> BuildPath(const DijResult& R, int v0, int dst) {
    vector<int> path;
    for (int cur = dst; cur != -1; cur = R.prev[cur]) {
        path.push_back(cur);
        if (cur == v0) break;
    }
    std::reverse(path.begin(), path.end());
    if (path.empty() || path[0] != v0) return {};   // 不可达
    return path;
}

int main() {
    Demo demo("7.6 Dijkstra 完整示例（教材经典 6 顶点有向网）");
    MGraph G(6);
    G.AddArc(0, 2, 10); G.AddArc(0, 4, 30); G.AddArc(0, 5, 100);
    G.AddArc(1, 2, 5);  G.AddArc(2, 3, 50);
    G.AddArc(3, 5, 10); G.AddArc(4, 3, 20); G.AddArc(4, 5, 60);

    DijResult R = ShortestPath_DIJ(G, 0);
    cout << "\n最终最短距离 D = [0, INF, 10, 50, 30, 60]\n";
    vector<int> expect = {0, INF_COST, 10, 50, 30, 60};
    DS_CHECK(R.dist == expect);                 // 与教材图 7.34 手算结果一致

    vector<int> path = BuildPath(R, 0, 5);
    cout << "0 -> 5 最短路径: "; printSeq(path);
    vector<int> ep = {0, 4, 3, 5};
    DS_CHECK(path == ep);                       // 0->4->3->5，长度 30+20+10=60
    DS_CHECK(BuildPath(R, 0, 1).empty());       // 顶点 1 从 v0 不可达

    vector<int> pq = ShortestPath_DIJ_PQ(G, 0);
    DS_CHECK(pq == R.dist);                     // 堆优化版结果一致
    cout << "\n[7.6] 断言通过：教材版 = 堆优化版，路径还原正确\n";
    return 0;
}
// @ENDSECTION
