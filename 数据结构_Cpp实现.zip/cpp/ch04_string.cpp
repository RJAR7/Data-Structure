// ch04_string.cpp —— 《数据结构（C 语言版）》第 4 章 串：可编译 C++17 实现
// 编译：g++ -std=c++17 -O2 -Wall ch04_string.cpp -o ch04 && ./ch04
// 约定：教材下标多从 1 起；凡 std::string / 数组下标为 0-based 处均显式注释转换。
#include "ds_common.h"
#include <utility>

// @SECTION 4.1 | 串的最小操作子集（std::string 底层）
// 教材最小操作子集：StrAssign / StrCompare / StrLength / Concat / SubString 不可由其它操作实现。
// 底层 std::string 为 0-based；教材 pos 为 1-based，函数内部统一做 pos-1 转换成 0-based 起点。
void StrAssign(string& T, const char* chars) { T = chars; }
int StrCompare(const string& S, const string& T) {                   // 字典序：>0 / =0 / <0
    size_t i = 0, n = std::min(S.size(), T.size());
    for (; i < n; ++i)
        if (S[i] != T[i]) return (unsigned char)S[i] - (unsigned char)T[i];
    return (int)S.size() - (int)T.size();
}
int StrLength(const string& S) { return (int)S.size(); }
void Concat(string& T, const string& S1, const string& S2) { T = S1 + S2; }
// 合法条件：1 <= pos <= StrLength(S)，0 <= len <= StrLength(S)-pos+1；len=0 的子串合法。
bool SubString(string& Sub, const string& S, int pos, int len) {
    if (pos < 1 || len < 0) return false;
    size_t start = (size_t)(pos - 1);                                // 1-based -> 0-based
    if (start > S.size() || (size_t)len > S.size() - start) return false;
    Sub = S.substr(start, (size_t)len);
    return true;
}
void StrCopy(string& T, const string& S) { T = S; }
bool StrEmpty(const string& S) { return S.empty(); }
void ClearString(string& S) { S.clear(); }
// Index 仅用最小操作子集实现（教材 p.25），返回 1-based 位置，0 表示不存在。
int Index(const string& S, const string& T, int pos) {
    if (pos <= 0) return 0;
    int n = StrLength(S), m = StrLength(T); string sub;
    for (int i = pos; i <= n - m + 1; ++i) {
        SubString(sub, S, i, m);
        if (StrCompare(sub, T) == 0) return i;
    }
    return 0;
}
// 复杂度：StrAssign/Concat/SubString 为 O(n)，StrCompare/Index 最坏 O(n*m)；空间 O(n)。
// @ENDSECTION

// @SECTION 4.2.1 | 定长顺序存储 SString
// 教材 MAXSTRLEN=255：0 号单元存串长，1..255 存字符（字符下标 1-based）。
constexpr int MAXSTRLEN = 255;
using SString = unsigned char[MAXSTRLEN + 1];
void StrAssign(SString& T, const char* chars) {                      // 超过 255 截断
    int n = 0;
    while (chars[n] != '\0' && n < MAXSTRLEN) { T[n + 1] = (unsigned char)chars[n]; ++n; }
    T[0] = (unsigned char)n;
}
int StrLength(const SString& S) { return S[0]; }
// Concat 三种情况（教材）：返回 uncut 表示是否未截断。
bool Concat(SString& T, const SString& S1, const SString& S2) {
    int n1 = S1[0], n2 = S2[0];
    if (n1 + n2 <= MAXSTRLEN) {                                     // ① 未截断
        for (int i = 1; i <= n1; ++i) T[i] = S1[i];
        for (int i = 1; i <= n2; ++i) T[n1 + i] = S2[i];
        T[0] = (unsigned char)(n1 + n2); return true;
    }
    if (n1 < MAXSTRLEN) {                                           // ② 部分截断
        for (int i = 1; i <= n1; ++i) T[i] = S1[i];
        for (int i = 1; i <= MAXSTRLEN - n1; ++i) T[n1 + i] = S2[i];
        T[0] = (unsigned char)MAXSTRLEN; return false;
    }
    for (int i = 1; i <= MAXSTRLEN; ++i) T[i] = S1[i];             // ③ 仅取 S1
    T[0] = (unsigned char)MAXSTRLEN; return false;
}
bool SubString(SString& Sub, const SString& S, int pos, int len) {
    if (pos < 1 || len < 0 || pos - 1 > S[0] || len > S[0] - (pos - 1)) return false;
    for (int i = 1; i <= len; ++i) Sub[i] = S[pos - 1 + i];         // pos-1：1-based -> 0-based
    Sub[0] = (unsigned char)len;
    return true;
}
int StrCompare(const SString& S, const SString& T) {
    for (int i = 1; i <= S[0] && i <= T[0]; ++i)
        if (S[i] != T[i]) return (int)S[i] - (int)T[i];
    return S[0] - T[0];
}
string SToString(const SString& S) {                                // 仅取 1..S[0] 有效字符
    return string(reinterpret_cast<const char*>(&S[1]), (size_t)S[0]);
}
// 复杂度：上述操作均为 O(MAXSTRLEN)；空间 O(1)（定长数组，无动态分配）。
// @ENDSECTION

// @SECTION 4.2.2 | 堆分配存储 HString（RAII 定义与赋值）
// 教材 HString 含 char* ch 与 int length 两个成员：ch 按串长分配（不带结尾符，显式存 length，O(1) 取长）。
// C++ 用构造/析构/拷贝构造/拷贝赋值/移动遵循 Rule of Five，深拷贝避免悬垂与重复释放。
struct HString {
    char* ch = nullptr; int length = 0;
    HString() = default;
    ~HString() { delete[] ch; }
    void copyFrom(const HString& o) {
        delete[] ch; ch = nullptr; length = 0;                      // 先释放旧空间
        if (o.length > 0 && o.ch) {
            ch = new char[o.length]; std::memcpy(ch, o.ch, o.length); length = o.length;
        }
    }
    HString(const HString& o) { copyFrom(o); }
    HString& operator=(const HString& o) { if (this != &o) copyFrom(o); return *this; }
    HString(HString&& o) noexcept : ch(o.ch), length(o.length) { o.ch = nullptr; o.length = 0; }
    HString& operator=(HString&& o) noexcept {
        if (this != &o) { delete[] ch; ch = o.ch; length = o.length; o.ch = nullptr; o.length = 0; }
        return *this;
    }
};
void StrAssign(HString& T, const char* chars) {                      // 释放-分配-复制（教材模式）
    delete[] T.ch; T.ch = nullptr; T.length = 0;
    int n = (int)std::strlen(chars);
    if (n > 0) { T.ch = new char[n]; std::memcpy(T.ch, chars, n); T.length = n; }
}
int StrLength(const HString& S) { return S.length; }
// 复杂度：构造/析构 O(1)，StrAssign O(n)；空间 O(n)（按串长精确分配）。
// @ENDSECTION

// @SECTION 4.2.2 | 堆分配存储 HString（插入、删除、比较、连接）
// 以下操作保持「先分配新缓冲并复制完，再释放旧 ch」的顺序，天然支持 T/S 自引用。
Status StrInsert(HString& S, int pos, const HString& T) {           // 1 <= pos <= length+1
    if (pos < 1 || pos > S.length + 1) return ERROR;
    if (T.length == 0) return OK;
    int off = pos - 1, newLen = S.length + T.length;                // pos-1：1-based -> 0-based
    char* p = new char[newLen];
    if (off) std::memcpy(p, S.ch, off);
    std::memcpy(p + off, T.ch, T.length);
    if (S.length - off) std::memcpy(p + off + T.length, S.ch + off, S.length - off);
    delete[] S.ch; S.ch = p; S.length = newLen;
    return OK;
}
Status StrDelete(HString& S, int pos, int len) {                     // 删除 [pos, pos+len-1]（1-based）
    int off = pos - 1;
    if (pos < 1 || len < 0 || off > S.length || len > S.length - off) return ERROR;
    int newLen = S.length - len; char* p = nullptr;
    if (newLen > 0) {
        p = new char[newLen];
        if (off) std::memcpy(p, S.ch, off);
        if (newLen - off) std::memcpy(p + off, S.ch + off + len, newLen - off);
    }
    delete[] S.ch; S.ch = p; S.length = newLen;
    return OK;
}
int StrCompare(const HString& S, const HString& T) {
    int n = std::min(S.length, T.length);
    for (int i = 0; i < n; ++i)
        if (S.ch[i] != T.ch[i]) return (unsigned char)S.ch[i] - (unsigned char)T.ch[i];
    return S.length - T.length;
}
void Concat(HString& T, const HString& S1, const HString& S2) {     // 不截断
    int n1 = S1.length, n2 = S2.length;
    char* p = (n1 + n2) ? new char[n1 + n2] : nullptr;
    if (n1) std::memcpy(p, S1.ch, n1);
    if (n2) std::memcpy(p + n1, S2.ch, n2);
    delete[] T.ch; T.ch = p; T.length = n1 + n2;                   // 复制完成后才释放，支持 T==S1
}
string HToString(const HString& S) { return string(S.ch ? S.ch : "", (size_t)S.length); }
// 复杂度：StrInsert/StrDelete/Concat/StrCompare 均 O(n)；空间 O(n)。
// @ENDSECTION

// @SECTION 4.2.3 | 块链存储 LString
// 教材 CHUNKSIZE=80，此处缩小为 4 便于演示；一个结点存一个子串（4 字符），块间指针相连。
constexpr int CHUNKSIZE = 4;
struct Chunk { char ch[CHUNKSIZE]; Chunk* next = nullptr; };
struct LString {
    Chunk* head = nullptr; Chunk* tail = nullptr; int curlen = 0;
    LString() = default;
    LString(const LString&) = delete; LString& operator=(const LString&) = delete;  // 含裸指针，禁拷贝防重复释放
    void Clear() {
        Chunk* p = head;
        while (p) { Chunk* q = p->next; delete p; p = q; }
        head = tail = nullptr; curlen = 0;
    }
    ~LString() { Clear(); }
};
void StrAssign(LString& S, const char* chars) {
    S.Clear();
    int n = (int)std::strlen(chars); S.curlen = n;
    Chunk* last = nullptr;
    for (int k = 0; k < n; ++k) {
        if (k % CHUNKSIZE == 0) {                                   // 每满 4 字符新开一块
            Chunk* c = new Chunk();                                  // 值初始化：ch 清零、next 为空
            if (!S.head) S.head = c; else last->next = c;
            last = c; S.tail = c;
        }
        last->ch[k % CHUNKSIZE] = chars[k];
    }
}
// 遍历打印：按 curlen 截断，跳过末块内填充的空字符。
string LStringToString(const LString& S) {
    string out; int cnt = 0;
    for (Chunk* p = S.head; p && cnt < S.curlen; p = p->next)
        for (int k = 0; k < CHUNKSIZE && cnt < S.curlen; ++k) { out += p->ch[k]; ++cnt; }
    return out;
}
// 复杂度：StrAssign / 遍历均 O(n)；空间 O(n/CHUNKSIZE) 个结点，存储密度随 CHUNKSIZE 增大而提高。
// @ENDSECTION

// @SECTION 4.3.1 | 朴素模式匹配 BF（教材 Index）
// 教材 Index(S, T, pos)：SString 字符下标 1-based，返回 1-based 起始位置，0 表示不存在。
// cmpCnt 可选：累计字符比较次数，用于和理论最坏 O(n*m) 对照；空指针表示不统计。
// 失配回退 i = i - j + 2 是 1-based 推导：本轮起点为 i-j+1，下一轮起点再后移一位。
int Index(const SString& S, const SString& T, int pos, long long* cmpCnt = nullptr) {
    int i = pos, j = 1;
    if (cmpCnt) *cmpCnt = 0;
    while (i <= S[0] && j <= T[0]) {
        if (cmpCnt) ++*cmpCnt;
        if (S[i] == T[j]) { ++i; ++j; }                             // 继续比较后继字符
        else { i = i - j + 2; j = 1; }                              // 主串指针回退，模式串复位
    }
    return (j > T[0]) ? (i - T[0]) : 0;
}
// 复杂度：时间最坏 O(n*m)（如 S 为多个 a 后接 b、T 为多个 a 后接 b），空间 O(1)。
// @ENDSECTION

// @SECTION 4.3.2 | KMP：get_next / get_nextval / Index_KMP
// 教材 1-based 写法：模式串 T[1..T[0]]，next[1]=0，next[0] 不用；数组须开到 T[0]+1 即 MAXSTRLEN+1。
// 与常见 0-based 版差异：本版 next[j] 表示失配时模式串重新比较的位置（1-based），next[1]=0 作哨兵。
void get_next(const SString& T, int next[]) {
    int j = 1, k = 0; next[1] = 0;
    while (j < T[0]) {
        if (k == 0 || T[j] == T[k]) { ++j; ++k; next[j] = k; }     // k==0 短路，勿访问 T[0]
        else k = next[k];                                            // 沿 next 链回溯
    }
}
void get_nextval(const SString& T, int nextval[]) {
    int j = 1, k = 0; nextval[1] = 0;
    while (j < T[0]) {
        if (k == 0 || T[j] == T[k]) {
            ++j; ++k;
            if (T[j] != T[k]) nextval[j] = k;                        // T[T[0]] 为最后字符，下标合法
            else nextval[j] = nextval[k];                             // 相等则跳过重复比较
        } else k = nextval[k];
    }
}
// 主串指针 i 不回溯；next 可传 get_next 或 get_nextval 的结果。
int Index_KMP(const SString& S, const SString& T, int pos, const int next[]) {
    int i = pos, j = 1;
    while (i <= S[0] && j <= T[0]) {
        if (j == 0 || S[i] == T[j]) { ++i; ++j; }                    // j==0 短路，勿访问 T[0]
        else j = next[j];                                            // i 不变，模式串右滑
    }
    return (j > T[0]) ? (i - T[0]) : 0;
}
// 复杂度：get_next / get_nextval 为 O(m)，Index_KMP 为 O(n)，合计 O(n+m)；空间 O(m)。
// @ENDSECTION

// @SECTION 4.4 | 串操作应用：串替换 Replace 与文本行统计
// 应用一：把 S 中所有 oldStr 替换为 newStr，返回替换次数；底层 std::string 为 0-based。
int Replace(string& S, const string& oldStr, const string& newStr) {
    if (oldStr.empty()) return 0;
    int cnt = 0; size_t pos = 0;
    while ((pos = S.find(oldStr, pos)) != string::npos) {
        S.replace(pos, oldStr.size(), newStr);
        pos += newStr.size(); ++cnt;                                 // 跳过新串，避免重叠死循环
    }
    return cnt;
}
// 应用二：按换行符切分统计总行数、非空行数、字符数（不含换行符）；空文本为 0 行。
struct LineStat { int lines = 0; int nonEmpty = 0; int chars = 0; };
LineStat StatLines(const string& text) {
    LineStat st; size_t start = 0;
    while (start < text.size()) {
        size_t e = text.find('\n', start);
        size_t end = (e == string::npos) ? text.size() : e;
        int len = (int)(end - start);
        ++st.lines; st.chars += len; if (len > 0) ++st.nonEmpty;
        if (e == string::npos) break;
        start = e + 1;
    }
    return st;
}
// 复杂度：Replace O(n*替换次数)、StatLines O(n)；空间 O(n)。
// @ENDSECTION

int main() {
    {
        Demo d("4.1 串的最小操作子集");
        string S, a, b, sub, man, cat;
        StrAssign(S, "commander");
        StrAssign(a, "data"); StrAssign(b, "state");
        DS_CHECK(StrCompare(a, b) < 0);
        StrAssign(a, "cat"); StrAssign(b, "case");
        DS_CHECK(StrCompare(a, b) > 0);
        DS_CHECK(StrLength(S) == 9);
        DS_CHECK(SubString(man, S, 4, 3) && man == "man");          // 1-based pos=4 -> 0-based 起点 3
        DS_CHECK(SubString(sub, S, 9, 0) && sub.empty());            // len=0 是合法串
        Concat(cat, S, a); DS_CHECK(cat == "commandercat");
        StrCopy(b, S); DS_CHECK(b == S);
        DS_CHECK(!StrEmpty(S)); ClearString(b); DS_CHECK(StrEmpty(b));
        string ms, mt; StrAssign(ms, "ababcabcacbab"); StrAssign(mt, "abcac");
        DS_CHECK(Index(ms, mt, 1) == 6);                             // 1-based 位置
        cout << "SubString(commander,4,3)=" << man << " | Index=" << Index(ms, mt, 1) << "\n";
        cout << "Concat(commander,cat)=" << cat << "\n";
    }
    {
        Demo d("4.2.1 定长顺序存储 SString(截断演示)");
        SString a = {}, b = {}, c = {}, sub = {}, A = {}, B = {}, C = {};
        StrAssign(a, "hello"); StrAssign(b, " world");
        DS_CHECK(Concat(c, a, b) && SToString(c) == "hello world"); // 未截断
        DS_CHECK(SubString(sub, c, 7, 5) && SToString(sub) == "world");
        DS_CHECK(StrCompare(a, b) != 0);
        string s250(250, 'x'), s10(10, 'y'), s255(255, 'z');
        StrAssign(A, s250.c_str()); StrAssign(B, s10.c_str());
        DS_CHECK(!Concat(C, A, B) && StrLength(C) == MAXSTRLEN);    // 部分截断
        DS_CHECK(SToString(C) == s250 + s10.substr(0, 5));          // 只补 5 个字符到 255
        cout << "SString 未截断: " << SToString(c) << " | 部分截断 len=" << StrLength(C) << "/" << MAXSTRLEN << "\n";
        StrAssign(A, s255.c_str());
        DS_CHECK(!Concat(C, A, B) && SToString(C) == s255);         // 仅取 S1
        cout << "SString 仅取 S1 后 len=" << StrLength(C) << " 且内容保持不变\n";
    }
    {
        Demo d("4.2.2 堆分配存储 HString(RAII 与深拷贝)");
        HString h, t, cat, copy;
        StrAssign(h, "abcdef");
        DS_CHECK(StrLength(h) == 6);
        copy = h;                                                    // 拷贝赋值：深拷贝
        DS_CHECK(StrCompare(copy, h) == 0 && copy.ch != h.ch);
        StrAssign(t, "XYZ");
        DS_CHECK(StrInsert(h, 3, t) == OK && HToString(h) == "abXYZcdef"); // 1-based pos=3 之前插入
        DS_CHECK(StrDelete(h, 3, 3) == OK && HToString(h) == "abcdef");
        Concat(cat, h, t); DS_CHECK(HToString(cat) == "abcdefXYZ");
        HString moved = std::move(copy);                             // 移动构造
        DS_CHECK(HToString(moved) == "abcdef" && copy.ch == nullptr && copy.length == 0);
        cout << "HString 插入->删除->连接 = " << HToString(cat) << " | 深拷贝与移动均安全\n";
    }
    {
        Demo d("4.2.3 块链存储 LString");
        LString L;
        StrAssign(L, "abcdefghij");                                 // 10 字符 -> 3 块（4+4+2）
        DS_CHECK(L.curlen == 10 && LStringToString(L) == "abcdefghij");
        DS_CHECK(L.head && L.head->next && L.head->next->next && !L.head->next->next->next);
        cout << "LString(" << CHUNKSIZE << " 字符每块): " << LStringToString(L) << " | curlen=" << L.curlen << "\n";
    }
    {
        Demo d("4.3.1 朴素模式匹配 BF(比较次数对照)");
        SString S = {}, T = {};
        StrAssign(S, "aaaaaaaaab"); StrAssign(T, "aaaab");           // 教材给出的最坏情形
        long long cnt = 0; int p = Index(S, T, 1, &cnt);
        int n = StrLength(S), m = StrLength(T);
        DS_CHECK(p == 6);
        DS_CHECK(cnt <= 1LL * n * m);
        cout << "BF: pos=" << p << " 字符比较=" << cnt << "(理论最坏 n*m=" << 1LL * n * m << ")\n";
    }
    {
        Demo d("4.3.2 KMP 算法(next / nextval 与四组对照)");
        SString T5 = {}; StrAssign(T5, "aaaab");
        int nxt[MAXSTRLEN + 1] = {}, nval[MAXSTRLEN + 1] = {};
        get_next(T5, nxt); get_nextval(T5, nval);
        printSeq(vector<int>(nxt + 1, nxt + T5[0] + 1), "next   ");
        printSeq(vector<int>(nval + 1, nval + T5[0] + 1), "nextval");
        DS_CHECK(nxt[1] == 0 && nxt[2] == 1 && nxt[3] == 2 && nxt[4] == 3 && nxt[5] == 4);
        DS_CHECK(nval[1] == 0 && nval[2] == 0 && nval[3] == 0 && nval[4] == 0 && nval[5] == 4);
        const char* cases[][2] = {
            {"ababcabcacbab", "abcac"}, {"aaaaaaaaab", "aaaab"},
            {"acabaabaabcacaabc", "abaabcac"}, {"hello world", "xyz"}
        };
        int bf[4], kmp[4], kmpv[4];
        for (int c = 0; c < 4; ++c) {
            SString S = {}, P = {};
            StrAssign(S, cases[c][0]); StrAssign(P, cases[c][1]);
            int nx[MAXSTRLEN + 1] = {}, nv[MAXSTRLEN + 1] = {};
            get_next(P, nx); get_nextval(P, nv);
            bf[c] = Index(S, P, 1);
            kmp[c] = Index_KMP(S, P, 1, nx);
            kmpv[c] = Index_KMP(S, P, 1, nv);
            DS_CHECK(bf[c] == kmp[c] && kmp[c] == kmpv[c]);
            size_t f = string(cases[c][0]).find(cases[c][1]);
            int expected = (f == string::npos) ? 0 : (int)f + 1;   // 0-based -> 1-based
            DS_CHECK(bf[c] == expected);
        }
        cout << "BF/KMP/nextval-KMP 四组位置: " << bf[0] << " " << bf[1] << " " << bf[2] << " " << bf[3] << "\n";
    }
    {
        Demo d("4.4 串操作应用:Replace 与文本行统计");
        string s = "go go golang, go!";
        int cnt = Replace(s, "go", "C++");
        DS_CHECK(cnt == 4 && s == "C++ C++ C++lang, C++!");
        cout << "Replace 次数=" << cnt << " 结果=" << s << "\n";
        string text = "abc\n\ndef";
        LineStat st = StatLines(text);
        DS_CHECK(st.lines == 3 && st.nonEmpty == 2 && st.chars == 6);
        cout << "StatLines: lines=" << st.lines << " 非空=" << st.nonEmpty << " 字符=" << st.chars << "\n";
    }
    cout << "第 4 章:全部 DS_CHECK 通过\n";
    return 0;
}
