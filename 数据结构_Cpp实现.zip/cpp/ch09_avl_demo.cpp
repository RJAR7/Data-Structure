// ch09_avl_demo.cpp —— 教材 9.2.1「平衡二叉树」AVL 四种旋转完整可编译示例
// 编译：g++ -std=c++17 -O2 ch09_avl_demo.cpp -o avl && ./avl
// 说明：整体作为一个 @SECTION 段，复制保存为 .cpp 即可单独编译运行。
// @SECTION 9.2.1 | 完整可编译示例：AVL 四种旋转
#include "ds_common.h"
#include <iomanip>

// ---------- 教材 9.2.1：平衡二叉排序树（BBST）结点 ----------
constexpr int LH = 1;    // 左高：bf = 左子树高 - 右子树高 = +1
constexpr int EH = 0;    // 等高
constexpr int RH = -1;   // 右高

struct BBSTNode {
    int key;
    int bf;                 // 平衡因子，只取 -1 / 0 / +1
    BBSTNode* lchild;
    BBSTNode* rchild;
    explicit BBSTNode(int k) : key(k), bf(EH), lchild(nullptr), rchild(nullptr) {}
};

// 记录本次插入触发的旋转类型，供逐步打印中间状态使用。
string g_rotType = "无旋转";

// 四种旋转的判别（bf = 左子树高 - 右子树高）：
//   LL：新结点落在「左孩子的左子树」→ lc->bf == LH → 对失衡根一次 R_Rotate；
//   RR：新结点落在「右孩子的右子树」→ rc->bf == RH → 一次 L_Rotate；
//   LR：新结点落在「左孩子的右子树」→ lc->bf == RH → 先 L_Rotate(T->lchild) 再 R_Rotate(T)；
//   RL：新结点落在「右孩子的左子树」→ rc->bf == LH → 先 R_Rotate(T->rchild) 再 L_Rotate(T)。
// 单次旋转 O(1)；插入沿一条路径回溯，至多触发一次平衡处理（双旋含两次旋转），总复杂度 O(log n)。

// 右旋（LL 型）：p 的左孩子 lc 升为新根，p 变为 lc 的右孩子。
// 关键：形参为指针的引用 BBSTNode*&，旋转后 p 直接指向新根，
// 双亲的 lchild/rchild（或树根）无需额外语句即完成「旋转后接回双亲」。
void R_Rotate(BBSTNode*& p) {
    BBSTNode* lc = p->lchild;
    p->lchild = lc->rchild;       // lc 的右子树转接为 p 的左子树
    lc->rchild = p;
    p = lc;                       // 引用回写：新根接回双亲
}

// 左旋（RR 型）：p 的右孩子 rc 升为新根，p 变为 rc 的左孩子，O(1)。
void L_Rotate(BBSTNode*& p) {
    BBSTNode* rc = p->rchild;
    p->rchild = rc->lchild;
    rc->lchild = p;
    p = rc;
}

// 左平衡（教材算法 9.10）：因在 T 的左子树插入而失衡（原 bf == LH）。
void LeftBalance(BBSTNode*& T) {
    BBSTNode* lc = T->lchild;
    if (lc->bf == LH) {                          // LL 型
        g_rotType = "LL 型旋转";
        T->bf = lc->bf = EH;
        R_Rotate(T);
    } else {                                     // LR 型：lc->bf == RH
        g_rotType = "LR 型旋转";
        BBSTNode* rd = lc->rchild;               // 新子树的根
        switch (rd->bf) {                        // 按 rd 的平衡因子修正 T 与 lc
            case LH: T->bf = RH; lc->bf = EH; break;
            case EH: T->bf = EH; lc->bf = EH; break;
            case RH: T->bf = EH; lc->bf = LH; break;
        }
        rd->bf = EH;
        L_Rotate(T->lchild);                     // 引用传参：左子树新根接回 T
        R_Rotate(T);                            // 再右旋 T，rd 成为整棵子树的新根
    }
}

// 右平衡（教材算法 9.12）：与左平衡镜像。
void RightBalance(BBSTNode*& T) {
    BBSTNode* rc = T->rchild;
    if (rc->bf == RH) {                          // RR 型
        g_rotType = "RR 型旋转";
        T->bf = rc->bf = EH;
        L_Rotate(T);
    } else {                                     // RL 型：rc->bf == LH
        g_rotType = "RL 型旋转";
        BBSTNode* ld = rc->lchild;
        switch (ld->bf) {
            case LH: T->bf = EH; rc->bf = RH; break;
            case EH: T->bf = EH; rc->bf = EH; break;
            case RH: T->bf = LH; rc->bf = EH; break;
        }
        ld->bf = EH;
        R_Rotate(T->rchild);
        L_Rotate(T);
    }
}

// 教材算法 9.11：插入关键字 e；taller 带回「子树是否长高」，供祖先判定失衡。
// 返回 FALSE 表示关键字已存在（不插入）；树高始终保持 O(log n)。
Status InsertAVL(BBSTNode*& T, int e, Status& taller) {
    if (!T) {                                    // 空树：造新结点，子树长高
        T = new BBSTNode(e);
        taller = TRUE;
        return TRUE;
    }
    if (e == T->key) { taller = FALSE; return FALSE; }   // 不插入重复关键字
    if (e < T->key) {
        if (!InsertAVL(T->lchild, e, taller)) return FALSE;
        if (taller) {
            switch (T->bf) {
                case LH: LeftBalance(T); taller = FALSE; break;  // 原左高 → 失衡
                case EH: T->bf = LH;     taller = TRUE;  break;  // 变左高，仍长高
                case RH: T->bf = EH;     taller = FALSE; break;  // 补齐高差，不长高
            }
        }
    } else {
        if (!InsertAVL(T->rchild, e, taller)) return FALSE;
        if (taller) {
            switch (T->bf) {
                case LH: T->bf = EH;      taller = FALSE; break;
                case EH: T->bf = RH;      taller = TRUE;  break;
                case RH: RightBalance(T); taller = FALSE; break;
            }
        }
    }
    return TRUE;
}

void InOrder(BBSTNode* t, vector<int>& out) {
    if (!t) return;
    InOrder(t->lchild, out);
    out.push_back(t->key);
    InOrder(t->rchild, out);
}

int Height(BBSTNode* t) {
    return t ? 1 + std::max(Height(t->lchild), Height(t->rchild)) : 0;
}

// 递归断言：每个结点 bf ∈ {-1,0,1} 且 bf == 左高 - 右高；返回以 t 为根的树高。
int CheckBalance(BBSTNode* t) {
    if (!t) return 0;
    int lh = CheckBalance(t->lchild);
    int rh = CheckBalance(t->rchild);
    DS_CHECK(t->bf >= -1 && t->bf <= 1);
    DS_CHECK(t->bf == lh - rh);
    return 1 + std::max(lh, rh);
}

bool AllBFZero(BBSTNode* t) {
    return !t || (t->bf == 0 && AllBFZero(t->lchild) && AllBFZero(t->rchild));
}

// 按层（广度优先）紧凑打印树形：各层用 | 分隔，空槽用 - 占位；std::setw 对齐成表格。
void PrintTree(BBSTNode* t) {
    cout << "  树形(层序): ";
    if (!t) { cout << "空\n"; return; }
    vector<BBSTNode*> cur{t};
    while (true) {
        vector<BBSTNode*> next;
        for (BBSTNode* p : cur) {
            string tok;
            if (p) {
                tok = std::to_string(p->key) + "/" + (p->bf >= 0 ? "+" : "") + std::to_string(p->bf);
                next.push_back(p->lchild);
                next.push_back(p->rchild);
            } else {
                tok = "-";
                next.push_back(nullptr);
                next.push_back(nullptr);
            }
            cout << std::setw(8) << tok;
        }
        bool hasReal = false;
        for (BBSTNode* p : next) if (p) { hasReal = true; break; }
        if (!hasReal) break;
        cout << " | ";
        cur = next;
    }
    cout << "\n";
}

void DestroyAVL(BBSTNode*& t) {
    if (!t) return;
    DestroyAVL(t->lchild);
    DestroyAVL(t->rchild);
    delete t;
    t = nullptr;
}

// 打印一次插入后的中间状态：旋转类型、新根、树高、中序序列。
void Report(int key, const string& rot, BBSTNode* root) {
    vector<int> seq;
    InOrder(root, seq);
    cout << "  插入 " << std::setw(2) << key
         << " → 触发 " << rot
         << " → 新根:" << std::setw(2) << root->key
         << " → 树高:" << Height(root) << " → 中序:";
    for (int x : seq) cout << std::setw(3) << x;
    cout << "\n";
}

int main() {
    Demo demo("9.2.1 AVL 四种旋转完整示例");

    // 四组序列分别只触发一种旋转，便于对照判别条件。
    vector<vector<int>> groups = {
        {30, 20, 10},   // LL：新结点落在左孩子的左子树
        {10, 20, 30},   // RR：新结点落在右孩子的右子树
        {30, 10, 20},   // LR：新结点落在左孩子的右子树
        {10, 30, 20}    // RL：新结点落在右孩子的左子树
    };
    vector<string> names = {"LL", "RR", "LR", "RL"};
    vector<int> expect{10, 20, 30};

    for (size_t g = 0; g < groups.size(); ++g) {
        cout << "[" << names[g] << " 型] 序列 {";
        for (size_t i = 0; i < groups[g].size(); ++i)
            cout << (i ? "," : "") << groups[g][i];
        cout << "}：逐步插入\n";
        BBSTNode* root = nullptr;
        for (int k : groups[g]) {
            g_rotType = "无旋转";
            Status taller = FALSE;
            InsertAVL(root, k, taller);
            Report(k, g_rotType, root);
            PrintTree(root);
        }
        vector<int> seq;
        InOrder(root, seq);
        DS_CHECK(root->key == 20);
        DS_CHECK(Height(root) == 2);
        DS_CHECK(CheckBalance(root) == 2);
        DS_CHECK(AllBFZero(root));
        DS_CHECK(seq == expect);
        cout << "  [" << names[g] << "] 断言通过：根=20 高=2 bf 全 0 中序 10 20 30\n";
        DestroyAVL(root);                         // main 结束前释放本组结点
    }

    // 综合：递增序列 1..15，验证动态平衡与高度上界 h <= 2*floor(log2(n+1))。
    cout << "[综合] 递增序列 1..15：检验 AVL 的动态平衡与 O(log n) 高度\n";
    BBSTNode* root15 = nullptr;
    vector<int> seq15, expect15;
    for (int k = 1; k <= 15; ++k) {
        expect15.push_back(k);
        Status taller = FALSE;
        InsertAVL(root15, k, taller);
    }
    InOrder(root15, seq15);
    int h = Height(root15);
    int bound = 2 * static_cast<int>(std::log2(15 + 1.0) + 1e-9);   // 2*4 = 8
    cout << "  中序:";
    for (int x : seq15) cout << std::setw(3) << x;
    cout << "\n";
    PrintTree(root15);
    cout << "  树高 h=" << h << "，上界 2*floor(log2(16))=" << bound << "\n";
    DS_CHECK(CheckBalance(root15) == h);
    DS_CHECK(seq15 == expect15);
    DS_CHECK(h <= bound);
    cout << "  [综合] 断言通过：bf 合法、中序 1..15、树高 " << h << " <= " << bound << "\n";
    DestroyAVL(root15);

    return 0;
}
// @ENDSECTION
