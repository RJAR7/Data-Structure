// ch06_tree.cpp —— 《数据结构(C 语言版)》第 6 章 树和二叉树 同步实现
// C++17 自含单文件：仅依赖 ds_common.h + 标准库。算法分节见 @SECTION / @ENDSECTION。
// 约定：教材 1-based 静态数组（SqBiTree / HuffmanTree / MFSet）均在注释中标注与 STL 0-based 的差异。
#include "ds_common.h"

// @SECTION 6.2 | 二叉树的存储结构与建立
// ① 顺序存储 SqBiTree：按完全二叉树层序编号 1..n 存入。教材是 1-based 静态数组（0 号弃用），
// 此处用 STL vector（本身 0-based），刻意让 v[0] 占位弃用，使 v[i] 直接对应编号 i，
// 从而 i/2、2i、2i+1 与教材性质 5 逐字一致；其余 STL 容器一律 0-based。
using SqBiTree = vector<char>;
// 性质 5：i>1 双亲为 floor(i/2)；2i<=n 时左孩子 2i；2i+1<=n 时右孩子 2i+1；返回 0 表示不存在。
inline int ParentIndex(int i) { return i > 1 ? i / 2 : 0; }
inline int LeftChildIndex(int i, int n) { return 2 * i <= n ? 2 * i : 0; }
inline int RightChildIndex(int i, int n) { return 2 * i + 1 <= n ? 2 * i + 1 : 0; }
// 构造含 n 个结点的完全二叉树(A,B,C,...)；时间 O(n)、空间 O(n)。
void BuildCompleteSqBiTree(SqBiTree& bt, int n) {
    bt.assign(n + 1, '#');                 // bt[0] 占位，有效下标 1..n
    for (int i = 1; i <= n; ++i) bt[i] = char('A' + i - 1);
}
// ② 二叉链表存储结构（教材 6.2.3）
struct BiTNode {
    char data;
    BiTNode *lchild, *rchild;
};
using BiTree = BiTNode*;
// CreateBiTree：按带 '#' 空标记的先序序列递归建立（教材算法 6.4；教材用空格、此处用 '#'）。
// 时间 O(n)、空间 O(h)（h 为树高，即递归栈深度）。
void CreateBiTree(BiTree& T, const string& pre, int& idx) {
    if (idx >= (int)pre.size() || pre[idx] == '#') {
        if (idx < (int)pre.size()) ++idx;  // 跳过空标记
        T = nullptr;
        return;
    }
    T = new BiTNode{pre[idx++], nullptr, nullptr};
    CreateBiTree(T->lchild, pre, idx);
    CreateBiTree(T->rchild, pre, idx);
}
// DestroyBiTree：后序释放全部结点；引用形参置空，避免悬垂指针与重复释放。时间 O(n)、空间 O(h)。
void DestroyBiTree(BiTree& T) {
    if (!T) return;
    DestroyBiTree(T->lchild);
    DestroyBiTree(T->rchild);
    delete T;
    T = nullptr;
}
// @ENDSECTION

// @SECTION 6.3.1 | 遍历二叉树与遍历的应用
// 递归三种遍历结构相同、仅 Visit 位置不同：时间 O(n)、空间 O(h)（递归栈，退化单链时 O(n)）。
void PreOrderTraverse(BiTree T, const std::function<void(char)>& Visit) {
    if (!T) return;
    Visit(T->data);
    PreOrderTraverse(T->lchild, Visit);
    PreOrderTraverse(T->rchild, Visit);
}
void InOrderTraverse(BiTree T, const std::function<void(char)>& Visit) {
    if (!T) return;
    InOrderTraverse(T->lchild, Visit);
    Visit(T->data);
    InOrderTraverse(T->rchild, Visit);
}
void PostOrderTraverse(BiTree T, const std::function<void(char)>& Visit) {
    if (!T) return;
    PostOrderTraverse(T->lchild, Visit);
    PostOrderTraverse(T->rchild, Visit);
    Visit(T->data);
}
// 非递归中序：栈模拟递归，一路向左入栈、弹出访问、转向右子树。时间 O(n)、空间 O(h)。
void InOrderTraverse_Iter(BiTree T, const std::function<void(char)>& Visit) {
    std::stack<BiTree> S;
    BiTree p = T;
    while (p || !S.empty()) {
        if (p) { S.push(p); p = p->lchild; }
        else { p = S.top(); S.pop(); Visit(p->data); p = p->rchild; }
    }
}
// 非递归先序：访问后先压右孩子、再压左孩子（栈后进先出）。时间 O(n)、空间 O(h)。
void PreOrderTraverse_Iter(BiTree T, const std::function<void(char)>& Visit) {
    if (!T) return;
    std::stack<BiTree> S;
    S.push(T);
    while (!S.empty()) {
        BiTree p = S.top(); S.pop();
        Visit(p->data);
        if (p->rchild) S.push(p->rchild);
        if (p->lchild) S.push(p->lchild);
    }
}
// 层序遍历：辅助队列，时间 O(n)、空间 O(w)（w 为最大层宽）。
void LevelOrderTraverse(BiTree T, const std::function<void(char)>& Visit) {
    if (!T) return;
    std::queue<BiTree> Q;
    Q.push(T);
    while (!Q.empty()) {
        BiTree p = Q.front(); Q.pop();
        Visit(p->data);
        if (p->lchild) Q.push(p->lchild);
        if (p->rchild) Q.push(p->rchild);
    }
}
// 遍历的应用：深度（后序）、叶子数、结点数、交换左右子树。均时间 O(n)、空间 O(h)。
int BiTreeDepth(BiTree T) {
    return T ? 1 + std::max(BiTreeDepth(T->lchild), BiTreeDepth(T->rchild)) : 0;
}
int CountLeaves(BiTree T) {
    if (!T) return 0;
    return (!T->lchild && !T->rchild) ? 1 : CountLeaves(T->lchild) + CountLeaves(T->rchild);
}
int NodeCount(BiTree T) {
    return T ? 1 + NodeCount(T->lchild) + NodeCount(T->rchild) : 0;
}
void ExchangeBiTree(BiTree T) {
    if (!T) return;
    std::swap(T->lchild, T->rchild);
    ExchangeBiTree(T->lchild);
    ExchangeBiTree(T->rchild);
}
// @ENDSECTION

// @SECTION 6.3.1 | 由遍历序列重建二叉树
// 先序+中序：先序首元素为根，在中序定位根切分左右子树（只有中序能分左右）。
// 每层线性查根，时间 O(n^2)、空间 O(h)；失败时 ok=false 且回收已建结点、不泄漏。
BiTree BuildTreeFromPreIn(const string& pre, int pl, int pr,
                          const string& in, int il, int ir, bool& ok) {
    if (pl > pr) return nullptr;
    if (pr - pl != ir - il) { ok = false; return nullptr; }  // 长度校验
    char root = pre[pl];
    int k = il;
    while (k <= ir && in[k] != root) ++k;
    if (k > ir) { ok = false; return nullptr; }              // 根不在中序中
    int leftLen = k - il;
    BiTree T = new BiTNode{root, nullptr, nullptr};
    T->lchild = BuildTreeFromPreIn(pre, pl + 1, pl + leftLen, in, il, k - 1, ok);
    T->rchild = BuildTreeFromPreIn(pre, pl + leftLen + 1, pr, in, k + 1, ir, ok);
    return T;
}
BiTree BuildTreeFromPreIn(const string& pre, const string& in, bool& ok) {
    ok = true;
    int n = (int)pre.size();
    if (n == 0 || n != (int)in.size()) { ok = false; return nullptr; }  // 长度校验
    BiTree T = BuildTreeFromPreIn(pre, 0, n - 1, in, 0, n - 1, ok);
    if (!ok) { DestroyBiTree(T); return nullptr; }           // 失败回收
    return T;
}
// 中序+后序（二选一之另一种）：后序末元素为根，同样在中序切分。复杂度同上。
BiTree BuildTreeFromInPost(const string& in, int il, int ir,
                           const string& post, int pl, int pr, bool& ok) {
    if (pl > pr) return nullptr;
    if (pr - pl != ir - il) { ok = false; return nullptr; }
    char root = post[pr];
    int k = il;
    while (k <= ir && in[k] != root) ++k;
    if (k > ir) { ok = false; return nullptr; }
    int leftLen = k - il;
    BiTree T = new BiTNode{root, nullptr, nullptr};
    T->lchild = BuildTreeFromInPost(in, il, k - 1, post, pl, pl + leftLen - 1, ok);
    T->rchild = BuildTreeFromInPost(in, k + 1, ir, post, pl + leftLen, pr - 1, ok);
    return T;
}
BiTree BuildTreeFromInPost(const string& in, const string& post, bool& ok) {
    ok = true;
    int n = (int)in.size();
    if (n == 0 || n != (int)post.size()) { ok = false; return nullptr; }
    BiTree T = BuildTreeFromInPost(in, 0, n - 1, post, 0, n - 1, ok);
    if (!ok) { DestroyBiTree(T); return nullptr; }
    return T;
}
// @ENDSECTION

// @SECTION 6.3.2 | 线索二叉树
// 利用二叉链表的 n+1 个空指针域存前驱/后继线索；Link=0 指孩子、Thread=1 指线索。
// 中序线索化时间 O(n)、空间 O(h)；线索遍历时间 O(n)、空间 O(1)（不需递归/栈）。
enum PointerTag { Link = 0, Thread = 1 };
struct BiThrNode {
    char data;
    BiThrNode *lchild, *rchild;
    PointerTag ltag, rtag;
};
using BiThrTree = BiThrNode*;
// 由普通二叉链表复制出待线索化的 BiThrNode 树（空孩子预置为 Thread、值为 nullptr）
BiThrTree CopyBiTreeToThr(BiTree T) {
    if (!T) return nullptr;
    BiThrTree p = new BiThrNode();
    p->data = T->data;
    p->lchild = CopyBiTreeToThr(T->lchild);
    p->rchild = CopyBiTreeToThr(T->rchild);
    p->ltag = p->lchild ? Link : Thread;
    p->rtag = p->rchild ? Link : Thread;
    return p;
}
// 中序线索化：pre 用引用（代替教材全局变量）始终指向刚访问过的结点
void InThreading(BiThrTree p, BiThrTree& pre) {
    if (!p) return;
    InThreading(p->lchild, pre);
    if (!p->lchild) { p->ltag = Thread; p->lchild = pre; }
    if (!pre->rchild) { pre->rtag = Thread; pre->rchild = p; }
    pre = p;
    InThreading(p->rchild, pre);
}
// 加头结点建立中序线索链表：Thrt->lchild 指向根、Thrt->rchild 指向中序末结点
void InOrderThreading(BiThrTree& Thrt, BiThrTree T) {
    Thrt = new BiThrNode();
    Thrt->data = '\0'; Thrt->ltag = Link; Thrt->rtag = Thread;
    Thrt->rchild = Thrt;                 // 先回指自己，避免被 InThreading 改写
    if (!T) { Thrt->lchild = Thrt; return; }
    Thrt->lchild = T;
    BiThrTree pre = Thrt;
    InThreading(T, pre);
    pre->rchild = Thrt; pre->rtag = Thread;   // 末结点后继指向头结点
    Thrt->rchild = pre;                       // 头结点右指针指向末结点
}
// 利用线索非递归中序遍历，T 为头结点
void InOrderTraverse_Thr(BiThrTree Thrt, const std::function<void(char)>& Visit) {
    BiThrTree p = Thrt->lchild;
    while (p != Thrt) {
        while (p->ltag == Link && p->lchild) p = p->lchild;   // 找中序首结点
        Visit(p->data);
        while (p->rtag == Thread && p->rchild != Thrt) {
            p = p->rchild; Visit(p->data);
        }
        p = p->rchild;                       // 转向右子树（或回到头结点结束）
    }
}
// 释放：线索指针非拥有关系，按中序收集所有结点后统一 delete，避免重复释放
void DestroyBiThrTree(BiThrTree& Thrt) {
    if (!Thrt) return;
    vector<BiThrTree> nodes;
    BiThrTree p = Thrt->lchild;
    while (p && p != Thrt) {
        while (p->ltag == Link && p->lchild) p = p->lchild;
        nodes.push_back(p);
        while (p->rtag == Thread && p->rchild && p->rchild != Thrt) {
            p = p->rchild; nodes.push_back(p);
        }
        p = p->rchild;
    }
    for (BiThrNode* q : nodes) delete q;
    delete Thrt;
    Thrt = nullptr;
}
// @ENDSECTION

// @SECTION 6.4 | 树的三种存储结构
// ① 双亲表示法：parent 为双亲下标、根为 -1；找双亲 O(1)、找孩子需 O(n) 扫描。
// 教材 nodes[1..n] 为 1-based；此处 STL vector 0-based（下标 0 即根位置 r=0），语义一致。
struct PTNode { char data; int parent; };
struct PTree { vector<PTNode> nodes; int r = 0, n = 0; };
int Parent_PT(const PTree& T, int i) {                 // 时间 O(1)
    return (i < 0 || i >= T.n) ? -1 : T.nodes[i].parent;
}
// ② 孩子链表：每个结点的孩子链成单链表；找孩子 O(结点的度)、找双亲需遍历。
struct CTNode { int child; CTNode* next; };
struct CTBox { char data; CTNode* firstchild; };
struct CTree { vector<CTBox> nodes; int n = 0, r = 0; };
void AddChild_CT(CTree& T, int parent, int child) {     // 头插挂孩子，时间 O(1)
    T.nodes[parent].firstchild = new CTNode{child, T.nodes[parent].firstchild};
}
void DestroyCTree(CTree& T) {                          // 释放所有边结点，时间 O(n+边数)
    for (auto& box : T.nodes) {
        CTNode* p = box.firstchild;
        while (p) { CTNode* q = p->next; delete p; p = q; }
        box.firstchild = nullptr;
    }
}
// ③ 孩子-兄弟（二叉链表）：firstchild 指第一个孩子、nextsibling 指下一兄弟。
struct CSNode { char data; CSNode *firstchild, *nextsibling; };
using CSTree = CSNode*;
CSTree NewCSNode(char c) { return new CSNode{c, nullptr, nullptr}; }
void DestroyCSTree(CSTree& T) {                        // 沿两条指针后序释放，时间 O(n)、空间 O(h)
    if (!T) return;
    DestroyCSTree(T->firstchild);
    DestroyCSTree(T->nextsibling);
    delete T;
    T = nullptr;
}
// @ENDSECTION

// @SECTION 6.4 | 森林与二叉树的转换及遍历
// 口诀「左孩子、右兄弟」：树/森林转二叉树后，单棵树的根必无右孩子。
// firstchild→lchild、nextsibling→rchild，时间 O(n)、空间 O(h)。
BiTree TreeToBinary(CSTree T) {
    if (!T) return nullptr;
    BiTree B = new BiTNode{T->data, nullptr, nullptr};
    B->lchild = TreeToBinary(T->firstchild);
    B->rchild = TreeToBinary(T->nextsibling);
    return B;
}
// 森林的孩子-兄弟表示即一条根兄弟链，ForestToBinary 与 TreeToBinary 是同一映射。
BiTree ForestToBinary(CSTree F) { return TreeToBinary(F); }
// 树先根：先访问根，再依次先根遍历各子树；对应转换后二叉树的先序。时间 O(n)、空间 O(h)。
void PreRootTraverse(CSTree T, const std::function<void(char)>& Visit) {
    if (!T) return;
    Visit(T->data);
    for (CSNode* c = T->firstchild; c; c = c->nextsibling) PreRootTraverse(c, Visit);
}
// 树后根：先依次后根遍历各子树，再访问根；对应转换后二叉树的中序。
void PostRootTraverse(CSTree T, const std::function<void(char)>& Visit) {
    if (!T) return;
    for (CSNode* c = T->firstchild; c; c = c->nextsibling) PostRootTraverse(c, Visit);
    Visit(T->data);
}
// 森林先序 = 依次对每棵树先根；森林中序 = 依次对每棵树后根（名称来自二叉树中序对应）。
void ForestPreTraverse(CSTree F, const std::function<void(char)>& Visit) {
    for (CSNode* t = F; t; t = t->nextsibling) PreRootTraverse(t, Visit);
}
void ForestInTraverse(CSTree F, const std::function<void(char)>& Visit) {
    for (CSNode* t = F; t; t = t->nextsibling) PostRootTraverse(t, Visit);
}
// @ENDSECTION

// @SECTION 6.5 | 并查集 MFSet 与 DisjointSet
// 数组双亲表示森林：根 parent 存集合规模的负值、非根存双亲下标。
// 教材 1-based 且用 parent>0 判「未到根」；此处 STL vector 0-based、判据改为 parent>=0
// （因下标 0 也是合法双亲），教材 1-based 中下标恒 >=1 才用 >0。
struct MFSet { vector<int> parent; int n = 0; };
void initial_mfset(MFSet& S, int n) { S.n = n; S.parent.assign(n, -1); }  // O(n)
void Initial(MFSet& S, int n) { initial_mfset(S, n); }                    // 同义别名
int find_mfset(const MFSet& S, int i) {                                     // 朴素查找 O(树高)
    if (i < 0 || i >= S.n) return -1;
    int j = i;
    while (S.parent[j] >= 0) j = S.parent[j];
    return j;
}
int Find_MFSet(const MFSet& S, int i) { return find_mfset(S, i); }
void merge_mfset(MFSet& S, int i, int j) {                                  // 教材朴素合并 O(1)
    if (i == j || i < 0 || i >= S.n || j < 0 || j >= S.n) return;
    S.parent[j] = i;              // 可能退化成单链；勿与加权合并混用
}
void mix_mfset(MFSet& S, int i, int j) {                                    // 按规模（加权）合并 O(1)
    if (i == j || i < 0 || i >= S.n || j < 0 || j >= S.n) return;
    if (S.parent[i] > S.parent[j]) std::swap(i, j);   // 负值大者规模小，换到 j
    S.parent[i] += S.parent[j];   // 累加规模
    S.parent[j] = i;              // 小树挂大树
}
void Mix_MFSet(MFSet& S, int i, int j) { mix_mfset(S, i, j); }
int fix_mfset(MFSet& S, int i) {                                            // 路径压缩，分摊近 O(α(n))
    if (i < 0 || i >= S.n) return -1;
    int j = i;
    while (S.parent[j] >= 0) j = S.parent[j];
    while (i != j) { int t = S.parent[i]; S.parent[i] = j; i = t; }
    return j;
}
// DisjointSet：union by rank + path compression 的完整 C++ 封装（0-based）。
class DisjointSet {
    vector<int> parent, rank_;
public:
    explicit DisjointSet(int n) : parent(n), rank_(n, 0) {
        for (int i = 0; i < n; ++i) parent[i] = i;
    }
    int Find(int x) { return parent[x] == x ? x : parent[x] = Find(parent[x]); }
    void Union(int a, int b) {
        int ra = Find(a), rb = Find(b);
        if (ra == rb) return;
        if (rank_[ra] < rank_[rb]) std::swap(ra, rb);
        parent[rb] = ra;
        if (rank_[ra] == rank_[rb]) ++rank_[ra];
    }
    bool Connected(int a, int b) { return Find(a) == Find(b); }
};
// @ENDSECTION

// @SECTION 6.6 | 赫夫曼树与赫夫曼编码
// HT/HC 用 1-based：HT[0]、HC[0] 弃用，有效下标 1..m / 1..n（m=2n-1）。
// STL vector 本身 0-based，故分配 m+1 / n+1 个单元，让下标与教材算法 6.12 逐字一致。
struct HTNode { unsigned weight; int parent, lchild, rchild; };
using HuffmanTree = vector<HTNode>;
using HuffmanCode = vector<string>;          // 教材 char**，此处换成 string 自动管理内存
// Select：在 HT[1..k] 中选 parent==0 且权值最小的两个下标 s1、s2。时间 O(k)。
void Select(const HuffmanTree& HT, int k, int& s1, int& s2) {
    s1 = s2 = 0;
    unsigned w1 = std::numeric_limits<unsigned>::max(), w2 = w1;
    for (int i = 1; i <= k; ++i) {
        if (HT[i].parent != 0) continue;                 // 只选尚未合并（无双亲）的结点
        if (HT[i].weight < w1) { w2 = w1; s2 = s1; w1 = HT[i].weight; s1 = i; }
        else if (HT[i].weight < w2) { w2 = HT[i].weight; s2 = i; }
    }
}
// HuffmanCoding（教材算法 6.12）：构造 HT 并从叶子逆向回溯到根求编码。时间 O(n^2)、空间 O(n)。
void HuffmanCoding(HuffmanTree& HT, HuffmanCode& HC, const vector<int>& w, int n) {
    if (n <= 1) return;
    int m = 2 * n - 1;
    HT.assign(m + 1, HTNode{0u, 0, 0, 0});              // HT[0] 占位
    for (int i = 1; i <= n; ++i) HT[i].weight = (unsigned)w[i - 1];
    for (int i = n + 1; i <= m; ++i) {
        int s1 = 0, s2 = 0;
        Select(HT, i - 1, s1, s2);
        HT[s1].parent = HT[s2].parent = i;
        HT[i].lchild = s1; HT[i].rchild = s2;
        HT[i].weight = HT[s1].weight + HT[s2].weight;
    }
    HC.assign(n + 1, string());                          // HC[0] 占位，HC[i] 对应 w[i-1]
    string cd(n - 1, '0');                               // 编码最长 n-1 位：缓冲区不预留多余尾部字符
    for (int i = 1; i <= n; ++i) {
        int start = n - 1, c = i, f = HT[i].parent;
        while (f != 0) {                                 // 从叶子到根逆向
            cd[--start] = (HT[f].lchild == c) ? '0' : '1';
            c = f; f = HT[f].parent;
        }
        HC[i] = cd.substr(start);
    }
}
// WPL = Σ 叶子权值×路径长度；由 HT 逐叶子向上数层数。时间 O(n·h)、空间 O(1)。
unsigned WPL(const HuffmanTree& HT, int n) {
    unsigned wpl = 0;
    for (int i = 1; i <= n; ++i) {
        int depth = 0, c = i;
        while (HT[c].parent != 0) { ++depth; c = HT[c].parent; }
        wpl += HT[i].weight * (unsigned)depth;
    }
    return wpl;
}
// Decoding：从根 m 出发按 0/1 下行，到叶子输出对应下标并回到根。时间 O(码长)、空间 O(1)。
vector<int> Decoding(const HuffmanTree& HT, const string& bits, int n) {
    vector<int> out;
    int m = 2 * n - 1, p = m;
    for (char b : bits) {
        p = (b == '0') ? HT[p].lchild : HT[p].rchild;
        if (HT[p].lchild == 0 && HT[p].rchild == 0) { out.push_back(p); p = m; }
    }
    return out;
}
// 前缀码校验：任意两码字互不为前缀。时间 O(n^2·L)、空间 O(1)。
bool IsPrefixCode(const HuffmanCode& HC, int n) {
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j) {
            if (i == j) continue;
            if (HC[i].size() <= HC[j].size() && HC[j].compare(0, HC[i].size(), HC[i]) == 0)
                return false;
        }
    return true;
}
// @ENDSECTION

// @SECTION 6.7 | 回溯法输出根到叶全部路径
// 先序 DFS + 栈保存当前路径：进入结点 push、离开时 pop（回溯），到叶子输出一条根→叶路径。
// 时间 O(n)（含输出 O(n·h)）、空间 O(h)（递归栈 + 路径栈）。
void AllPath(BiTree T, std::stack<char>& path, vector<string>& out) {
    if (!T) return;
    path.push(T->data);
    if (!T->lchild && !T->rchild) {
        std::stack<char> tmp = path;                  // 拷贝，避免破坏回溯路径
        string s;
        while (!tmp.empty()) { s += tmp.top(); tmp.pop(); }
        std::reverse(s.begin(), s.end());            // 栈顶是叶、栈底是根
        out.push_back(s);
    } else {
        AllPath(T->lchild, path, out);
        AllPath(T->rchild, path, out);
    }
    path.pop();                                       // 回溯
}
vector<string> AllPath(BiTree T) {
    vector<string> out;
    std::stack<char> path;
    AllPath(T, path, out);
    return out;
}
// @ENDSECTION

// @SECTION 6.8 | 树的计数（Catalan 数）
// n 个结点的不同形态二叉树数 h(n)=C(2n,n)/(n+1)。DP：h(0)=1，
// h(n)=Σ h(i)·h(n-1-i)（i=0..n-1），即左/右子树形态数相乘后求和。时间 O(n^2)、空间 O(n)。
vector<long long> CatalanDP(int N) {
    vector<long long> h(N + 1, 0);
    h[0] = 1;                                         // 空树算一种形态
    for (int n = 1; n <= N; ++n)
        for (int i = 0; i <= n - 1; ++i) h[n] += h[i] * h[n - 1 - i];
    return h;
}
// 闭式验算：先用 c=c*(n+k)/k 递推算 C(2n,n)，再除以 n+1；整除性由组合数保证。
long long CatalanClosed(int n) {
    long long c = 1;
    for (int k = 1; k <= n; ++k) c = c * (n + k) / k;
    return c / (n + 1);
}
// @ENDSECTION

// 把任意以 std::function 为 Visit 的遍历结果收集进 vector（C++11 模板函数，替代原泛型 lambda）
// Fn 接收签名为 void(Tree, const std::function<void(char)>&) 的可调用对象；此处为二叉链表树
template<class Fn>
vector<char> collect(Fn fn, BiTree t) {
    vector<char> v;
    fn(t, [&](char c) { v.push_back(c); });
    return v;
}
// 同上，针对孩子-兄弟（森林）遍历函数
template<class Fn>
vector<char> csCollect(Fn fn, CSTree t) {
    vector<char> v;
    fn(t, [&](char c) { v.push_back(c); });
    return v;
}

int main() {
    // 测试树 A(B(D,E), C(,F))：先序串用 '#' 标空（教材算法 6.4）
    const string kNullPre = "ABD##E##C#F##";
    const string kPre = "ABDECF", kIn = "DBEACF", kPost = "DEBFCA", kLevel = "ABCDEF";
    auto toVec = [](const string& s) { return vector<char>(s.begin(), s.end()); };
    auto toStr = [](const vector<char>& v) { return string(v.begin(), v.end()); };
    BiTree T = nullptr;            // 主测试树，main 结束前统一释放
    BiThrTree Thrt = nullptr;      // 线索树头结点，main 结束前统一释放

    // ---------------- 6.2 ----------------
    {
        Demo d("6.2 顺序存储(性质5)与二叉链表");
        SqBiTree sq;
        BuildCompleteSqBiTree(sq, 7);
        DS_CHECK((int)sq.size() == 8);                 // sq[0] 占位，1..7 有效
        DS_CHECK(sq[1] == 'A' && sq[7] == 'G');
        DS_CHECK(ParentIndex(3) == 1 && ParentIndex(1) == 0);
        DS_CHECK(LeftChildIndex(3, 7) == 6 && RightChildIndex(3, 7) == 7);
        DS_CHECK(LeftChildIndex(4, 7) == 0 && RightChildIndex(4, 7) == 0);
        cout << "SqBiTree[1..7]: ";
        printSeq(vector<char>(sq.begin() + 1, sq.end()));
        int idx = 0;
        CreateBiTree(T, kNullPre, idx);
        DS_CHECK(T != nullptr && idx == (int)kNullPre.size() && NodeCount(T) == 6);
        cout << "CreateBiTree 读入字符数/结点数: " << idx << "/" << NodeCount(T) << "\n";
    }

    // ---------------- 6.3.1 ----------------
    {
        Demo d("6.3.1 遍历 / 应用 / 由序列重建");
        vector<char> pre = collect(PreOrderTraverse, T), in = collect(InOrderTraverse, T);
        vector<char> post = collect(PostOrderTraverse, T), lvl = collect(LevelOrderTraverse, T);
        DS_CHECK(pre == toVec(kPre) && in == toVec(kIn));
        DS_CHECK(post == toVec(kPost) && lvl == toVec(kLevel));
        cout << "先/中/后/层序: " << toStr(pre) << " " << toStr(in) << " "
             << toStr(post) << " " << toStr(lvl) << "\n";
        printSeq(collect(InOrderTraverse_Iter, T), "非递归中序");
        DS_CHECK(collect(InOrderTraverse_Iter, T) == in);
        DS_CHECK(collect(PreOrderTraverse_Iter, T) == pre);
        DS_CHECK(BiTreeDepth(T) == 3 && CountLeaves(T) == 3 && NodeCount(T) == 6);
        cout << "深度/叶子/结点: " << BiTreeDepth(T) << "/" << CountLeaves(T)
             << "/" << NodeCount(T) << "\n";
        ExchangeBiTree(T); ExchangeBiTree(T);           // 交换两次还原
        DS_CHECK(collect(InOrderTraverse, T) == in);
        bool ok = true;
        BiTree T2 = BuildTreeFromPreIn(kPre, kIn, ok);
        DS_CHECK(ok && T2 != nullptr);
        DS_CHECK(collect(PreOrderTraverse, T2) == pre);
        DS_CHECK(collect(InOrderTraverse, T2) == in);
        DestroyBiTree(T2);
        ok = true;                                       // 长度校验：不等长应失败
        BiTree T3 = BuildTreeFromPreIn("ABDECF", "DBEA", ok);
        DS_CHECK(!ok && T3 == nullptr);
        DestroyBiTree(T3);
        ok = true;
        BiTree T4 = BuildTreeFromInPost(kIn, kPost, ok);
        DS_CHECK(ok && T4 && collect(PreOrderTraverse, T4) == pre);
        DestroyBiTree(T4);
        cout << "重建(先中/中后/非法长度)与 Exchange 均通过\n";
    }

    // ---------------- 6.3.2 ----------------
    {
        Demo d("6.3.2 线索二叉树");
        BiThrTree root = CopyBiTreeToThr(T);
        InOrderThreading(Thrt, root);   // root 交由线索链表，统一由 DestroyBiThrTree 释放
        root = nullptr;                 // 所有权移交，避免悬垂指针
        vector<char> seqThr;
        InOrderTraverse_Thr(Thrt, [&](char c) { seqThr.push_back(c); });
        DS_CHECK(seqThr == collect(InOrderTraverse, T));   // 线索序列 == 递归中序
        cout << "线索中序: "; printSeq(seqThr);
    }

    // ---------------- 6.4 ----------------
    {
        Demo d("6.4 树的存储 / 森林与二叉树转换");
        PTree pt;
        pt.nodes = {{'A', -1}, {'B', 0}, {'C', 0}, {'D', 1}};
        pt.n = 4; pt.r = 0;
        DS_CHECK(Parent_PT(pt, 3) == 1 && Parent_PT(pt, 0) == -1);   // 找双亲 O(1)
        CTree ct;
        ct.nodes = {{'A', nullptr}, {'B', nullptr}, {'C', nullptr}, {'D', nullptr}};
        ct.n = 4; ct.r = 0;
        AddChild_CT(ct, 0, 1); AddChild_CT(ct, 0, 2); AddChild_CT(ct, 1, 3);
        int childCnt = 0;
        for (CTNode* p = ct.nodes[0].firstchild; p; p = p->next) ++childCnt;
        DS_CHECK(childCnt == 2);
        cout << "PTree(3)的双亲 / CTree A的孩子数: " << Parent_PT(pt, 3) << " / " << childCnt << "\n";
        DestroyCTree(ct);
        // 孩子-兄弟森林 F：树1 A(B(D), C) 与树2 E(F) 用 nextsibling 相连
        CSNode* nA = NewCSNode('A'), *nB = NewCSNode('B'), *nC = NewCSNode('C');
        CSNode* nD = NewCSNode('D'), *nE = NewCSNode('E'), *nF = NewCSNode('F');
        nA->firstchild = nB; nB->firstchild = nD; nB->nextsibling = nC;
        nA->nextsibling = nE; nE->firstchild = nF;
        CSTree F = nA;
        CSNode* saved = nA->nextsibling; nA->nextsibling = nullptr;   // 临时取单棵树
        BiTree b1 = TreeToBinary(F);
        nA->nextsibling = saved;
        DS_CHECK(b1->rchild == nullptr);                 // 单棵树转换：根无右孩子
        DS_CHECK(csCollect(PreRootTraverse, F) == collect(PreOrderTraverse, b1));
        DS_CHECK(csCollect(PostRootTraverse, F) == collect(InOrderTraverse, b1));
        BiTree bf = ForestToBinary(F);
        DS_CHECK(bf->rchild != nullptr);                 // 森林转换：根有右子树
        DS_CHECK(csCollect(ForestPreTraverse, F) == collect(PreOrderTraverse, bf));
        DS_CHECK(csCollect(ForestInTraverse, F) == collect(InOrderTraverse, bf));
        cout << "森林先序/二叉树先序: "; printSeq(csCollect(ForestPreTraverse, F));
        cout << "森林中序/二叉树中序: "; printSeq(csCollect(ForestInTraverse, F));
        DestroyBiTree(b1);
        DestroyBiTree(bf);
        DestroyCSTree(F);
    }

    // ---------------- 6.5 ----------------
    {
        Demo d("6.5 并查集 MFSet / DisjointSet");
        MFSet S;
        Initial(S, 10);                                  // 10 人 0..9（教材 1..10 转 0-based）
        const int pairs[][2] = {{0,1},{2,3},{4,1},{3,5},{1,5},{7,6},{8,6},{0,5}};
        cout << "合并过程(根a,b): ";
        for (auto& e : pairs) {
            int ra = fix_mfset(S, e[0]), rb = Find_MFSet(S, e[1]);
            cout << ra << (ra == rb ? "=" : "+") << rb << " ";
            if (ra != rb) Mix_MFSet(S, ra, rb);
        }
        cout << "\n";
        DS_CHECK(fix_mfset(S, 4) == fix_mfset(S, 5));   // 5 与 6 同集合
        DS_CHECK(fix_mfset(S, 4) != fix_mfset(S, 6));   // 5 与 7 不同集合
        vector<int> roots;
        for (int i = 0; i < 10; ++i) {
            int r = fix_mfset(S, i);
            if (std::find(roots.begin(), roots.end(), r) == roots.end()) roots.push_back(r);
        }
        DS_CHECK((int)roots.size() == 3);                // 3 个等价类
        cout << "等价类根: "; printSeq(roots);
        DisjointSet ds(10);
        for (auto& e : pairs) ds.Union(e[0], e[1]);
        DS_CHECK(ds.Connected(4, 5) && !ds.Connected(4, 6));
        int cnt = 0;
        for (int i = 0; i < 10; ++i) if (ds.Find(i) == i) ++cnt;
        DS_CHECK(cnt == 3);
        cout << "DisjointSet: 4~5=" << ds.Connected(4,5) << ", 4~6=" << ds.Connected(4,6) << "\n";
    }

    // ---------------- 6.6 ----------------
    {
        Demo d("6.6 赫夫曼树与编码");
        vector<int> w = {5, 29, 7, 8, 14, 23, 3, 11};   // 经典 8 权值
        HuffmanTree HT; HuffmanCode HC;
        HuffmanCoding(HT, HC, w, 8);
        cout << "赫夫曼编码: ";
        for (int i = 1; i <= 8; ++i) cout << w[i - 1] << ":" << HC[i] << " ";
        cout << "\n";
        DS_CHECK(IsPrefixCode(HC, 8));
        unsigned wpl = WPL(HT, 8), wpl2 = 0;
        for (int i = 1; i <= 8; ++i) wpl2 += (unsigned)w[i - 1] * (unsigned)HC[i].size();
        // 最小堆（std::greater 比较器）独立算 WPL，验证 Select 的最优性
        std::priority_queue<unsigned, vector<unsigned>, std::greater<unsigned>> pq;
        for (int x : w) pq.push((unsigned)x);
        unsigned wpl3 = 0;
        while (pq.size() > 1) {
            unsigned a = pq.top(); pq.pop();
            unsigned b = pq.top(); pq.pop();
            wpl3 += a + b; pq.push(a + b);
        }
        DS_CHECK(wpl == wpl2 && wpl == wpl3 && wpl == 271u);
        cout << "WPL=" << wpl << " (HT/编码/最小堆三者一致)\n";
        string bits;
        for (int i = 1; i <= 8; ++i) bits += HC[i];
        vector<int> dec = Decoding(HT, bits, 8);
        vector<int> expect;
        for (int i = 1; i <= 8; ++i) expect.push_back(i);
        DS_CHECK(dec == expect);
        cout << "译码还原: "; printSeq(dec);
    }

    // ---------------- 6.7 / 6.8 ----------------
    {
        Demo d("6.7 回溯路径 / 6.8 树的计数");
        vector<string> paths = AllPath(T);
        DS_CHECK((int)paths.size() == CountLeaves(T));
        cout << "根到叶路径: "; printSeq(paths);
        vector<long long> h = CatalanDP(10);
        DS_CHECK(h[1] == 1 && h[2] == 2 && h[3] == 5 && h[4] == 14 && h[5] == 42);
        for (int n = 0; n <= 10; ++n) DS_CHECK(h[n] == CatalanClosed(n));
        cout << "Catalan h(1..10): ";
        for (int n = 1; n <= 10; ++n) cout << h[n] << ' ';
        cout << "\n";
    }

    // main 结束前释放所有 new 出来的结点
    DestroyBiTree(T);
    DestroyBiThrTree(Thrt);
    return 0;
}
