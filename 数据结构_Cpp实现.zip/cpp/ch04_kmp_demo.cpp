// ch04_kmp_demo.cpp —— 教材 4.3.2「串的模式匹配 / KMP 算法」完整可编译示例
// 编译：g++ -std=c++17 -O2 ch04_kmp_demo.cpp -o kmp && ./kmp
// 说明：与 ch07_prim_demo.cpp 风格一致，整段为一个 @SECTION，复制即可编译运行。
// @SECTION 4.3.2 | 完整可编译示例：KMP 逐步演示 + BF 对照
#include "ds_common.h"
#include <iomanip>

// ---------- 0/1-based 换算约定（务必先读）----------
// 教材 SString 为 1-based：T[0] 存串长，字符在 T[1..m]，且 next[1]=0。
// 为与教材伪码逐字对应，本实现统一构造 `string T = " " + pat`：
//   T[0] 弃用（不存串长，长度用 m 单独记录），T[1..m] 存放真实字符；
//   原始 pat 的第 k 个字符 pat[k-1] 对应教材 T[k]（k 从 1 起）。
// next / nextval 数组下标 1..m 有效，[0] 恒为 0；返回位置均为 1-based，0 表示未匹配。

// 教材算法 4.7 get_next：预处理 O(m)。verbose 时逐位打印推导与 j 回退链。
vector<int> get_next(const string& pat, bool verbose = false) {
    string T = " " + pat;
    int m = (int)pat.size();
    vector<int> next(m + 1, 0);
    int i = 1, j = 0;
    next[1] = 0;
    string back;                                   // 记录确定 next[i] 之前的 j 回退链
    while (i < m) {
        if (j == 0 || T[i] == T[j]) {
            ++i; ++j;
            next[i] = j;
            if (verbose)
                cout << "  next i=" << std::setw(2) << i << " j=" << std::setw(2) << j
                     << " 回退[" << (back.empty() ? string("-") : back) << "]"
                     << " => next[" << i << "]=" << j << "\n";
            back.clear();
        } else {
            int old = j;
            j = next[j];                            // 失配：j 回退
            if (!back.empty()) back += " ";
            back += std::to_string(old) + "->" + std::to_string(j);
        }
    }
    return next;
}

// 教材算法 4.8 get_nextval：在 next 基础上修正（T[i]==T[j] 时继承 nextval[j]），O(m)。
vector<int> get_nextval(const string& pat, bool verbose = false) {
    string T = " " + pat;
    int m = (int)pat.size();
    vector<int> nv(m + 1, 0);
    int i = 1, j = 0;
    nv[1] = 0;
    string back;
    while (i < m) {
        if (j == 0 || T[i] == T[j]) {
            ++i; ++j;
            if (T[i] != T[j]) nv[i] = j;
            else nv[i] = nv[j];                     // 字符相同则跳过重复比较
            if (verbose)
                cout << "  nval i=" << std::setw(2) << i << " j=" << std::setw(2) << j
                     << " 回退[" << (back.empty() ? string("-") : back) << "]"
                     << " => nextval[" << i << "]=" << nv[i] << "\n";
            back.clear();
        } else {
            int old = j;
            j = nv[j];                              // 教材：用修正值回退
            if (!back.empty()) back += " ";
            back += std::to_string(old) + "->" + std::to_string(j);
        }
    }
    return nv;
}

// 教材算法 4.6 Index_KMP：主串指针 i 不回退，失配时 j=next[j]，整体 O(n+m)（含预处理）。
// cmp 累计「字符比较」次数（j==0 起步分支短路，不计比较）；verbose 打印关键步骤。
int Index_KMP(const string& S, const string& pat, const vector<int>& next,
              int* cmp = nullptr, bool verbose = false) {
    string s = " " + S, t = " " + pat;
    int n = (int)S.size(), m = (int)pat.size();
    int i = 1, j = 1;
    while (i <= n && j <= m) {
        if (j == 0) {                              // 教材：j==0 时 i、j 同时右移
            if (verbose) cout << "  i=" << i << " j=0 -> 起步，i=" << (i + 1) << " j=1\n";
            ++i; ++j;
        } else if (s[i] == t[j]) {
            if (cmp) ++*cmp;
            if (verbose)
                cout << "  i=" << i << " j=" << j << " : S[" << i << "]='" << s[i]
                     << "' = T[" << j << "]='" << t[j] << "' -> 相等，双指针推进\n";
            ++i; ++j;
        } else {
            if (cmp) ++*cmp;
            int old = j;
            j = next[j];
            if (verbose)
                cout << "  i=" << i << " j=" << old << " : S[" << i << "]='" << s[i]
                     << "' != T[" << old << "]='" << t[old]
                     << "' -> 失配，j=next[" << old << "]=" << j << "\n";
        }
    }
    return (j > m) ? (i - m) : 0;
}

// 教材算法 4.1 Index_BF（朴素对照）：失配时主串指针 i 回退，最坏 O(n*m)。
int Index_BF(const string& S, const string& pat, int* cmp = nullptr) {
    string s = " " + S, t = " " + pat;
    int n = (int)S.size(), m = (int)pat.size();
    int i = 1, j = 1;
    while (i <= n && j <= m) {
        if (cmp) ++*cmp;                            // 一次字符比较
        if (s[i] == t[j]) { ++i; ++j; }
        else { i = i - j + 2; j = 1; }             // 教材：i 回退到本趟起点的下一位
    }
    return (j > m) ? (i - m) : 0;
}

int main() {
    Demo demo("4.3.2 KMP 完整示例（教材经典 abaabcac）");

    // [一] 经典模式串 next / nextval 的逐位推导
    cout << "\n[一] abaabcac 的 next / nextval 逐位推导（j 回退链已列出）\n";
    cout << "  --- get_next（算法 4.7，next[1]=0）---\n";
    vector<int> next = get_next("abaabcac", true);
    cout << "  --- get_nextval（算法 4.8）---\n";
    vector<int> nv = get_nextval("abaabcac", true);
    auto pack = [](const vector<int>& a, int m) {
        string r;
        for (int k = 1; k <= m; ++k) r += char('0' + a[k]);
        return r;
    };
    string sNext = pack(next, 8), sNv = pack(nv, 8);
    cout << "  next    = " << sNext << "（教材值 01122312）\n";
    cout << "  nextval = " << sNv << "（按算法 4.8 推导）\n";
    DS_CHECK(sNext == "01122312");
    // 差异说明：任务提示的 nextval=01102110 与教材算法 4.8 逐步推导不符；
    // 本实现采用 1-based、next[1]=0 的教材约定，真实结果为 01021302（上表逐位可核对），
    // 故断言按本实现值书写以保证真实成立；差异源于教材表与该提示值的约定不同。
    DS_CHECK(sNv == "01021302");

    // [二] KMP 匹配过程逐步演示（短例，含一次失配回退）
    cout << "\n[二] KMP 匹配逐步演示（S=ababc，T=abc，next=011）\n";
    vector<int> vnext = get_next("abc");
    int cmpK = 0, cmpB = 0;
    int posK = Index_KMP("ababc", "abc", vnext, &cmpK, true);
    int posB = Index_BF("ababc", "abc", &cmpB);
    DS_CHECK(posK == posB && posK == 3);           // 手算：S[3..5]=abc，位置 3
    cout << "  => KMP=" << posK << "，BF=" << posB
         << "；字符比较次数 KMP=" << cmpK << "，BF=" << cmpB << "\n";

    // [三] 4 组用例：KMP 与 BF 结果一致 + 比较次数对照
    cout << "\n[三] 4 组用例对照（位置 1-based，0 表示未匹配）\n";
    vector<vector<string>> cases = {
        {"xxababcabab", "abab"},                  // abab 类重复，中间匹配
        {"abcdefgh",    "xyz"},                   // 完全失配
        {"hello world", "hello"},                 // 首次即匹配
        {string(10, 'a') + "b", "aaab"},          // 末尾匹配 + 重复前缀，体现 KMP 优势
    };
    vector<int> expect = {3, 0, 1, 8};
    cout << "  " << std::setw(2) << "#" << " " << std::setw(13) << "S"
         << " " << std::setw(6) << "T" << " " << std::setw(4) << "KMP"
         << " " << std::setw(4) << "BF" << " " << std::setw(6) << "cmpBF"
         << " " << std::setw(6) << "cmpKMP" << "\n";
    int totalB = 0, totalK = 0;
    for (size_t k = 0; k < cases.size(); ++k) {
        const string& S = cases[k][0];
        const string& T = cases[k][1];
        vector<int> nx = get_next(T);
        int cb = 0, ck = 0;
        int pk = Index_KMP(S, T, nx, &ck);
        int pb = Index_BF(S, T, &cb);
        DS_CHECK(pk == pb);                        // 两种算法结果必须一致
        DS_CHECK(pk == expect[k]);                 // 手算位置
        totalB += cb; totalK += ck;
        cout << "  " << std::setw(2) << (k + 1) << " " << std::setw(13) << S
             << " " << std::setw(6) << T << " " << std::setw(4) << pk
             << " " << std::setw(4) << pb << " " << std::setw(6) << cb
             << " " << std::setw(6) << ck << "\n";
    }
    cout << "  合计字符比较次数：BF=" << totalB << "，KMP=" << totalK << "\n";

    cout << "\n[4.3.2] 断言通过：4 组 KMP==BF；next=01122312，nextval=01021302\n";
    return 0;
}
// @ENDSECTION
