// ch02_linear_list.cpp - 第 2 章 线性表: 可编译 C++17 实现
// 对应"数据结构(C 语言版)"严蔚敏 2.1 ~ 2.4
// 只依赖标准库与 ds_common.h, 自带 main() 演示与 DS_CHECK 自测
#include "ds_common.h"

// @SECTION 2.1 | 线性表 ADT List 的 C++ 接口, 例 2-1 并集与例 2-2 有序归并
// 教材 2.1 ADT List: 用 std::vector 落地 (0-based 存储).
// 与教材下标约定: 教材位序 i 从 1 起, vector 为 0-based, 故内部取 L[i-1],
//   返回的位序仍是 1-based; LocateElem 不存在时返回 0.
// 例 2-1 的 union 是 C++ 保留字, 故改名 Union, 语义不变.
// 时间复杂度: GetElem O(1), LocateElem/ListInsert O(n), Union O(m*n), 归并 O(m+n);
// 空间复杂度: 除结果表外均 O(1).
using List = vector<ElemType>;

int ListLength(const List& L) { return static_cast<int>(L.size()); }

Status GetElem(const List& L, int i, ElemType& e) {        // 1-based 位序, 随机存取 O(1)
    if (i < 1 || i > ListLength(L)) return ERROR;
    e = L[i - 1];
    return OK;
}
int LocateElem(const List& L, ElemType e) {                 // 返回 1-based 位序, 不存在 0
    for (int i = 0; i < ListLength(L); ++i)
        if (L[i] == e) return i + 1;
    return 0;
}
Status ListInsert(List& L, int i, ElemType e) {             // 1 <= i <= n+1
    int n = ListLength(L);
    if (i < 1 || i > n + 1) return ERROR;                   // i 越界
    L.insert(L.begin() + (i - 1), e);
    return OK;
}
void Union(List& La, List Lb) {                             // 例 2-1: A = A 并 B
    int La_len = ListLength(La);
    int Lb_len = ListLength(Lb);
    for (int i = 1; i <= Lb_len; ++i) {
        ElemType e = 0;
        GetElem(Lb, i, e);
        if (!LocateElem(La, e)) ListInsert(La, ++La_len, e);
    }
}
void MergeList_Sq(List La, List Lb, List& Lc) {             // 例 2-2: 有序表归并 (ADT 版)
    Lc.clear();
    int i = 1, j = 1;
    int m = ListLength(La), n = ListLength(Lb);
    while (i <= m && j <= n) {
        ElemType ai = 0, bj = 0;
        GetElem(La, i, ai); GetElem(Lb, j, bj);
        if (ai <= bj) { Lc.push_back(ai); ++i; }
        else          { Lc.push_back(bj); ++j; }
    }
    while (i <= m) { ElemType ai = 0; GetElem(La, i++, ai); Lc.push_back(ai); }
    while (j <= n) { ElemType bj = 0; GetElem(Lb, j++, bj); Lc.push_back(bj); }
}
int LocateElem_Sq(const List& L, ElemType e) {              // 顺序查找, 与 2.2 的 SqList 版同名重载
    for (int i = 1; i <= ListLength(L); ++i)
        if (L[i - 1] == e) return i;                        // 1-based 位序
    return 0;
}
// @ENDSECTION

// @SECTION 2.2 | 顺序表 SqList 的类型定义与初始化, 插入, 删除, 查找, 销毁
// 教材 SqList 伪码内部为 0-based (q = &L.elem[i-1]); 本讲义按 README 约定保留
//   1-based 数组, elem[0] 留作哨兵, 插入位置 i 对应 elem[i] (等价于教材 elem[i-1]).
// 扩容: 教材 realloc + LISTINCREMENT, 此处用 vector::resize, 语义一致.
// 时间复杂度: 取第 i 个 O(1), 插入/删除 O(n), 查找 O(n); 空间复杂度: 表 O(n), 辅助 O(1).
constexpr int LIST_INIT_SIZE = 100;      // 教材 LIST_INIT_SIZE
constexpr int LISTINCREMENT  = 10;       // 教材 LISTINCREMENT

struct SqList {
    vector<ElemType> elem;               // 1-based: elem[1..length] 有效, elem[0] 为哨兵
    int length = 0;                      // 当前长度
    int listsize = 0;                    // 当前分配容量 (不含 0 号哨兵)
};
Status InitList_Sq(SqList& L) {
    L.elem.assign(LIST_INIT_SIZE + 1, 0);  // 多分配 1 个给 0 号哨兵
    L.length = 0;
    L.listsize = LIST_INIT_SIZE;
    return OK;
}
Status ListInsert_Sq(SqList& L, int i, ElemType e) {
    if (i < 1 || i > L.length + 1) return ERROR;                // i 越界
    if (L.length >= L.listsize) {                                // 表满, 扩容 (realloc 语义)
        int newSize = L.listsize + LISTINCREMENT;
        L.elem.resize(newSize + 1, 0);
        L.listsize = newSize;
    }
    for (int p = L.length; p >= i; --p) L.elem[p + 1] = L.elem[p];  // 从后往前右移
    L.elem[i] = e;                                              // 教材 *q=e 对应 elem[i-1], 此处 elem[i]
    ++L.length;
    return OK;
}
Status ListDelete_Sq(SqList& L, int i, ElemType& e) {
    if (i < 1 || i > L.length) return ERROR;
    e = L.elem[i];
    for (int p = i; p < L.length; ++p) L.elem[p] = L.elem[p + 1];   // 被删元素之后左移
    --L.length;
    return OK;
}
int LocateElem_Sq(const SqList& L, ElemType e) {
    for (int i = 1; i <= L.length; ++i) if (L.elem[i] == e) return i; // 1-based 位序
    return 0;
}
int ListLength_Sq(const SqList& L) { return L.length; }
Status DestroyList(SqList& L) {
    L.elem.clear();                       // 教材 free(L.elem); vector 自动释放
    L.length = 0;
    L.listsize = 0;
    return OK;
}
// @ENDSECTION

// @SECTION 2.2 | 顺序有序表的归并 MergeList_Sq (O(m+n))
// 教材 2.2 的真正 O(m+n) 版本: 直接按 1-based 下标赋值, 不调用 ListInsert_Sq
//   (后者每次插入都可能触发移动, 会退化). 复用本文件前部 2.2 段定义的 SqList.
// 与教材下标约定: elem[1..length] 为 1-based; 教材 0-based 版对应 elem[0..length-1].
// 时间复杂度 O(m+n), 空间复杂度 O(m+n) (结果表本身), 辅助 O(1).
void MergeList_Sq(const SqList& La, const SqList& Lb, SqList& Lc) {
    int m = La.length, n = Lb.length;
    Lc.elem.assign(m + n + 1, 0);        // 1-based, 预留 0 号哨兵
    Lc.listsize = m + n;
    Lc.length = m + n;
    int i = 1, j = 1, k = 1;
    while (i <= m && j <= n) {
        if (La.elem[i] <= Lb.elem[j]) Lc.elem[k++] = La.elem[i++];
        else                          Lc.elem[k++] = Lb.elem[j++];
    }
    while (i <= m) Lc.elem[k++] = La.elem[i++];
    while (j <= n) Lc.elem[k++] = Lb.elem[j++];
}
// @ENDSECTION

// @SECTION 2.3 | 单链表结点 LNode/LinkList 与按位查找, 插入, 删除
// 教材 2.3.1: 结点 = 数据域 + 指针域; LinkList 为指向头结点的指针.
// 带头结点: L->next 指向第 1 个元素结点, 空表时 L->next == nullptr.
// C++ 用 new/delete 替代 malloc/free; next 初值 nullptr, 数据初值 0, 避免未初始化.
// 时间复杂度: 三个操作定位需从头扫描, 均 O(n); 空间复杂度 O(1).
struct LNode {
    ElemType data = 0;
    LNode* next = nullptr;
};
using LinkList = LNode*;

Status GetElem_L(LinkList L, int i, ElemType& e) {           // 1-based 位序, O(n)
    if (i < 1) return ERROR;
    LNode* p = L->next; int j = 1;
    while (p && j < i) { p = p->next; ++j; }
    if (!p || j > i) return ERROR;
    e = p->data;
    return OK;
}
Status ListInsert_L(LinkList& L, int i, ElemType e) {         // 找第 i-1 个结点, O(n)
    LNode* p = L; int j = 0;
    while (p && j < i - 1) { p = p->next; ++j; }
    if (i < 1 || !p || j > i - 1) return ERROR;
    LNode* s = new LNode;
    s->data = e;
    s->next = p->next;      // 次序不可颠倒, 否则丢链
    p->next = s;
    return OK;
}
Status ListDelete_L(LinkList& L, int i, ElemType& e) {        // O(n)
    LNode* p = L; int j = 0;
    while (p->next && j < i - 1) { p = p->next; ++j; }
    if (i < 1 || !(p->next) || j > i - 1) return ERROR;
    LNode* q = p->next;
    p->next = q->next;
    e = q->data;
    delete q;
    return OK;
}
vector<ElemType> ListToVector(LinkList L) {                   // 演示辅助: 链表转 vector, 便于 printSeq
    vector<ElemType> v;
    for (LNode* p = L->next; p; p = p->next) v.push_back(p->data);
    return v;
}
// @ENDSECTION

// @SECTION 2.3 | 单链表的建立 (头插/尾插), 有序归并, 就地逆置与清空
// 教材 CreateList_L 用 scanf 逆位序输入; 此处改为传入 vector, 便于演示与自测.
// 头插法所得链表顺序与输入相反; 尾插法保持一致. 位序仍从 1 起, vector 为 0-based.
// 时间复杂度: 建表/逆置/归并/清空均 O(n); 空间复杂度: 建表 O(n), 其余复用结点 O(1).
// 复用本文件 2.3 前段定义的 LNode/LinkList.
void CreateList_L(LinkList& L, const vector<ElemType>& a) {   // 头插法, 结果为 a 的逆序
    L = new LNode;                       // 头结点
    L->next = nullptr;
    for (ElemType x : a) {
        LNode* p = new LNode;
        p->data = x;
        p->next = L->next;              // 插到表头
        L->next = p;
    }
}
void CreateList_R(LinkList& L, const vector<ElemType>& a) {   // 尾插法, 结果与 a 同序
    L = new LNode;
    L->next = nullptr;
    LNode* r = L;                       // 尾指针
    for (ElemType x : a) {
        LNode* p = new LNode;
        p->data = x;
        p->next = nullptr;
        r->next = p;
        r = p;
    }
}
void MergeList_L(LinkList& La, LinkList& Lb, LinkList& Lc) {  // 有序归并, 复用原结点
    LNode* pa = La->next;
    LNode* pb = Lb->next;
    LNode* pc = La;                     // 复用 La 头结点作结果表头
    Lc = La;
    delete Lb;                          // 释放 Lb 头结点 (元素结点已摘出)
    Lb = nullptr;
    La = nullptr;                       // 所有权转交 Lc, 避免主程序重复释放
    while (pa && pb) {
        if (pa->data <= pb->data) { pc->next = pa; pc = pa; pa = pa->next; }
        else                      { pc->next = pb; pc = pb; pb = pb->next; }
    }
    pc->next = pa ? pa : pb;            // 接上剩余段
}
void ReverseList_L(LinkList& L) {                             // 就地逆置, O(1) 额外空间
    LNode* p = L->next;
    L->next = nullptr;
    while (p) {
        LNode* q = p->next;
        p->next = L->next;
        L->next = p;
        p = q;
    }
}
Status ClearList_L(LinkList& L) {                             // 释放全部结点 (含头结点)
    if (!L) return ERROR;
    LNode* p = L;
    while (p) {
        LNode* q = p->next;
        delete p;
        p = q;
    }
    L = nullptr;
    return OK;
}
// @ENDSECTION

// @SECTION 2.3.2 | 循环链表与仅设尾指针的合并 Connect
// 最后一个结点 next 指回头结点; 判表尾条件由 p->next == nullptr 改为 p->next == head.
// 仅设尾指针 rear 时, rear->next 为头结点, rear->next->next 为第 1 个元素结点;
//   合并两个循环链表只改 2 个指针, O(1). 复用 2.3 前段定义的 LNode/LinkList.
// 时间复杂度: 建表 O(n), Connect O(1), 遍历/清空 O(n); 空间复杂度: 建表 O(n), 其余 O(1).
LinkList CreateCircularRear(const vector<ElemType>& a) {
    LNode* head = new LNode;
    head->next = head;                  // 空环: 头结点指回自己
    LNode* rear = head;                 // 尾指针
    for (ElemType x : a) {
        LNode* p = new LNode;
        p->data = x;
        p->next = head;                 // 新尾结点指回头结点, 成环
        rear->next = p;                 // 原尾接上新结点
        rear = p;                       // 更新尾指针
    }
    return rear;                        // 仅返回尾指针
}
vector<ElemType> CircularToVector(LinkList rear) {
    vector<ElemType> v;
    if (!rear) return v;
    LNode* head = rear->next;           // 尾结点的 next 即头结点
    for (LNode* p = head->next; p != head; p = p->next) v.push_back(p->data);
    return v;
}
LinkList Connect(LinkList& A, LinkList& B) {   // 教材 Connect: B 接在 A 之后, 返回新尾指针
    LNode* ha = A->next;               // A 的头结点
    LNode* hb = B->next;               // B 的头结点
    if (hb == B) {                     // B 为空表: 只需释放其唯一头结点
        delete hb;
        LinkList res = A;
        A = nullptr;
        B = nullptr;
        return res;
    }
    A->next = hb->next;                // A 尾结点接 B 的第 1 个元素结点
    delete hb;                         // 释放 B 的头结点
    B->next = ha;                      // B 尾结点接回 A 的头结点, 成环
    LinkList res = B;                  // 合并后尾指针为 B 的尾结点
    A = nullptr;
    B = nullptr;
    return res;
}
Status ClearCircular(LinkList& rear) {
    if (!rear) return ERROR;
    LNode* head = rear->next;
    LNode* p = head->next;
    while (p != head) {
        LNode* q = p->next;
        delete p;
        p = q;
    }
    delete head;
    rear = nullptr;
    return OK;
}
// @ENDSECTION

// @SECTION 2.3.3 | 双向循环链表 DuLNode/DuLinkList 与定位
// 教材 2.3.3: 每个结点含 prior 与 next 两条链, 头结点 prior/next 均指向自己.
// 可 O(1) 找前驱, 但定位第 i 个结点仍需 O(n). GetElemP_DuL 的 i 为 1-based 位序,
//   i == 0 返回头结点 (供表尾追加定位); 教材 0-based 内部下标在此改为 1-based 位序.
// 时间复杂度: 定位/遍历/清空 O(n), 初始化 O(1); 空间复杂度 O(1) 辅助.
struct DuLNode {
    ElemType data = 0;
    DuLNode* prior = nullptr;
    DuLNode* next = nullptr;
};
using DuLinkList = DuLNode*;

DuLinkList InitList_DuL() {
    DuLNode* L = new DuLNode;
    L->prior = L;
    L->next = L;
    return L;
}
DuLNode* GetElemP_DuL(DuLinkList L, int i) {
    if (i == 0) return L;              // 头结点 (供尾插定位)
    if (i < 1) return nullptr;
    DuLNode* p = L->next; int j = 1;
    while (p != L && j < i) { p = p->next; ++j; }
    if (p == L || j > i) return nullptr;
    return p;
}
vector<ElemType> DuLToVector(DuLinkList L) {
    vector<ElemType> v;
    for (DuLNode* p = L->next; p != L; p = p->next) v.push_back(p->data);
    return v;
}
Status ClearList_DuL(DuLinkList& L) {
    if (!L) return ERROR;
    DuLNode* p = L->next;
    while (p != L) { DuLNode* q = p->next; delete p; p = q; }
    delete L;
    L = nullptr;
    return OK;
}
// @ENDSECTION

// @SECTION 2.3.3 | 双向链表的插入 ListInsert_DuL 与删除 ListDelete_DuL
// 在第 i 个位置之前插入: 四条指针, 先连 s 再断原链, 次序不可颠倒.
// i 合法范围 1..n+1, i == n+1 表示表尾追加 (p 取头结点, 插在头结点之前即表尾).
// 时间复杂度 O(n) (含定位), 空间复杂度 O(1) 辅助 (插入新结点 O(1)).
// 复用本文件 2.3.3 前段定义的 DuLNode/DuLinkList 与 GetElemP_DuL.
Status ListInsert_DuL(DuLinkList& L, int i, ElemType e) {
    int len = 0;
    for (DuLNode* q = L->next; q != L; q = q->next) ++len;
    if (i < 1 || i > len + 1) return ERROR;                 // i 越界
    DuLNode* p = (i == len + 1) ? L : GetElemP_DuL(L, i);
    if (!p) return ERROR;
    DuLNode* s = new DuLNode;
    s->data = e;
    s->prior = p->prior;  p->prior->next = s;
    s->next  = p;         p->prior = s;
    return OK;
}
Status ListDelete_DuL(DuLinkList& L, int i, ElemType& e) {
    DuLNode* p = GetElemP_DuL(L, i);                        // p 指向第 i 个结点
    if (!p || p == L) return ERROR;
    e = p->data;
    p->prior->next = p->next;
    p->next->prior = p->prior;
    delete p;
    return OK;
}
// @ENDSECTION

// @SECTION 2.4 | 一元多项式的有序链表表示: term/PNode 与 CreatPolyn/PrintPolyn
// 教材 2.4: 只存非零项 (coef, expn), 用带头结点的有序链表按指数递增排列.
// 教材 term.coef 为 float; 此处用 double 便于精确比较, 零系数与合并为零的项均不存.
// 时间复杂度: CreatPolyn O(m^2) (逐个有序插入), PrintPolyn/Destroy O(n); 空间 O(n).
struct term {
    double coef = 0.0;   // 系数
    int expn = 0;        // 指数
    // C++11 下带 NSDMI 的类不是聚合体，补构造函数以支持 T{a,b} 与 vector<term>{{...}}
    term(double c = 0.0, int e = 0) : coef(c), expn(e) {}
};
struct PNode {
    double coef = 0.0;
    int expn = 0;
    PNode* next = nullptr;
    // 同理，支持 new PNode{coef, expn, next} 的花括号初始化
    PNode(double c = 0.0, int e = 0, PNode* n = nullptr) : coef(c), expn(e), next(n) {}
};
using Polynomial = PNode*;

void CreatPolyn(Polynomial& P, const vector<term>& items) {
    P = new PNode;                      // 头结点, expn 不用
    P->next = nullptr;
    for (const auto& t : items) {
        if (t.coef == 0.0) continue;                        // 零系数项不存
        PNode* pre = P;
        while (pre->next && pre->next->expn < t.expn) pre = pre->next;
        if (pre->next && pre->next->expn == t.expn) {       // 同指数合并
            pre->next->coef += t.coef;
            if (pre->next->coef == 0.0) {                   // 合并后为 0 则删除该项
                PNode* q = pre->next;
                pre->next = q->next;
                delete q;
            }
        } else {
            PNode* s = new PNode;
            s->coef = t.coef; s->expn = t.expn;
            s->next = pre->next;
            pre->next = s;
        }
    }
}
void DestroyPolyn(Polynomial& P) {
    if (!P) return;
    PNode* p = P;
    while (p) { PNode* q = p->next; delete p; p = q; }
    P = nullptr;
}
void PrintPolyn(const Polynomial& P) {
    cout << "P(x) = ";
    bool first = true;
    for (PNode* p = P->next; p; p = p->next) {
        if (!first) cout << (p->coef >= 0 ? " + " : " - ");
        else if (p->coef < 0) cout << "-";
        cout << std::fabs(p->coef);
        if (p->expn != 0) cout << "x^" << p->expn;
        first = false;
    }
    if (first) cout << "0";
    cout << '\n';
}
double CoefOf(const Polynomial& P, int expn) {              // 演示辅助: 按指数查系数, 不存在返回 0
    for (PNode* p = P->next; p; p = p->next)
        if (p->expn == expn) return p->coef;
    return 0.0;
}
// @ENDSECTION

// @SECTION 2.4 | 一元多项式相加 AddPolyn 与相减 SubtractPolyn
// AddPolyn: Pa = Pa + Pb, 归并两个按指数递增的有序链表, 系数和为 0 的项必须删除.
// 取舍: 教材复用原结点 (额外空间 O(1)); 此处新建结果结点, 语义更清晰,
//   额外空间 O(m+n), 并在末尾销毁 Pa/Pb 旧表, Pb 置 nullptr.
// 时间复杂度 O(m+n); 空间复杂度 O(m+n) (结果表).
// 复用本文件 2.4 前段定义的 PNode/Polynomial 与 DestroyPolyn.
void AddPolyn(Polynomial& Pa, Polynomial& Pb) {
    PNode* a = Pa->next;
    PNode* b = Pb->next;
    Polynomial pc = new PNode;         // 结果表头结点
    PNode* tail = pc;
    while (a && b) {
        if (a->expn < b->expn) {
            tail->next = new PNode{a->coef, a->expn, nullptr};
            tail = tail->next; a = a->next;
        } else if (a->expn > b->expn) {
            tail->next = new PNode{b->coef, b->expn, nullptr};
            tail = tail->next; b = b->next;
        } else {
            double c = a->coef + b->coef;
            if (c != 0.0) {                                 // 系数和为 0 的项删除
                tail->next = new PNode{c, a->expn, nullptr};
                tail = tail->next;
            }
            a = a->next; b = b->next;
        }
    }
    for (PNode* p = a ? a : b; p; p = p->next) {
        tail->next = new PNode{p->coef, p->expn, nullptr};
        tail = tail->next;
    }
    DestroyPolyn(Pa);
    DestroyPolyn(Pb);
    Pa = pc;
}
void SubtractPolyn(Polynomial& Pa, Polynomial& Pb) {
    // 教材思路: Pa - Pb = Pa + (-Pb), 借助系数取负 + AddPolyn 实现
    for (PNode* p = Pb->next; p; p = p->next) p->coef = -p->coef;
    AddPolyn(Pa, Pb);
}
// @ENDSECTION

int main() {
    {
        Demo d("2.1 ADT List: 例 2-1 并集与例 2-2 有序归并");
        List La{1, 3, 5}, Lb{2, 3, 6}, Lc;
        Union(La, Lb);                       // A = A 并 B
        printSeq(La, "Union(La,Lb)");
        List expectU{1, 3, 5, 2, 6};
        DS_CHECK(La == expectU);
        DS_CHECK(LocateElem(La, 3) == 2);
        DS_CHECK(LocateElem_Sq(La, 99) == 0);
        List A{1, 3, 5, 7}, B{2, 4, 5, 8};
        MergeList_Sq(A, B, Lc);
        printSeq(Lc, "MergeList_Sq(A,B)");
        List expectM{1, 2, 3, 4, 5, 5, 7, 8};
        DS_CHECK(Lc == expectM);
    }
    {
        Demo d("2.2 顺序表 SqList: 插入, 删除, 扩容与有序归并");
        SqList L;
        InitList_Sq(L);
        DS_CHECK(ListLength_Sq(L) == 0 && L.listsize == 100);
        DS_CHECK(ListInsert_Sq(L, 1, 30) == OK);
        DS_CHECK(ListInsert_Sq(L, 1, 10) == OK);
        DS_CHECK(ListInsert_Sq(L, 2, 20) == OK);
        DS_CHECK(ListInsert_Sq(L, 0, 0) == ERROR);
        DS_CHECK(ListInsert_Sq(L, 5, 0) == ERROR);
        ElemType e = 0;
        DS_CHECK(ListDelete_Sq(L, 2, e) == OK && e == 20);
        DS_CHECK(LocateElem_Sq(L, 30) == 2);
        vector<ElemType> v;
        for (int i = 1; i <= L.length; ++i) v.push_back(L.elem[i]);
        printSeq(v, "SqList 插入删除后");
        SqList M; InitList_Sq(M);
        for (int i = 1; i <= 120; ++i) ListInsert_Sq(M, i, i);
        DS_CHECK(M.length == 120 && M.listsize >= 120);
        DS_CHECK(M.elem[120] == 120);
        SqList P, Q, R;
        InitList_Sq(P); InitList_Sq(Q);
        for (int x : {1, 3, 5}) ListInsert_Sq(P, P.length + 1, x);
        for (int x : {2, 4, 6}) ListInsert_Sq(Q, Q.length + 1, x);
        MergeList_Sq(P, Q, R);
        vector<ElemType> rv;
        for (int i = 1; i <= R.length; ++i) rv.push_back(R.elem[i]);
        printSeq(rv, "MergeList_Sq(P,Q)");
        vector<ElemType> expectR{1, 2, 3, 4, 5, 6};
        DS_CHECK(rv == expectR);
        DestroyList(L); DestroyList(M);
        DestroyList(P); DestroyList(Q); DestroyList(R);
    }
    {
        Demo d("2.3 单链表: 头插/尾插, 插入删除, 逆置与有序归并");
        LinkList L1 = nullptr;
        CreateList_R(L1, {1, 2, 3, 4});
        printSeq(ListToVector(L1), "尾插法 CreateList_R");
        ElemType e = 0;
        DS_CHECK(GetElem_L(L1, 3, e) == OK && e == 3);
        DS_CHECK(ListInsert_L(L1, 1, 0) == OK);
        DS_CHECK(ListDelete_L(L1, 3, e) == OK && e == 2);
        printSeq(ListToVector(L1), "插入删除后");
        ReverseList_L(L1);
        printSeq(ListToVector(L1), "就地逆置");
        vector<ElemType> expectL1{4, 3, 1, 0};
        DS_CHECK(ListToVector(L1) == expectL1);
        ClearList_L(L1);
        DS_CHECK(L1 == nullptr);

        LinkList L2 = nullptr;
        CreateList_L(L2, {1, 2, 3});
        printSeq(ListToVector(L2), "头插法 CreateList_L");
        vector<ElemType> expectL2{3, 2, 1};
        DS_CHECK(ListToVector(L2) == expectL2);
        ClearList_L(L2);

        LinkList A = nullptr, B = nullptr, C = nullptr;
        CreateList_R(A, {1, 3, 5});
        CreateList_R(B, {2, 4, 6});
        MergeList_L(A, B, C);
        printSeq(ListToVector(C), "MergeList_L(A,B)");
        vector<ElemType> expectC{1, 2, 3, 4, 5, 6};
        DS_CHECK(ListToVector(C) == expectC);
        ClearList_L(C);
    }
    {
        Demo d("2.3.2 循环链表: 仅设尾指针的 Connect 合并");
        LinkList Ra = CreateCircularRear({1, 3, 5});
        LinkList Rb = CreateCircularRear({2, 4, 6});
        printSeq(CircularToVector(Ra), "循环链表 A");
        LNode* head = Ra->next;
        LNode* p = head->next;
        int guard = 0;
        while (p != head && guard++ < 100) p = p->next;
        DS_CHECK(p == head);             // 能绕回头结点
        LinkList Rc = Connect(Ra, Rb);
        printSeq(CircularToVector(Rc), "Connect(A,B)");
        vector<ElemType> expectCC{1, 3, 5, 2, 4, 6};
        DS_CHECK(CircularToVector(Rc) == expectCC);
        DS_CHECK(Rb == nullptr && Ra == nullptr);
        ClearCircular(Rc);
        DS_CHECK(Rc == nullptr);
    }
    {
        Demo d("2.3.3 双向循环链表: 插入与删除");
        DuLinkList DL = InitList_DuL();
        DS_CHECK(ListInsert_DuL(DL, 1, 10) == OK);
        DS_CHECK(ListInsert_DuL(DL, 2, 30) == OK);
        DS_CHECK(ListInsert_DuL(DL, 2, 20) == OK);
        printSeq(DuLToVector(DL), "双向链表插入后");
        ElemType e = 0;
        DS_CHECK(ListDelete_DuL(DL, 2, e) == OK && e == 20);
        DS_CHECK(ListInsert_DuL(DL, 0, 0) == ERROR);
        printSeq(DuLToVector(DL), "删除后");
        vector<ElemType> expectD{10, 30};
        DS_CHECK(DuLToVector(DL) == expectD);
        ClearList_DuL(DL);
        DS_CHECK(DL == nullptr);
    }
    {
        Demo d("2.4 一元多项式: 创建, 相加, 相减与打印");
        Polynomial Pa = nullptr, Pb = nullptr;
        vector<term> ta{{1.0, 0}, {2.0, 1}, {3.0, 2}};
        vector<term> tb{{4.0, 0}, {5.0, 3}, {-3.0, 2}};
        CreatPolyn(Pa, ta);
        CreatPolyn(Pb, tb);
        PrintPolyn(Pa);
        PrintPolyn(Pb);
        AddPolyn(Pa, Pb);
        PrintPolyn(Pa);
        DS_CHECK(CoefOf(Pa, 2) == 0.0);
        DS_CHECK(CoefOf(Pa, 0) == 5.0 && CoefOf(Pa, 1) == 2.0 && CoefOf(Pa, 3) == 5.0);
        DS_CHECK(Pb == nullptr);
        Polynomial Pc = nullptr, Pd = nullptr;
        vector<term> tc{{7.0, 0}, {3.0, 2}};
        vector<term> td{{2.0, 0}, {3.0, 2}};
        CreatPolyn(Pc, tc);
        CreatPolyn(Pd, td);
        SubtractPolyn(Pc, Pd);
        PrintPolyn(Pc);
        DS_CHECK(CoefOf(Pc, 0) == 5.0 && CoefOf(Pc, 2) == 0.0);
        DestroyPolyn(Pa); DestroyPolyn(Pc);
    }
    return 0;
}
