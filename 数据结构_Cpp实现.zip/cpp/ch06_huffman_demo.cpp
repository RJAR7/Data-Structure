// ch06_huffman_demo.cpp —— 教材 6.6「赫夫曼树及其应用」完整可编译示例
// 编译：g++ -std=c++17 -O2 ch06_huffman_demo.cpp -o huffman && ./huffman
// 说明：与 ch07_prim_demo.cpp 风格一致，整段为一个 @SECTION，复制即可编译运行。
// @SECTION 6.6 | 完整可编译示例：赫夫曼树构造与编码
#include "ds_common.h"
#include <iomanip>

// ---------- 赫夫曼树：静态三叉链表（教材 6.6.2）----------
struct HTNode {
    int weight = 0;
    int parent = 0, lchild = 0, rchild = 0;
};
// 1-based 下标：0 号单元不用；new[] 分配，DestroyHuffman 用 delete[] 释放。
using HuffmanTree = HTNode*;

// 在 HT[1..k] 中选 parent==0 且权值最小的两个下标，权值并列时取下标较小者。
void Select(HuffmanTree HT, int k, int& s1, int& s2) {
    s1 = 0;
    for (int i = 1; i <= k; ++i)
        if (HT[i].parent == 0 && (s1 == 0 || HT[i].weight < HT[s1].weight)) s1 = i;
    s2 = 0;
    for (int i = 1; i <= k; ++i)
        if (i != s1 && HT[i].parent == 0 && (s2 == 0 || HT[i].weight < HT[s2].weight)) s2 = i;
}

// 教材算法 6.12 的构造部分：n 个叶子 -> m = 2n-1 个结点。
// 复杂度：每轮 Select 线性扫描 O(m)，共 n-1 轮，故构造为 O(n^2)；
// 若用最小堆维护 parent==0 的候选结点，构造可优化到 O(n log n)，本例沿用教材 O(n^2)。
HuffmanTree BuildHuffmanTree(const vector<int>& w, int n) {
    int m = 2 * n - 1;
    HuffmanTree HT = new HTNode[m + 1]();         // () 值初始化，各字段全 0
    for (int i = 1; i <= n; ++i) HT[i].weight = w[i];
    cout << "n = " << n << "，总结点数 m = 2n-1 = " << m << "；逐轮 Select：\n";
    for (int i = n + 1; i <= m; ++i) {
        int s1 = 0, s2 = 0;
        Select(HT, i - 1, s1, s2);               // 只在 1..i-1 中选
        HT[s1].parent = i; HT[s2].parent = i;
        HT[i].lchild = s1; HT[i].rchild = s2;
        HT[i].weight = HT[s1].weight + HT[s2].weight;
        cout << "  第" << std::setw(2) << (i - n) << "轮: s1=" << std::setw(2) << s1
             << "(w=" << std::setw(2) << HT[s1].weight << ")  s2=" << std::setw(2) << s2
             << "(w=" << std::setw(2) << HT[s2].weight << ")  ->  新结点 HT[" << i
             << "].weight=" << HT[i].weight << "\n";
    }
    return HT;
}

// 打印最终 HT 表四列（std::setw 表格）
void PrintHT(HuffmanTree HT, int n) {
    int m = 2 * n - 1;
    cout << "  " << std::setw(3) << "i" << std::setw(8) << "weight"
         << std::setw(8) << "parent" << std::setw(8) << "lchild"
         << std::setw(8) << "rchild" << "\n";
    for (int i = 1; i <= m; ++i)
        cout << "  " << std::setw(3) << i << std::setw(8) << HT[i].weight
             << std::setw(8) << HT[i].parent << std::setw(8) << HT[i].lchild
             << std::setw(8) << HT[i].rchild << "\n";
}

// 教材算法 6.12：从叶子到根逆向求每个字符的赫夫曼编码。
// cd 长度 n，cd[n-1] 作结尾哨兵；最深叶子的编码恰为 n-1 位（下标 0..n-2），
// 用 assign(ptr, n-1-start) 只取有效位，不会多留一位导致编码尾部出现多余的 0。
void HuffmanCoding(HuffmanTree HT, int n, vector<string>& HC) {
    HC.assign(n + 1, "");
    string cd(n, '\0');
    for (int i = 1; i <= n; ++i) {
        int start = n - 1;
        int c = i, f = HT[i].parent;
        while (f != 0) {
            --start;
            cd[start] = (HT[f].lchild == c) ? '0' : '1';
            c = f; f = HT[f].parent;
        }
        HC[i].assign(cd.data() + start, n - 1 - start);
    }
}

// WPL：按 HT 表逐个叶子沿 parent 链回溯到根，累加 权值 * 深度
int WPL(HuffmanTree HT, int n) {
    int wpl = 0;
    for (int i = 1; i <= n; ++i) {
        int d = 0, c = i;
        while (HT[c].parent != 0) { ++d; c = HT[c].parent; }
        wpl += HT[i].weight * d;
    }
    return wpl;
}

// 译码：从根（下标 2n-1）出发，0 走左、1 走右，到叶子输出权值并回到根
vector<int> Decoding(HuffmanTree HT, int n, const string& bits) {
    int root = 2 * n - 1;
    vector<int> out;
    int p = root;
    for (char bit : bits) {
        p = (bit == '0') ? HT[p].lchild : HT[p].rchild;
        if (HT[p].lchild == 0 && HT[p].rchild == 0) {
            out.push_back(HT[p].weight);
            p = root;
        }
    }
    return out;
}

// 前缀码判定：任一编码都不是另一编码的前缀
bool IsPrefixCode(const vector<string>& HC, int n) {
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j)
            if (i != j && HC[j].size() >= HC[i].size()
                && HC[j].substr(0, HC[i].size()) == HC[i]) return false;
    return true;
}

void DestroyHuffman(HuffmanTree& HT) {
    delete[] HT;
    HT = nullptr;
}

int main() {
    Demo demo("6.6 赫夫曼树构造与编码完整示例（8 个权值）");

    const int n = 8;
    vector<int> w = {0, 5, 29, 7, 8, 14, 23, 3, 11};  // 1-based，w[0] 弃用
    HuffmanTree HT = BuildHuffmanTree(w, n);

    cout << "--- 最终 HT 表（1-based，0 号单元不用）---\n";
    PrintHT(HT, n);

    vector<string> HC;
    HuffmanCoding(HT, n, HC);
    cout << "--- 各权值的赫夫曼编码 ---\n";
    for (int i = 1; i <= n; ++i)
        cout << "  w=" << std::setw(3) << HT[i].weight << " (HT[" << std::setw(2) << i
             << "]) 编码 = " << std::setw(5) << HC[i]
             << "  长度 = " << HC[i].length() << "\n";

    // 断言 1：前缀码
    bool prefix = IsPrefixCode(HC, n);
    DS_CHECK(prefix);                             // 任一个编码都不是另一个的前缀
    cout << "前缀码检查 = " << (prefix ? "通过" : "失败") << "\n";

    // 断言 2：WPL 三种算法应一致，并等于手算值 271
    int wpl = WPL(HT, n);                         // 按 HT 表回溯深度算
    int wplByCode = 0, wplByInternal = 0;
    for (int i = 1; i <= n; ++i) wplByCode += HT[i].weight * (int)HC[i].length();
    for (int i = n + 1; i <= 2 * n - 1; ++i) wplByInternal += HT[i].weight;
    cout << "WPL(HT回溯)=" << wpl << " WPL(编码长度)=" << wplByCode
         << " WPL(内部结点权和)=" << wplByInternal << "\n";
    DS_CHECK(wpl == wplByCode);                  // WPL == 按编码/HT 算出的带权路径长度
    DS_CHECK(wpl == wplByInternal);              // WPL == 全部非叶结点权值之和
    DS_CHECK(wpl == 271);                         // 手算 WPL = 8+15+19+29+42+58+100 = 271

    // 断言 3：译码结果 == 原始权值序列
    string bits;
    for (int i = 1; i <= n; ++i) bits += HC[i];
    vector<int> dec = Decoding(HT, n, bits);
    cout << "编码串 = " << bits << "\n";
    printSeq(dec, "  译码结果");
    printSeq(vector<int>(w.begin() + 1, w.end()), "  原始权值");
    bool same = (dec.size() == (size_t)n);
    for (int i = 1; same && i <= n; ++i) same = (dec[i - 1] == w[i]);
    DS_CHECK(same);                               // 译码结果 == 原始权值序列

    cout << "[6.6] 断言通过：前缀码 / WPL==271 / 译码还原 / 与 HT 表一致\n";

    DestroyHuffman(HT);                           // main 结束前释放 new[] 的 HT
    cout << "  DestroyHuffman 已释放 HT 数组\n";
    return 0;
}
// @ENDSECTION
