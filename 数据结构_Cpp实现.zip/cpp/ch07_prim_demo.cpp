// ch07_prim_demo.cpp —— 教材 7.4「最小生成树」Prim 算法完整可编译示例
// 编译：g++ -std=c++17 -O2 ch07_prim_demo.cpp -o prim && ./prim
// 说明：本文件整体作为一个 @SECTION 段，便于讲义折叠展示「复制即可编译」的完整源码。
// @SECTION 7.4 | 完整可编译示例：Prim 逐步演示 + Kruskal 对照
#include "ds_common.h"
#include <iomanip>

// ---------- 图的邻接矩阵（0-based 顶点；教材伪码用 1-based，公式一一对应）----------
struct MGraph {
    int n;
    vector<vector<int>> arcs;                 // arcs[u][v] 为权值，INF_COST 表示无边
    explicit MGraph(int n_) : n(n_), arcs(n_, vector<int>(n_, INF_COST)) {
        for (int i = 0; i < n_; ++i) arcs[i][i] = 0;
    }
    void AddUndir(int u, int v, int w) { arcs[u][v] = arcs[v][u] = w; }
};

// 教材 closedge[j]：adjvex 记录「U 中与该顶点最近的顶点」，lowcost 为当前最小边权；
// lowcost == 0 表示该顶点已并入生成树顶点集 U。
struct CloseEdge { int adjvex = 0; int lowcost = INF_COST; };

void PrintCloseEdge(const vector<CloseEdge>& ce) {
    cout << "  v      : ";
    for (size_t v = 0; v < ce.size(); ++v) cout << std::setw(5) << v;
    cout << "\n  adjvex : ";
    for (const auto& e : ce) cout << std::setw(5) << (e.lowcost == 0 ? -1 : e.adjvex);
    cout << "\n  lowcost: ";
    for (const auto& e : ce) {
        if (e.lowcost == 0) cout << std::setw(5) << "0";
        else if (e.lowcost >= INF_COST) cout << std::setw(5) << "INF";
        else cout << std::setw(5) << e.lowcost;
    }
    cout << "\n";
}

// 教材算法 7.9：O(n^2)，适合稠密图；每轮选 lowcost 最小的顶点并入 U，再更新 closedge。
int MiniSpanTree_PRIM(const MGraph& G, int start) {
    int n = G.n;
    vector<CloseEdge> closedge(n);
    for (int v = 0; v < n; ++v) {                 // 初始化 U = {start}
        closedge[v].adjvex = start;
        closedge[v].lowcost = G.arcs[start][v];
    }
    closedge[start].lowcost = 0;
    cout << "初始 closedge（U = {" << start << "}）:\n";
    PrintCloseEdge(closedge);

    int total = 0, edges = 0;
    for (int k = 1; k < n; ++k) {
        int minc = INF_COST, pick = -1;
        for (int v = 0; v < n; ++v)               // 选 lowcost 最小的 v ∈ V-U
            if (closedge[v].lowcost > 0 && closedge[v].lowcost < minc) {
                minc = closedge[v].lowcost; pick = v;
            }
        if (pick == -1) { cout << "图不连通，无法生成生成树\n"; return -1; }
        cout << "\n第 " << k << " 轮：选边 (" << closedge[pick].adjvex
             << ", " << pick << ") 权 " << minc << "\n";
        total += minc; ++edges;
        closedge[pick].lowcost = 0;               // pick 并入 U
        for (int v = 0; v < n; ++v)               // 用新顶点到各点的边更新候选
            if (G.arcs[pick][v] < closedge[v].lowcost) {
                closedge[v].lowcost = G.arcs[pick][v];
                closedge[v].adjvex = pick;
            }
        PrintCloseEdge(closedge);
    }
    cout << "\nPrim 共选 " << edges << " 条边，MST 总权值 = " << total << "\n";
    return total;
}

// ---------- 对照：Kruskal（并查集判环，O(e log e)，适合稀疏图）----------
struct Edge { int u, v, w; };
struct UnionFind {
    vector<int> parent, rankv;
    explicit UnionFind(int n) : parent(n), rankv(n, 0) {
        for (int i = 0; i < n; ++i) parent[i] = i;
    }
    int Find(int x) { return parent[x] == x ? x : (parent[x] = Find(parent[x])); }
    bool Union(int a, int b) {
        a = Find(a); b = Find(b);
        if (a == b) return false;
        if (rankv[a] < rankv[b]) std::swap(a, b);
        parent[b] = a;
        if (rankv[a] == rankv[b]) ++rankv[a];
        return true;
    }
};
int MiniSpanTree_KRUSKAL(int n, vector<Edge> es) {
    std::sort(es.begin(), es.end(), [](const Edge& a, const Edge& b) { return a.w < b.w; });
    UnionFind uf(n);
    int total = 0, cnt = 0;
    cout << "\nKruskal 选边次序: ";
    for (const auto& e : es)
        if (uf.Union(e.u, e.v)) {
            cout << "(" << e.u << "," << e.v << "," << e.w << ") ";
            total += e.w;
            if (++cnt == n - 1) break;
        }
    cout << "\nKruskal MST 总权值 = " << total << "\n";
    return total;
}

int main() {
    Demo demo("7.4 Prim 完整示例（教材经典 6 顶点无向网）");
    MGraph G(6);
    vector<Edge> es;
    auto add = [&](int u, int v, int w) { G.AddUndir(u, v, w); es.push_back({u, v, w}); };
    add(0, 1, 6); add(0, 2, 1); add(0, 3, 5); add(1, 2, 5);
    add(1, 4, 3); add(2, 3, 5); add(2, 4, 6); add(2, 5, 4);
    add(3, 5, 2); add(4, 5, 6);

    int prim = MiniSpanTree_PRIM(G, 0);
    int kruskal = MiniSpanTree_KRUSKAL(G.n, es);
    DS_CHECK(prim == 15);                         // 手算 MST = 1+4+2+5+3 = 15
    DS_CHECK(prim == kruskal);                    // 两种算法结果必须一致
    cout << "\n[7.4] 断言通过：Prim = Kruskal = 15\n";
    return 0;
}
// @ENDSECTION
