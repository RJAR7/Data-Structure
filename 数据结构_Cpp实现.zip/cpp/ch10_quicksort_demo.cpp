// ch10_quicksort_demo.cpp —— 教材 10.3「快速排序」完整可编译示例
// 编译：g++ -std=c++17 -O2 ch10_quicksort_demo.cpp -o quicksort && ./quicksort
// 说明：本文件整体作为一个 @SECTION 段，便于讲义折叠展示「复制即可编译」的完整源码。
// @SECTION 10.3 | 完整可编译示例：快速排序逐趟划分
#include "ds_common.h"

// ---------- 教材 SqList / RedType：1-based 下标，r[0] 作枢轴暂存单元 ----------
// 与 STL 0-based 的换算：教材 r[i] 对应容器第 i 个元素（i 从 1 起），
// 故分配 n+1 个单元，r[0] 仅用于暂存枢轴记录，不参与排序结果。
struct RedType {
    KeyType key = 0;        // 关键字项
    int otherinfo = 0;      // 其它数据项（随记录一起移动，便于观察不稳定）
};
struct SqList {
    vector<RedType> r;      // r[0..n]，1-based 使用
    int length;
    explicit SqList(int n) : r(n + 1), length(n) {}
};

// 演示统计：为忠实照抄教材伪码（函数签名不含统计参数），用文件级变量收集。
long long g_cmp = 0;            // 关键字比较次数
long long g_mov = 0;            // 记录移动（赋值）次数
int       g_maxDepth = 0;       // 递归最大深度
bool      g_snapDone = false;   // 是否已记录第一趟划分快照
vector<int> g_firstSnap;        // 第一趟划分后的 1..n 关键字序列
int       g_firstPivot = 0;     // 第一趟划分后枢轴的最终位置

// 打印 1..n 的关键字（r[0] 为暂存单元，不打印），std::setw 对齐
void printList(const SqList& L) {
    cout << "[";
    for (int i = 1; i <= L.length; ++i) cout << std::setw(3) << L.r[i].key;
    cout << " ]";
}
// 表格式打印：下标行 + 关键字行
void printTable(const SqList& L) {
    cout << "  i :";
    for (int i = 1; i <= L.length; ++i) cout << std::setw(4) << i;
    cout << "\n  r :";
    for (int i = 1; i <= L.length; ++i) cout << std::setw(4) << L.r[i].key;
    cout << "\n";
}

// 教材算法 10.6(a)：一趟划分。pivotkey = L.r[low].key，双指针交替扫描；
// 每次「比枢轴小的移到低端 / 比枢轴大的移到高端」都打印一行中间状态。
// 平均 O(n log n)、最坏 O(n^2)；相等关键字会被交换 -> 不稳定；递归栈 O(log n)。
int Partition(SqList& L, int low, int high, int depth) {
    string ind(2 * depth + 2, ' ');
    L.r[0] = L.r[low];                       // 枢轴记录暂存在 r[0]
    ++g_mov;
    KeyType pivotkey = L.r[low].key;
    cout << ind << "pivotkey=" << pivotkey << " (r[0] 暂存枢轴), 扫描区间 ["
         << low << "," << high << "]\n";
    while (low < high) {
        // high 左移：找第一个关键字 < pivotkey 的记录
        while (low < high) {
            ++g_cmp;
            if (L.r[high].key >= pivotkey) --high;
            else break;
        }
        if (low < high) {
            L.r[low] = L.r[high];            // 小记录移到低端
            ++g_mov;
            cout << ind << "  high 左移: r[" << high << "]=" << L.r[high].key
                 << " < " << pivotkey << ", 移到 r[" << low << "]\n";
        }
        // low 右移：找第一个关键字 > pivotkey 的记录
        while (low < high) {
            ++g_cmp;
            if (L.r[low].key <= pivotkey) ++low;
            else break;
        }
        if (low < high) {
            L.r[high] = L.r[low];            // 大记录移到高端
            ++g_mov;
            cout << ind << "  low  右移: r[" << low << "]=" << L.r[low].key
                 << " > " << pivotkey << ", 移到 r[" << high << "]\n";
        }
    }
    L.r[low] = L.r[0];                       // 枢轴记录到位
    ++g_mov;
    cout << ind << "  枢轴 r[0] 归位到 r[" << low << "] = " << pivotkey << "\n";
    return low;                              // 返回枢轴最终位置
}

// 教材算法 10.7：递归快排。depth 用于递归区间划分树的缩进层次。
void QSort(SqList& L, int low, int high, int depth) {
    g_maxDepth = std::max(g_maxDepth, depth);
    if (low >= high) return;
    string ind(2 * depth, ' ');
    cout << ind << "QSort[" << low << "," << high << "]\n"; // 区间划分树节点
    int p = Partition(L, low, high, depth);
    cout << ind << "  -> 该趟结束 ";
    printList(L);
    cout << "  枢轴归位 r[" << p << "]=" << L.r[p].key
         << ", 子区间 [" << low << "," << p - 1 << "] / [" << p + 1 << "," << high << "]\n";
    if (!g_snapDone) {                       // 记录顶层（第一趟）划分快照
        for (int i = 1; i <= L.length; ++i) g_firstSnap.push_back(L.r[i].key);
        g_firstPivot = p;
        g_snapDone = true;
    }
    QSort(L, low, p - 1, depth + 1);
    QSort(L, p + 1, high, depth + 1);
}

void QuickSort(SqList& L) {
    g_cmp = 0; g_mov = 0; g_maxDepth = 0;
    g_snapDone = false; g_firstSnap.clear(); g_firstPivot = 0;
    QSort(L, 1, L.length, 0);
}

int main() {
    Demo demo("10.3 快速排序逐趟划分（教材序列 49 38 65 97 76 13 27 49）");
    vector<int> init = {49, 38, 65, 97, 76, 13, 27, 49};
    SqList L(8);
    for (int i = 1; i <= L.length; ++i) {    // STL 0-based init 映射到 1-based r
        L.r[i].key = init[i - 1];
        L.r[i].otherinfo = i;                // 记录原始位置，用于观察稳定性
    }
    cout << "初始序列（1-based，r[0] 仅作枢轴暂存）：\n";
    printTable(L);
    cout << "\n开始 QuickSort，逐趟划分（缩进 = 递归层次）：\n";
    QuickSort(L);
    cout << "\n最终排序结果：\n";
    printTable(L);

    vector<int> got;
    for (int i = 1; i <= L.length; ++i) got.push_back(L.r[i].key);
    vector<int> expect = init;               // STL 为 0-based，单独拷贝对照
    std::sort(expect.begin(), expect.end());

    int n = L.length;
    double nlogn = n * std::log2((double)n);
    cout << "\n统计: cmp=" << g_cmp << "  mov=" << g_mov
         << "  maxDepth=" << g_maxDepth << "\n";
    cout << "对照: n*log2(n)=" << std::fixed << std::setprecision(1) << nlogn
         << "  n^2=" << (long long)n * n << "\n";

    // ---- 手算断言 ----
    // 第一趟：以 49 为枢轴，high 依次 8->7、6->5->4，low 依次 1->2->3、3->4，
    // 得 {27,38,13,49,76,97,65,49}，枢轴落位 r[4]；本实现与教材结果一致。
    vector<int> first = {27, 38, 13, 49, 76, 97, 65, 49};
    DS_CHECK(g_firstSnap == first);          // 第一趟划分结果
    DS_CHECK(g_firstPivot == 4);             // 枢轴最终位置
    DS_CHECK(got == expect);                 // 与 std::sort 一致（含重复 49）
    DS_CHECK(g_maxDepth <= n);               // 递归深度 <= n
    DS_CHECK(g_cmp <= (long long)n * n);     // 比较次数 <= n^2
    cout << "[10.3] 断言通过：首趟={27,38,13,49,76,97,65,49}, pivot=4, 整体升序\n";
    return 0;
}
// @ENDSECTION
