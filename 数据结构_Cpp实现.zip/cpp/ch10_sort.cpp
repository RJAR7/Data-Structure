// ch10_sort.cpp - 第10章 内部排序 配套实现(C++17 单文件)
// 教材 1-based 下标: r[1..length] 为有效记录, r[0] 作哨兵/暂存
#include "ds_common.h"
#include <chrono>
#include <string>

// @SECTION 10.2 | 插入排序(公共约定与直接插入)
// 复杂度: 时间 O(n^2), 空间 O(1), 稳定性: 稳定
// 下标换算: r[1..length] 对应 0-based [0..length-1]; r[0] 作哨兵/暂存
// 全局开销计数器, 教材伪码类型与比较助手
static long long CMP = 0, MOV = 0;          // 比较次数/移动次数
static bool VERBOSE = false;                // 打开时打印每趟划分/建堆结果
static bool g_allPass = true;               // 自测总开关
struct RedType { KeyType key; int ord; };  // ord: 原序标号, 仅用于稳定性检验
struct SqList { RedType r[MAXSIZE + 1]; int length = 0; };  // r[0] 哨兵
struct SLNode { RedType rc; int next = 0; };                // 静态链表结点
struct SLList { SLNode r[MAXSIZE + 1]; int length = 0; };    // r[0] 头结点
static RedType Aux[MAXSIZE + 1];            // 归并辅助数组
inline void ResetCost() { CMP = 0; MOV = 0; }
inline bool LT(KeyType a, KeyType b) { ++CMP; return a < b; }   // a <  b
inline bool LE(KeyType a, KeyType b) { ++CMP; return a <= b; }  // a <= b
inline bool GT(KeyType a, KeyType b) { ++CMP; return a > b; }   // a >  b
inline bool GE(KeyType a, KeyType b) { ++CMP; return a >= b; }  // a >= b
// 直接插入排序: r[0] 暂存待插记录并作哨兵, 逆序时整体后移
void InsertionSort(SqList& L) {
    for (int i = 2; i <= L.length; ++i) {
        if (LT(L.r[i].key, L.r[i - 1].key)) {
            L.r[0] = L.r[i];            ++MOV;   // 复制到哨兵
            L.r[i] = L.r[i - 1];        ++MOV;
            int j;
            for (j = i - 2; LT(L.r[0].key, L.r[j].key); --j) {
                L.r[j + 1] = L.r[j];    ++MOV;   // 记录后移
            }
            L.r[j + 1] = L.r[0];        ++MOV;   // 插入
        }
    }
}
// @ENDSECTION

// @SECTION 10.2 | 插入排序(折半插入)
// 复杂度: 时间 O(n^2), 空间 O(1), 稳定性: 稳定
// 下标换算: r[1..length] 对应 0-based [0..length-1]; r[0] 暂存待插记录
// 用折半查找确定插入位置, 相等时继续在右半查找以保证稳定
void BInsertSort(SqList& L) {
    for (int i = 2; i <= L.length; ++i) {
        L.r[0] = L.r[i];            ++MOV;   // 暂存
        int low = 1, high = i - 1;
        while (low <= high) {
            int m = (low + high) / 2;
            if (LT(L.r[0].key, L.r[m].key)) high = m - 1;
            else                            low  = m + 1;
        }
        for (int j = i - 1; j >= low; --j) {
            L.r[j + 1] = L.r[j];    ++MOV;   // 后移
        }
        L.r[low] = L.r[0];          ++MOV;   // 插入
    }
}
// @ENDSECTION

// @SECTION 10.2 | 插入排序(表插入与 Arrange 重排)
// 复杂度: 时间 O(n^2), 空间 O(n), 稳定性: 稳定
// 下标换算: SL.r[1..length] 对应 0-based [0..length-1]; SL.r[0] 为头结点
// Arrange: 依静态链表 next 链把记录物理重排到 r[1..length], 保链序即稳定
void Arrange(SLList& SL) {
    vector<RedType> buf;
    buf.reserve(SL.length);
    for (int p = SL.r[0].next; p != 0; p = SL.r[p].next)
        buf.push_back(SL.r[p].rc);
    for (int i = 1; i <= (int)buf.size(); ++i) {
        SL.r[i].rc = buf[i - 1];    ++MOV;   // 0-based buf[0] -> r[1]
    }
}
// TableInsertSort: 建按关键字有序的静态链表(相等插在之后, 稳定), 再重排
void TableInsertSort(SqList& L) {
    SLList SL{};
    SL.length = L.length;
    for (int i = 1; i <= SL.length; ++i) { SL.r[i].rc = L.r[i]; ++MOV; }
    if (SL.length >= 1) {
        SL.r[0].next = 1;
        SL.r[1].next = 0;
        for (int i = 2; i <= SL.length; ++i) {
            int pre = 0, p = SL.r[0].next;
            while (p != 0 && LE(SL.r[p].rc.key, SL.r[i].rc.key)) {
                pre = p; p = SL.r[p].next;
            }
            SL.r[i].next = p;
            SL.r[pre].next = i;
        }
        Arrange(SL);
    }
    for (int i = 1; i <= L.length; ++i) { L.r[i] = SL.r[i].rc; ++MOV; }
}
// @ENDSECTION

// @SECTION 10.2 | 插入排序(希尔排序)
// 复杂度: 时间 O(n^1.3) 约, 空间 O(1), 稳定性: 不稳定
// 下标换算: r[1..length] 对应 0-based [0..length-1]; r[0] 暂存, 增量 dk=n/2..1
// 一趟增量为 dk 的插入排序
void ShellInsert(SqList& L, int dk) {
    for (int i = dk + 1; i <= L.length; ++i) {
        if (LT(L.r[i].key, L.r[i - dk].key)) {
            L.r[0] = L.r[i];                ++MOV;
            int j;
            for (j = i - dk; j > 0 && LT(L.r[0].key, L.r[j].key); j -= dk) {
                L.r[j + dk] = L.r[j];       ++MOV;   // 按 dk 后移
            }
            L.r[j + dk] = L.r[0];           ++MOV;
        }
    }
}
// 增量序列 dk = n/2, n/4, ..., 1 (教材 dlta[] 取法)
void ShellSort(SqList& L) {
    for (int dk = L.length / 2; dk >= 1; dk /= 2)
        ShellInsert(L, dk);
}
// @ENDSECTION

// @SECTION 10.3 | 交换排序(冒泡排序)
// 复杂度: 时间 O(n^2), 空间 O(1), 稳定性: 稳定
// 下标换算: r[1..length] 对应 0-based [0..length-1]; lastExchangeIndex 为 1-based
// 每趟用 lastExchangeIndex 记下最后交换处, 下一趟只扫到该处
void BubbleSort(SqList& L) {
    int i = L.length;
    while (i > 1) {
        int lastExchangeIndex = 1;
        for (int j = 1; j < i; ++j) {
            if (GT(L.r[j].key, L.r[j + 1].key)) {
                RedType t = L.r[j];
                L.r[j] = L.r[j + 1];
                L.r[j + 1] = t;
                MOV += 3;
                lastExchangeIndex = j;
            }
        }
        i = lastExchangeIndex;
    }
}
// @ENDSECTION

// @SECTION 10.3 | 交换排序(快速排序)
// 复杂度: 时间 O(nlogn) 平均, 空间 O(logn) 递归栈, 稳定性: 不稳定
// 下标换算: r[low..high] 为 1-based 当前子表; r[0] 暂存枢轴记录
// Partition: 一趟划分, 返回枢轴最终位置; VERBOSE 时由 QSort 打印每趟划分结果
int Partition(SqList& L, int low, int high) {
    L.r[0] = L.r[low];              ++MOV;   // 枢轴暂存
    KeyType pivotkey = L.r[0].key;
    while (low < high) {
        while (low < high && GE(L.r[high].key, pivotkey)) --high;
        L.r[low] = L.r[high];       ++MOV;   // 小者移到低端
        while (low < high && LE(L.r[low].key, pivotkey)) ++low;
        L.r[high] = L.r[low];       ++MOV;   // 大者移到高端
    }
    L.r[low] = L.r[0];              ++MOV;   // 枢轴归位
    return low;
}
void QSort(SqList& L, int low, int high) {
    if (low < high) {
        int pivotloc = Partition(L, low, high);
        if (VERBOSE) {
            cout << "  划分[" << low << "," << high << "] 枢轴位=" << pivotloc << ": ";
            for (int i = 1; i <= L.length; ++i) cout << L.r[i].key << ' ';
            cout << '\n';
        }
        QSort(L, low, pivotloc - 1);
        QSort(L, pivotloc + 1, high);
    }
}
void QuickSort(SqList& L) { QSort(L, 1, L.length); }
// @ENDSECTION

// @SECTION 10.4 | 选择排序(简单选择)
// 复杂度: 时间 O(n^2), 空间 O(1), 稳定性: 不稳定
// 下标换算: r[1..length] 对应 0-based [0..length-1]; 每趟在 r[i..length] 选最小
// 选最小关键字记录与 r[i] 交换, 交换可能越过相等关键字故不稳定
void SelectSort(SqList& L) {
    for (int i = 1; i < L.length; ++i) {
        int k = i;
        for (int j = i + 1; j <= L.length; ++j)
            if (LT(L.r[j].key, L.r[k].key)) k = j;
        if (k != i) {
            RedType t = L.r[i];
            L.r[i] = L.r[k];
            L.r[k] = t;
            MOV += 3;
        }
    }
}
// @ENDSECTION

// @SECTION 10.4 | 选择排序(堆排序)
// 复杂度: 时间 O(nlogn), 空间 O(1), 稳定性: 不稳定
// 下标换算: r[1..length] 为 1-based 完全二叉树; r[s] 的孩子为 r[2s], r[2s+1]
// 大顶堆: HeapAdjust 筛选 s 使 r[s..m] 成堆; 建堆后反复交换堆顶与堆尾
void HeapAdjust(SqList& L, int s, int m) {
    RedType rc = L.r[s];             ++MOV;   // 暂存子树根
    for (int j = 2 * s; j <= m; j *= 2) {
        if (j < m && LT(L.r[j].key, L.r[j + 1].key)) ++j;   // 取较大孩子
        if (!LT(rc.key, L.r[j].key)) break;                  // 已满足堆
        L.r[s] = L.r[j];            ++MOV;   // 大孩子上移
        s = j;
    }
    L.r[s] = rc;                     ++MOV;   // 归位
}
void HeapSort(SqList& L) {
    int n = L.length;
    for (int i = n / 2; i >= 1; --i) HeapAdjust(L, i, n);   // 建大顶堆
    if (VERBOSE) {
        cout << "  建堆结果: ";
        for (int i = 1; i <= n; ++i) cout << L.r[i].key << ' ';
        cout << '\n';
    }
    for (int i = n; i >= 2; --i) {
        RedType t = L.r[1];
        L.r[1] = L.r[i];
        L.r[i] = t;
        MOV += 3;
        HeapAdjust(L, 1, i - 1);
    }
}
// @ENDSECTION

// @SECTION 10.5 | 归并排序(2-路归并 递归)
// 复杂度: 时间 O(nlogn), 空间 O(n), 稳定性: 稳定
// 下标换算: SR[i..m] 与 SR[m+1..n] 为 1-based 两段; Aux 为全局辅助数组
// 相等关键字取左段优先(<=), 保证稳定; 归并后拷回 SR 供上层继续
void Merge(RedType SR[], RedType TR[], int i, int m, int n) {
    int j = m + 1, k = i;
    while (i <= m && j <= n) {
        if (LE(SR[i].key, SR[j].key)) { TR[k] = SR[i]; ++i; }
        else                          { TR[k] = SR[j]; ++j; }
        ++k; ++MOV;
    }
    while (i <= m) { TR[k] = SR[i]; ++k; ++i; ++MOV; }
    while (j <= n) { TR[k] = SR[j]; ++k; ++j; ++MOV; }
}
void MSort(RedType SR[], RedType TR[], int s, int t) {
    if (s >= t) return;                       // 递归边界: 单元素有序
    int m = (s + t) / 2;
    MSort(SR, TR, s, m);
    MSort(SR, TR, m + 1, t);
    Merge(SR, TR, s, m, t);
    for (int i = s; i <= t; ++i) { SR[i] = TR[i]; ++MOV; }
}
void MergeSort(SqList& L) { MSort(L.r, Aux, 1, L.length); }
// @ENDSECTION

// @SECTION 10.5 | 归并排序(自底向上 非递归)
// 复杂度: 时间 O(nlogn), 空间 O(n), 稳定性: 稳定
// 下标换算: r[1..length] 1-based; 步长 len=1,2,4... 归并相邻两段
// 无伙伴的尾段已有序, 直接留在原处; 每轮归并后拷回原表
void MergeSort_Iter(SqList& L) {
    int n = L.length;
    for (int len = 1; len < n; len *= 2) {
        for (int s = 1; s + len <= n; s += 2 * len) {
            int m = s + len - 1;
            int t = (s + 2 * len - 1 <= n) ? (s + 2 * len - 1) : n;
            Merge(L.r, Aux, s, m, t);
            for (int i = s; i <= t; ++i) { L.r[i] = Aux[i]; ++MOV; }
        }
    }
}
// @ENDSECTION

// @SECTION 10.6 | 基数排序(LSD 分配-收集)
// 复杂度: 时间 O(d(n+10)), 空间 O(n+10), 稳定性: 稳定(按链分配收集)
// 下标换算: SL.r[1..length] 对应 0-based [0..length-1]; SL.r[0] 头结点; 十进制非负整数
// f[10]/e[10] 为 10 个桶的队头/队尾(结点下标), 低位到高位分配-收集 d 趟
void RadixSort(SqList& L) {
    if (L.length <= 0) return;
    SLList SL{};
    SL.length = L.length;
    for (int i = 1; i <= SL.length; ++i) {
        SL.r[i].rc = L.r[i];                         ++MOV;
        SL.r[i].next = (i < SL.length) ? (i + 1) : 0;
    }
    SL.r[0].next = 1;                                // 初始链 1->2->...->n->0
    int maxKey = 0;
    for (int i = 1; i <= L.length; ++i)
        if (L.r[i].key > maxKey) maxKey = L.r[i].key;
    int d = 1, p = 10;
    while (maxKey >= p) { ++d; p *= 10; }            // 最大位数
    int power = 1;
    for (int k = 0; k < d; ++k) {
        int f[10], e[10];
        for (int j = 0; j < 10; ++j) { f[j] = 0; e[j] = 0; }
        for (int i = SL.r[0].next; i != 0; i = SL.r[i].next) {
            int digit = (SL.r[i].rc.key / power) % 10;
            ++CMP;                                    // 分配一次判断
            if (f[digit] == 0) f[digit] = i;
            else SL.r[e[digit]].next = i;
            e[digit] = i;
        }
        int j = 0;
        while (j < 10 && f[j] == 0) ++j;             // 找首个非空桶
        SL.r[0].next = f[j];
        int tail = e[j];
        for (++j; j < 10; ++j) {
            if (f[j] != 0) { SL.r[tail].next = f[j]; tail = e[j]; }
        }
        SL.r[tail].next = 0;                         // 链尾
        power *= 10;
    }
    int idx = 1;
    for (int i = SL.r[0].next; i != 0; i = SL.r[i].next) {
        L.r[idx] = SL.r[i].rc;                       ++MOV;
        ++idx;
    }
}
// @ENDSECTION

// @SECTION 10.7 | 测试框架(公共辅助与算法清单)
// 复杂度: 测试辅助, 时间/空间 O(n); 稳定性: 由 key+ord 二元组判定
// 下标换算: MakeList 把 0-based vector a[0..n-1] 装入 1-based r[1..n]
inline SqList MakeList(const vector<int>& a) {
    SqList L{};                                   // 值初始化, r[] 清零
    L.length = (int)a.size();
    for (int i = 1; i <= L.length; ++i) {
        L.r[i].key = a[i - 1];                    // 0-based a[i-1] -> 1-based r[i]
        L.r[i].ord = i - 1;                      // 原序标号 = 0-based 下标
    }
    return L;
}
inline vector<int> Keys(const SqList& L) {
    vector<int> v;
    v.reserve(L.length);
    for (int i = 1; i <= L.length; ++i) v.push_back(L.r[i].key);
    return v;
}
inline vector<int> Sorted(vector<int> v) {
    std::sort(v.begin(), v.end());
    return v;
}
inline bool IsStable(const SqList& L) {
    for (int i = 2; i <= L.length; ++i)
        if (L.r[i].key == L.r[i - 1].key && L.r[i].ord < L.r[i - 1].ord)
            return false;
    return true;
}
static unsigned int RNG = 20261111u;
inline int NextRand() {
    RNG = RNG * 1103515245u + 12345u;            // 线性同余, 结果确定
    return (int)(RNG % 100000);
}
inline vector<int> MakeData(int kind, int n) {
    vector<int> a(n);
    for (int i = 0; i < n; ++i) {
        if (kind == 0)      a[i] = NextRand() % 100;   // 随机 0..99
        else if (kind == 1) a[i] = n - i;              // 逆序 n..1
        else if (kind == 2) a[i] = i + 1;              // 已有序 1..n
        else                a[i] = NextRand() % 5;     // 大量重复 0..4
    }
    return a;
}
using SortFn = void (*)(SqList&);
struct Algo { const char* name; SortFn fn; bool stable; };
static const Algo ALGOS[] = {
    {"直接插入",   InsertionSort,   true},
    {"折半插入",   BInsertSort,     true},
    {"表插入",     TableInsertSort, true},
    {"希尔",       ShellSort,       false},
    {"冒泡",       BubbleSort,      true},
    {"快速",       QuickSort,       false},
    {"简单选择",   SelectSort,      false},
    {"堆",         HeapSort,        false},
    {"归并(递归)", MergeSort,       true},
    {"归并(迭代)", MergeSort_Iter,  true},
    {"基数",       RadixSort,       true},
};
static const int ALGO_COUNT = (int)(sizeof(ALGOS) / sizeof(ALGOS[0]));
// @ENDSECTION

// @SECTION 10.7 | 测试框架(正确性与开销统计)
// 复杂度: 计时统计, 时间 O(11*4*nlogn) 约, 空间 O(n); 稳定性: 不涉及
// 下标换算: 数据由 MakeList 转为 1-based 顺序表, 结果由 Keys 转回 0-based 比对
void RunCorrectnessAndCost() {
    VERBOSE = false;
    const int N = 40;
    vector<vector<int>> data(4);
    for (int k = 0; k < 4; ++k) data[k] = MakeData(k, N);
    cout << "[10.7] 正确性/开销: 4 类数据, 结果均与 std::sort 比对\n";
    cout << "  算法        比较次数  移动次数  耗时(us)\n";
    long long grandC = 0, grandM = 0;
    for (int a = 0; a < ALGO_COUNT; ++a) {
        long long tc = 0, tm = 0, tus = 0;
        bool ok = true;
        for (int k = 0; k < 4; ++k) {
            vector<int> expect = Sorted(data[k]);
            SqList L = MakeList(data[k]);
            ResetCost();
            auto t0 = std::chrono::high_resolution_clock::now();
            ALGOS[a].fn(L);
            auto t1 = std::chrono::high_resolution_clock::now();
            tus += std::chrono::duration_cast<std::chrono::microseconds>(t1 - t0).count();
            tc += CMP; tm += MOV;
            if (Keys(L) != expect) ok = false;
        }
        DS_CHECK(ok);
        g_allPass = g_allPass && ok;
        grandC += tc; grandM += tm;
        cout << "  " << ALGOS[a].name << " cmp=" << tc << " mov=" << tm
             << " t=" << tus << "us\n";
    }
    cout << "  合计(4类数据累加): 比较 " << grandC << ", 移动 " << grandM << "\n";
}
// @ENDSECTION

// @SECTION 10.7 | 测试框架(稳定性对照)
// 复杂度: 稳定性验证, 时间/空间 O(n); 稳定性: 插入/冒泡/归并/基数稳定, 其余不稳定
// 下标换算: 二元组记录 (key, ord); ord 为 0-based 原序, 相等 key 看 ord 是否递增
// 下面重复关键字数据集经预先验证, 能稳定复现 4 种不稳定算法的失稳
static const int STAB_DATA[] = {
    4, 1, 4, 3, 1, 4, 2, 4, 2, 2, 2, 3,
    4, 2, 3, 2, 4, 2, 1, 4, 2, 4, 4, 2
};
void RunStability() {
    VERBOSE = false;
    vector<int> s(STAB_DATA, STAB_DATA + sizeof(STAB_DATA) / sizeof(int));
    cout << "[10.7] 稳定性对照(key+ord 二元组, 看重复关键字原序是否保序)\n";
    for (int a = 0; a < ALGO_COUNT; ++a) {
        SqList L = MakeList(s);
        ResetCost();
        ALGOS[a].fn(L);
        bool stable = IsStable(L);
        DS_CHECK(Keys(L) == Sorted(s));
        DS_CHECK(stable == ALGOS[a].stable);
        g_allPass = g_allPass && (stable == ALGOS[a].stable);
        cout << "  " << ALGOS[a].name << " : " << (stable ? "稳定" : "不稳定") << "\n";
    }
}
// @ENDSECTION

int main() {
    Demo demo("第10章 内部排序 综合自测");
    vector<int> sample = {49, 38, 65, 97, 76, 13, 27, 49};
    printSeq(sample, "演示序列");

    {   // 直接插入排序演示
        SqList L = MakeList(sample);
        InsertionSort(L);
        printSeq(Keys(L), "直接插入排序结果");
        DS_CHECK(Keys(L) == Sorted(sample));
    }

    {   // 快速排序: 打印每趟划分结果
        SqList L = MakeList(sample);
        VERBOSE = true;
        QuickSort(L);
        VERBOSE = false;
        DS_CHECK(Keys(L) == Sorted(sample));
    }

    {   // 堆排序: 打印建堆结果
        SqList L = MakeList(sample);
        VERBOSE = true;
        HeapSort(L);
        VERBOSE = false;
        DS_CHECK(Keys(L) == Sorted(sample));
    }

    RunCorrectnessAndCost();
    RunStability();

    DS_CHECK(g_allPass);
    cout << "全部断言通过\n";
    return 0;
}
