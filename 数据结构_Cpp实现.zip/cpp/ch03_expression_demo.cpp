// ch03_expression_demo.cpp —— 教材 3.2.5「表达式求值（算符优先法）」完整可编译示例
// 编译：g++ -std=c++17 -O2 ch03_expression_demo.cpp -o expr && ./expr
// 说明：与 ch07_prim_demo.cpp 风格一致，整段为一个 @SECTION，复制即可编译运行。
// @SECTION 3.2.5 | 完整可编译示例：表达式求值（算符优先法）
#include "ds_common.h"
#include <iomanip>

// ---------- 算符优先表 Precede[行][列] ----------
// 行 = OPTR 栈顶算符 θ1，列 = 当前读入算符 θ2；行列顺序统一为 + - * / ( ) # 七种算符。
// '>' ：θ1 优先权高于 θ2，应弹出 θ1 与两个操作数做一次运算（退栈运算）；
// '<' ：θ2 优先权更高，θ2 应压入 OPTR（进栈）；
// '=' ：θ1 与 θ2 配对（'(' 遇 ')' 脱括号，或 '#' 遇 '#' 结束）；
// ' ' ：非法组合（即教材表中的空格，如括号不匹配），据此安全报错，不崩溃。
static const char kPrecTable[7][7] = {
    /*      +    -    *    /    (    )    #   */
    /* + */ {'>', '>', '<', '<', '<', '>', '>'},
    /* - */ {'>', '>', '<', '<', '<', '>', '>'},
    /* * */ {'>', '>', '>', '>', '<', '>', '>'},
    /* / */ {'>', '>', '>', '>', '<', '>', '>'},
    /* ( */ {'<', '<', '<', '<', '<', '=', ' '},
    /* ) */ {'>', '>', '>', '>', ' ', '>', '>'},
    /* # */ {'<', '<', '<', '<', '<', ' ', '='},
};

int OpIndex(char c) {
    switch (c) {
        case '+': return 0;
        case '-': return 1;
        case '*': return 2;
        case '/': return 3;
        case '(': return 4;
        case ')': return 5;
        case '#': return 6;
        default:  return -1;
    }
}

char Precede(char theta1, char theta2) {
    int r = OpIndex(theta1), c = OpIndex(theta2);
    if (r < 0 || c < 0) return '?';             // 非法字符
    return kPrecTable[r][c];
}

// 教材 Operate(a, theta, b)：附加 ok 引用用于除零等错误的安全处理（前 3 参数与教材一致）。
int Operate(int a, char theta, int b, bool& ok) {
    switch (theta) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/':
            if (b == 0) { ok = false; return 0; } // 除零：安全返回
            return a / b;                         // 整数除法（C++ 向零取整）
        default:
            ok = false; return 0;
    }
}

// 把 stack 按「栈底 -> 栈顶」拼成字符串，便于逐步打印。
string StackStr(std::stack<char> s) {
    string r;
    while (!s.empty()) { r += s.top(); s.pop(); }
    std::reverse(r.begin(), r.end());
    return r;
}
string StackStr(std::stack<int> s) {
    vector<int> v;
    while (!s.empty()) { v.push_back(s.top()); s.pop(); }
    std::reverse(v.begin(), v.end());
    string r;
    for (int x : v) r += std::to_string(x) + " ";
    return r;
}

// 教材算法 3.4 EvaluateExpression：OPTR / OPND 双栈 + 算符优先。
// 支持多位数、括号、整数除法；表达式以 '#' 结尾。
// ok=false 表示语法错误或除零（安全处理）；verbose 时逐步打印两栈、读入字符与动作。
// 取舍：按教材最小实现，未支持前导正负号（教材把 '-' 一律视为二元减）。
int EvaluateExpression(const string& expr, bool& ok, bool verbose = false) {
    ok = true;
    std::stack<char> OPTR;
    std::stack<int>  OPND;
    OPTR.push('#');                             // 栈底哨兵
    size_t p = 0;
    char c = expr[0];                          // 当前读入字符（教材 c=getchar()）
    auto nextChar = [&]() -> char {
        ++p;
        return (p < expr.size()) ? expr[p] : '#';
    };
    auto dump = [&](char cur, const string& act) {
        if (!verbose) return;
        cout << "  c='" << cur << "'  OPTR[" << std::left << std::setw(7)
             << StackStr(OPTR) << "] OPND[" << std::setw(9) << StackStr(OPND)
             << std::right << "]  " << act << "\n";
    };
    auto isDig = [](char x) { return x >= '0' && x <= '9'; };

    if (verbose) cout << "  初始 OPTR[#]、OPND[]\n";
    while (c != '#' || OPTR.top() != '#') {
        char cur = c;
        if (isDig(cur)) {                       // 一次读完整多位数
            int val = 0;
            while (isDig(c)) { val = val * 10 + (c - '0'); c = nextChar(); }
            OPND.push(val);
            dump(cur, "数字 " + std::to_string(val) + " 进 OPND");
            continue;                           // c 已是下一位算符，不重复读
        }
        char rel = Precede(OPTR.top(), cur);
        if (rel == '<') {
            OPTR.push(cur);
            c = nextChar();
            dump(cur, string("Precede='<'，算符 ") + cur + " 进 OPTR");
        } else if (rel == '=') {
            OPTR.pop();
            c = nextChar();
            dump(cur, "Precede='='，脱括号 / 结束并读下一字符");
        } else if (rel == '>') {
            if (OPND.size() < 2 || OPTR.empty()) { ok = false; return 0; }
            char theta = OPTR.top(); OPTR.pop();
            int b = OPND.top(); OPND.pop();
            int a = OPND.top(); OPND.pop();
            int r = Operate(a, theta, b, ok);
            if (!ok) { dump(cur, "除零，安全报错返回"); return 0; }
            OPND.push(r);
            dump(cur, string("Precede='>'，弹 ") + theta + " 算 " +
                      std::to_string(a) + string(1, theta) + std::to_string(b) +
                      " = " + std::to_string(r));
        } else {                                // ' ' 或 '?'：非法组合
            ok = false;
            dump(cur, "非法算符组合（括号不匹配 / 非法字符），安全报错返回");
            return 0;
        }
    }
    if (OPND.size() != 1) { ok = false; return 0; }
    return OPND.top();
}

int main() {
    Demo demo("3.2.5 表达式求值完整示例（算符优先法）");

    // [一] 逐步演示：3*(7-2)#
    cout << "\n[一] 逐步求值 3*(7-2)#（打印 OPTR / OPND / 读入字符 / 动作）\n";
    bool ok = true;
    int r1 = EvaluateExpression("3*(7-2)#", ok, true);
    DS_CHECK(ok && r1 == 15);                   // 手算：3*(7-2)=15
    cout << "  => 结果 " << r1 << "，断言 15\n";

    // [二] 另外两个表达式（不逐步打印，只断言结果）
    cout << "\n[二] 多位数 / 混合优先级 / 括号 断言\n";
    int r2 = EvaluateExpression("2+3*4#", ok);
    DS_CHECK(ok && r2 == 14);                   // 手算：2+12=14
    int r3 = EvaluateExpression("(8+2)*3-6/2#", ok);
    DS_CHECK(ok && r3 == 27);                   // 手算：30-3=27
    cout << "  2+3*4# = " << r2 << "（断言 14）\n";
    cout << "  (8+2)*3-6/2# = " << r3 << "（断言 27）\n";

    // [三] 非法括号与除零的安全处理
    cout << "\n[三] 错误表达式安全处理\n";
    bool bad1 = true, bad2 = true;
    EvaluateExpression("3+4)#", bad1);          // 右括号多余
    EvaluateExpression("8/0#", bad2);           // 除零
    DS_CHECK(!bad1 && !bad2);                   // 均安全报错，不崩溃
    cout << "  3+4)# -> 非法括号，安全报错\n";
    cout << "  8/0#  -> 除零，安全报错\n";

    cout << "\n[3.2.5] 断言通过：15 / 14 / 27，非法括号与除零均被安全处理\n";
    return 0;
}
// @ENDSECTION
