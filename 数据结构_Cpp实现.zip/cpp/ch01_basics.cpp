// ch01_basics.cpp - 第 1 章 绪论: 可编译 C++17 实现
// 对应"数据结构(C 语言版)"严蔚敏 1.3 抽象数据类型, 1.4 算法和算法分析
// 只依赖标准库与 ds_common.h, 自带 main() 演示与 DS_CHECK 自测
#include "ds_common.h"

// @SECTION 1.3 | 复数抽象数据类型 ADT Complex
// 教材 1.3 的 ADT Complex: 数据对象 D = {e1, e2}, 关系 R = {<e1, e2>}.
// 用 struct 表示值, 用自由函数实现基本操作, 引用参数 &sum 与教材伪码一致.
// 时间复杂度: 各操作均 O(1); 空间复杂度: O(1).
struct Complex {
    double real = 0.0;   // 实部 e1, 缺省初始化为 0, 避免未初始化读取
    double imag = 0.0;   // 虚部 e2
};
Status InitComplex(Complex& Z, double v1, double v2) {  // 教材 InitComplex(&Z, v1, v2)
    Z.real = v1; Z.imag = v2;
    return OK;
}
Status Assign(Complex& Z, double v1, double v2) {         // 赋值参数版, 语义同 InitComplex
    return InitComplex(Z, v1, v2);
}
double GetReal(const Complex& Z) { return Z.real; }        // 教材 GetReal(Z, &realPart)
double GetImag(const Complex& Z) { return Z.imag; }
Status Add(const Complex& z1, const Complex& z2, Complex& sum) {  // Add(z1, z2, &sum)
    sum.real = z1.real + z2.real;
    sum.imag = z1.imag + z2.imag;
    return OK;
}
Status Multiply(const Complex& z1, const Complex& z2, Complex& prod) {
    // (a+bi)*(c+di) = (ac-bd) + (ad+bc)i
    prod.real = z1.real * z2.real - z1.imag * z2.imag;
    prod.imag = z1.real * z2.imag + z1.imag * z2.real;
    return OK;
}
void PrintComplex(const Complex& Z) {                     // 演示用, 非 ADT 基本操作
    cout << Z.real << (Z.imag >= 0 ? " + " : " - ") << std::fabs(Z.imag) << "i\n";
}
// @ENDSECTION

// @SECTION 1.3 | 三元组抽象数据类型 Triplet (例 1-6 / 例 1-7)
// 教材 Triplet 为 ElemType* 指向 3 个连续元素, 此处用 vector 自动管理内存.
// 与教材下标约定: 教材 Get/Put 的位序 i 从 1 起 (1..3), 内部容器 e 为 0-based,
//   取元素用 e[i-1]; 位序与下标的换算在本段集中体现.
// 时间复杂度: 各操作均 O(3) = O(1); 空间复杂度: O(1) 辅助.
struct Triplet {
    vector<ElemType> e;   // 3 个元素, 0-based 内部存储
};
Status InitTriplet(Triplet& T, ElemType v1, ElemType v2, ElemType v3) {
    T.e = {v1, v2, v3};                  // 教材 malloc(3*sizeof(ElemType)) 后逐个赋值
    return OK;
}
Status DestroyTriplet(Triplet& T) {
    T.e.clear();                          // 教材 free(T); vector 自行释放
    return OK;
}
Status Get(const Triplet& T, int i, ElemType& e) {
    if (i < 1 || i > 3 || T.e.size() != 3) return ERROR;
    e = T.e[i - 1];                       // 1-based 位序 -> 0-based 下标
    return OK;
}
Status Put(Triplet& T, int i, ElemType e) {
    if (i < 1 || i > 3 || T.e.size() != 3) return ERROR;
    T.e[i - 1] = e;
    return OK;
}
Status IsAscending(const Triplet& T) {
    if (T.e.size() != 3) return ERROR;
    return (T.e[0] <= T.e[1] && T.e[1] <= T.e[2]) ? TRUE : FALSE;
}
Status IsDescending(const Triplet& T) {
    if (T.e.size() != 3) return ERROR;
    return (T.e[0] >= T.e[1] && T.e[1] >= T.e[2]) ? TRUE : FALSE;
}
Status Max(const Triplet& T, ElemType& e) {
    if (T.e.size() != 3) return ERROR;
    e = std::max(T.e[0], std::max(T.e[1], T.e[2]));
    return OK;
}
Status Min(const Triplet& T, ElemType& e) {
    if (T.e.size() != 3) return ERROR;
    e = std::min(T.e[0], std::min(T.e[1], T.e[2]));
    return OK;
}
Status Replace(Triplet& T, ElemType x, ElemType y) {
    // 教材风格补充操作: 把三元组中所有值为 x 的元素替换为 y, 有替换返回 OK
    bool hit = false;
    for (auto& v : T.e) if (v == x) { v = y; hit = true; }
    return hit ? OK : ERROR;
}
// @ENDSECTION

// @SECTION 1.4 | 语句频度统计与渐近时间复杂度
// 把教材三类经典频度分析的"基本操作"替换为 ++count, 返回真实执行次数.
// 教材例 1: 三重循环矩阵乘法 (乘法为原操作, O(n^3)); 例 2: 选择排序比较 (O(n^2));
// 例 3: k*=2 外层乘 n 内层 (O(n log n)); 另补单层 ++x (O(n)) 与 k*=2 (O(log n)).
// 时间复杂度 = 各自渐近阶, 空间复杂度均 O(1) (原地计数, 未引入辅助数组).
long long freqO_n(int n) {                 // O(n)
    long long count = 0;
    for (int i = 1; i <= n; ++i) ++count;
    return count;                          // 实测 = n
}
long long freqO_n2(int n) {                // O(n^2)
    long long count = 0;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j) ++count;
    return count;                          // 实测 = n*n
}
long long freqSelectSort(int n) {          // 教材例 2: 选择排序比较次数, O(n^2)
    long long count = 0;
    for (int i = 1; i < n; ++i)
        for (int j = i + 1; j <= n; ++j) ++count;
    return count;                          // 实测 = n*(n-1)/2
}
long long freqO_n3(int n) {                // 教材例 1: 三重循环矩阵乘法, O(n^3)
    long long mul = 0;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j)
            for (int k = 1; k <= n; ++k) ++mul;
    return mul;                            // 实测 = n*n*n
}
long long freqO_logn(int n) {              // k *= 2 型循环, O(log n)
    long long count = 0;
    for (int k = 1; k <= n; k *= 2) ++count;
    return count;                          // 实测 = floor(log2(n))+1
}
long long freqO_nlogn(int n) {             // 教材例 3: k*=2 外层乘 n 内层, O(n log n)
    long long count = 0;
    for (int k = 1; k <= n; k *= 2)
        for (int j = 1; j <= n; ++j) ++count;
    return count;                          // 实测 = n*(floor(log2(n))+1)
}
// @ENDSECTION

// @SECTION 1.4 | 递归与迭代对比: 阶乘与 Fibonacci 的频度计数
// ops 为"基本操作"计数, 与语句频度等价, 代替平台相关的计时 API.
// 时间复杂度: 阶乘 O(n) (两种写法); Fib 递归 O(2^n), Fib 迭代 O(n).
// 空间复杂度: 迭代只用常数辅助变量 = O(1) 原地工作; 递归栈深度为 n = O(n).
long long factRecursive(int n, long long& ops) {
    ++ops;
    if (n <= 1) return 1;
    return n * factRecursive(n - 1, ops);   // 递归深度 n, 栈空间 O(n)
}
long long factIterative(int n, long long& ops) {
    long long r = 1;
    for (int i = 2; i <= n; ++i) { ++ops; r *= i; }
    return r;                                // 仅常数辅助变量, O(1)
}
long long fibRecursive(int n, long long& ops) {
    ++ops;
    if (n <= 1) return n;
    return fibRecursive(n - 1, ops) + fibRecursive(n - 2, ops);  // 指数级
}
long long fibIterative(int n, long long& ops) {
    long long a = 0, b = 1;
    if (n <= 1) return n;
    for (int i = 2; i <= n; ++i) {
        ++ops;
        long long c = a + b; a = b; b = c;
    }
    return b;                                 // O(n) 时间, O(1) 空间
}
// @ENDSECTION

// @SECTION 1.4 | 算法存储空间需求: 原地工作 O(1) 与辅助数组 O(n)
// 教材 1.4.4: 只比较辅助变量所占空间; 输入数据与程序代码所占空间与算法无关, 不计入 S(n).
// 额外空间相对输入为常数时称原地工作; 本段演示同一逆置问题的两种空间代价.
// 与教材下标约定: 此处用 STL vector 的 0-based 写法, n = v.size().
// 时间复杂度: 两种写法均 O(n); 空间复杂度: 就地逆置 O(1), 辅助数组 O(n).
// S(n) = O(g(n)) 中 g(n) 只统计算法运行期间额外申请的辅助空间, 不含输入本身.
// 若存储量依赖于特定输入, 按最坏情况估计; 常数额外空间即 S(n) = O(1).
// 注意: 返回新 vector 属于 O(n) 辅助空间, 而直接改写形参属于原地工作.
void reverseInPlace(vector<int>& v) {
    // 只用一个临时变量交换, 不另开数组, S(n) = O(1) 原地工作
    int i = 0, j = static_cast<int>(v.size()) - 1;
    while (i < j) { std::swap(v[i], v[j]); ++i; --j; }
}
vector<int> reverseWithBuffer(const vector<int>& v) {
    // 新建同规模数组容纳结果, S(n) = O(n), 非原地
    return vector<int>(v.rbegin(), v.rend());
}
// @ENDSECTION

int main() {
    {
        Demo d("1.3 复数 ADT Complex");
        Complex z1, z2, sum, prod;
        Assign(z1, 1.0, 2.0);
        Assign(z2, 3.0, 4.0);
        Add(z1, z2, sum);
        Multiply(z1, z2, prod);
        PrintComplex(sum);
        PrintComplex(prod);
        DS_CHECK(GetReal(sum) == 4.0 && GetImag(sum) == 6.0);
        DS_CHECK(GetReal(prod) == -5.0 && GetImag(prod) == 10.0);
    }
    {
        Demo d("1.3 三元组 ADT Triplet");
        Triplet T;
        InitTriplet(T, 1, 3, 5);
        ElemType x = 0;
        Get(T, 2, x);
        DS_CHECK(x == 3);
        DS_CHECK(IsAscending(T) == TRUE);
        Max(T, x); DS_CHECK(x == 5);
        Min(T, x); DS_CHECK(x == 1);
        Put(T, 2, 9);
        Get(T, 2, x); DS_CHECK(x == 9);
        DS_CHECK(IsDescending(T) == FALSE);
        Replace(T, 9, 7);
        Get(T, 2, x); DS_CHECK(x == 7);
        printSeq(T.e, "三元组");
        DestroyTriplet(T);
        DS_CHECK(T.e.empty());
    }
    {
        Demo d("1.4 语句频度统计与渐近时间复杂度");
        const int n = 8;
        cout << "n = " << n << '\n';
        cout << "单层循环 ++x   : 实测 " << freqO_n(n)       << "  渐近 O(n)\n";
        cout << "二重循环 ++x   : 实测 " << freqO_n2(n)      << "  渐近 O(n^2)\n";
        cout << "选择排序比较   : 实测 " << freqSelectSort(n) << "  渐近 O(n^2)\n";
        cout << "矩阵乘法 三重  : 实测 " << freqO_n3(n)      << "  渐近 O(n^3)\n";
        cout << "k*=2 循环      : 实测 " << freqO_logn(n)    << "  渐近 O(log n)\n";
        cout << "k*=2 乘 n 例3  : 实测 " << freqO_nlogn(n)   << "  渐近 O(n log n)\n";
        DS_CHECK(freqO_n(n) == n);
        DS_CHECK(freqO_n2(n) == 1LL * n * n);
        DS_CHECK(freqSelectSort(n) == 1LL * n * (n - 1) / 2);
        DS_CHECK(freqO_n3(n) == 1LL * n * n * n);
        DS_CHECK(freqO_logn(n) == 4);
        DS_CHECK(freqO_nlogn(n) == 1LL * n * 4);
    }
    {
        Demo d("1.4 递归 vs 迭代 (频度计数)");
        long long o1 = 0, o2 = 0, o3 = 0, o4 = 0;
        long long fR = factRecursive(10, o1), fI = factIterative(10, o2);
        long long bR = fibRecursive(20, o3),  bI = fibIterative(20, o4);
        cout << "阶乘(10) 递归=" << fR << " ops=" << o1 << " | 迭代=" << fI << " ops=" << o2 << '\n';
        cout << "Fib(20)  递归=" << bR << " ops=" << o3 << " | 迭代=" << bI << " ops=" << o4 << '\n';
        DS_CHECK(fR == fI && fI == 3628800);
        DS_CHECK(bR == bI && bI == 6765);
        DS_CHECK(o3 > o4);
    }
    {
        Demo d("1.4 空间复杂度: 原地 O(1) 与辅助 O(n)");
        vector<int> a{1, 2, 3, 4, 5};
        reverseInPlace(a);
        printSeq(a, "就地逆置 O(1)");
        vector<int> b = reverseWithBuffer(a);
        printSeq(b, "辅助数组 O(n)");
        DS_CHECK(a[0] == 5 && a[4] == 1);
        DS_CHECK(b[0] == 1 && b[4] == 5);
    }
    return 0;
}
